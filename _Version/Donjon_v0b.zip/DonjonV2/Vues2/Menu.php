<html>
<link rel="stylesheet" 			href="../Controleurs/cssGeneral.css" type="text/css" />

<script type="text/javascript" src="..Javascript/menu.js"></script>

<body>

<div class="menu-general" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');">
Etat Personnage
</div> 
<ul id="sous-menu1" class="habillage" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');"> 
    <li><a href="?id=test">Etat Personnage</a></li> 
    <li><a href="#">Inventaire</a></li> 
    <li><a href="#">Messagerie</a></li> 
</ul>


<div class="menu-general" onmouseover="montre('sous-menu2');" onmouseout="cache('sous-menu2');">
Village
</div>
<ul id="sous-menu2" class="habillage" onmouseover="montre('sous-menu2');" onmouseout="cache('sous-menu2');">
    <li><a href="#">Visiter le village</a></li>
    <li><a href="#">Visiter l'arene</a></li>
    <li><a href="#">Visiter la taverne</a></li>
	<li><a href="#">Visiter la forge</a></li>
    <li><a href="#">Visiter le magazin</a></li>
</ul>


<div class="menu-general"onmouseover="montre('sous-menu3');" onmouseout="cache('sous-menu3');">Voyager</div> <!-- idem pr�c�dent -->
<ul id="sous-menu3" class="habillage" onmouseover="montre('sous-menu3');" onmouseout="cache('sous-menu3');">
    <li><a href="#">Afficher la carte</a></li>
    <li><a href="#">Sous-menu3 2</a></li>
    <li><a href="#">Sous-menu3 3</a></li>
</ul>



<div >


<?
	if (isset($_GET['id']))
	{
		switch ($_GET['id'])
		{
		case "test":
			include ("EtatHero.php");
			break;
		case "Liens":
			include ("Vues/vLiens.html");
			break;
	
	}
	}

else
{
?>

	

		<?
	}

?>



</div>


</body>
</html>