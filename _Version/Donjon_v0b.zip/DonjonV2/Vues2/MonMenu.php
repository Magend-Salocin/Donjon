

<link rel="stylesheet" 			href="../Controleurs/cssGeneral.css" type="text/css" />

<script type="text/javascript" src="menu.js"></script>

<div class="menu-general" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');">Menu 1</div> <!-- idem menu sans habillage -->
<ul id="sous-menu1" class="habillage" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');"> <!-- idem menu sans habillage -->
    <li><a href="#">Sous-menu1 1</a></li> <!-- idem menu sans habillage -->
    <li><a href="#">Sous-menu1 2</a></li> <!-- idem menu sans habillage -->
    <li><a href="#">Sous-menu1 3</a></li> <!-- idem menu sans habillage -->
</ul>


<div class="menu-general" onmouseover="montre('sous-menu2');" onmouseout="cache('sous-menu2');">Menu 2</div> <!-- idem pr�c�dent -->
<ul id="sous-menu2" class="habillage" onmouseover="montre('sous-menu2');" onmouseout="cache('sous-menu2');">
    <li><a href="#">Sous-menu2 1</a></li>
    <li><a href="#">Sous-menu2 2</a></li>
    <li><a href="#">Sous-menu2 3</a></li>
</ul>


<div class="menu-general"onmouseover="montre('sous-menu3');" onmouseout="cache('sous-menu3');">Menu 3</div> <!-- idem pr�c�dent -->
<ul id="sous-menu3" class="habillage" onmouseover="montre('sous-menu3');" onmouseout="cache('sous-menu3');">
    <li><a href="#">Sous-menu3 1</a></li>
    <li><a href="#">Sous-menu3 2</a></li>
    <li><a href="#">Sous-menu3 3</a></li>
</ul>



