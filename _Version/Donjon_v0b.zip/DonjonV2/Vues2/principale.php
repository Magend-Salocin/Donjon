<html><head></head>

<?
require ("../Secret/connect.php");	

include ("../MesFonctions.php");								include ("../Controleurs/ControleurMenu.php");  
include ("../Controleurs/ControleurAventure.php");				include ("../Controleurs/ControleurGrade.php"); 
include ("../Controleurs/ControleurOutil.php");  				include ("../Controleurs/ControleurVillage.php");

	
	
	if ( isset($_GET['passage']) ){//V�rifie les identifiant de connection d'un utilisateur
			$Tuple=GetAuth($_GET['nom'],$_GET['mdp']);
			SetJoueur($Tuple);	Modif("Enligne",$HeureActuelle,$_SESSION["num"]);
	}
?>
<body>


<form method="GET" action="" name="connect" >
		<br>Nom d utilisateur	<input type="text" 		name="nom" 		size="20">
		<br>Mot de passe     	<input type="password" 	name="mdp"  	value="">
								<input type="hidden" 	name="passage"  value='1'>
		<br>					<input type="button" 	name="valider" 	value="connecter" onClick ="test()">
	</form>
<form method="POST" action="EtatHero.php" name="page" target="cadreDroite">




</body></html>