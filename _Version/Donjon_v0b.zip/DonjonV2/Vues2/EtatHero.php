<?session_start();
require	("../Secret/connect.php");
include ("../MesFonctions.php");
include ("../Controleurs/ControleurMenu.php");
include ("../Controleurs/ControleurOutil.php"); 

	$heros=$_SESSION["tab"];
	$attaque= $heros["forc"]  + $heros["vit"]   ;	$attaque=$attaque*2;
	$defence= $heros["dext"]  + $heros["end"]  ;	$defence=$defence*2;
	
		if (isset($_GET["var"])){
			$num=$heros["num"];	$toto=$_GET["var"];	$heros["$toto"]="rien";
		//get euqipe + -
		//$Requete="UPDATE joueur SET ".$O[3]." = '".$valeur."' ,".$toto." = 'rien' WHERE num = '".$hero."' ";
			//ExecuteRequete($Requete);
			Modif($toto,"rien",$num);	SetJoueur($heros);
		}
?>

<html>
<head><STYLE><? include ("../Controleurs/css.php"); ?></STYLE></head>

<body  width="60%">

	<table class="tabheros" border = 1 borderColor="#000000">
	    <TR align=middle><TD colSpan=2><B><?print $heros["nom"] ?>: <?print $heros["libellerace"]?> - Niveau : <?print $heros["codeexp"] ?></B></TD></TR>
	    <TR>
			<TD align=center width="58%">
				<table>
				<tr><td align=center colSpan=2>	<IMG  src="../image/<?print $heros["image"]?>"  border=0>				</td></tr>
					<tr><td align=center>			<B>Vie: </B><?print $heros["pv2"]?>/<?print $heros["pv"]?>			</td></tr>
					<tr><td>							<? getbarre("barv.jpg",$heros["pv2"],$heros["pv"]); ?>				</td></tr>
					<tr><td align=center>			<B>Magie: </B><?print $heros["pm"]?>/<?print $heros["pm2"]?>		</td></tr>
					<tr><td>							<? getbarre("barb.jpg",$heros["pm2"],$heros["pm"]); ?>				</td></tr>
				</table>
			</TD>
	        <TD>
	            <TABLE>
					<TR>
		                <TD  colSpan=2 align=center width="50%"><B>Experience:		</B></TD>
						<TD  colSpan=2 align=center width="50%"><?print $heros["exp"]?>   </TD>
					</TR>
								<TR><TD td colSpan=4 ><BR></TD></TR>
					<TR>
		                <TD align=left width="50%"><B>Force: 				</B></TD>
		                <TD align=left width="50%"><?print $heros["forc"] ;?> 		</TD>
						<TD align=left width="50%"><B>Dexterit�:			</B></TD>
		                <TD align=left width="50%"><?print $heros["dext"] ;?>      </TD>
					</TR>
		            <TR>
		                <TD align=left width="50%"><B>Intelligence:			</B></TD>
						<TD align=left width="50%"><?print $heros["inti"] ;?>       </TD>
		                <TD align=left width="50%"><B>Charisme:				</B></TD>
						<TD align=left width="50%"><?print $heros["cha"];?>       </TD>
					</TR>
		            <TR>
		                <TD align=left width="50%"><B>Vitesse:				</B></TD>
		                <TD align=left width="50%"><?print $heros["vit"] ;?> 		</TD>
						<TD align=left width="50%"><B>Endurance:			</B></TD>
		                <TD align=left width="50%"><?print $heros["end"] ;?> 		</TD>
					</TR>
					<TR>
						<TD align=left width="50%"><B>Attaque:				</B></TD>
						<TD align=left width="50%"><?print $attaque;?> 			</TD> 
						<TD align=left width="50%"><B>Defense:				</B></TD>
						<TD align=left width="50%"><?print $defence;?> 			</TD>
					</TR>
								<TR><TD td colSpan=4 ><BR></TD></TR>
		            <TR>
		                <TD colSpan=2 align=center width="50%"><B>Maniment des armes:</B></TD>
						<TD colSpan=2 align=center width="50%"><?print $heros["man"];?>	</TD>
					</TR>
					<TR>
		                <TD colSpan=2 align=center width="50%"><B>Puissance magique:</B></TD>
						<TD colSpan=2 align=center width="50%"><?print $heros["ppm"];?>   </TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
	</table>
	
	<BR>
         
	<TABLE  class="tabheros"  borderColor=#000000>
	    <TR><TD colSpan=2 align=middle><B>Equipement</B></TD></TR>     
	    <TR>
			<TD align=center width="50%"><B>Arme:	</B><?print $heros["Arme"] ;?>	</TD>
			<TD align=center width="50%"><A href="?var=Arme">D�s�quip�</A>		</TD>
		</TR>
		<TR>
			<TD align=center width="50%"><B>Bouclier:	</B><?print $heros["Bouclier"];?>	</TD>
			<TD align=center width="50%"><A href="?var=Bouclier">D�s�quip�</A>		</TD>
		</TR>
		<TR>
			<TD align=center width="50%"><B>Casque:	</B><?print $heros["Casque"];?>	</TD>
			<TD align=center width="50%"><A href="?var=Casque">D�s�quip�</A>		</TD>
		</TR>
	    <TR>
			<TD align=center width="50%"><B>Plastron:	</B><?print $heros["Plastron"];?>	</TD>
			<TD align=center width="50%"><A href="?var=Plastron">D�s�quip�</A>		</TD>
		</TR>
		<TR>
			<TD align=center width="50%"><B>AvantBras:	</B><?print $heros["AvantBras"];?>	</TD>
			<TD align=center width="50%"><A href="?var=AvantBras">D�s�quip�</A>		</TD>
		</TR>
		<TR>
			<TD align=center width="50%"><B>Botte:	</B><?print $heros["Botte"] 	;?>	</TD>
			<TD align=center width="50%"><A href="?var=Botte">D�s�quip�</A>		</TD>
		</TR>
	    <TR>
			<TD align=center width="50%"><B>Jambi�re:	</B><?print $heros["Jambiere"] ;?>	</TD>
			<TD align=center width="50%"><A href="?var=Jambiere">D�s�quip�</A>		</TD>
		</TR>
	</TABLE>
		
				
		

           
</body></html>