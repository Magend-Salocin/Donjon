<?php 
include ("../Controleurs/ControleurCombat.php"); 
include ("../Controleurs/ControleurMenu.php"); 

$heros=$_SESSION["tab"];	$num=time();

if(isset($_GET['adversaire'])){	if ($heros['NbCombatDay']<60) {	SetDefis($num,$_GET['adversaire'],$heros["num"],$heros["village"]); }		}

?>
<html>
  <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580"  bgcolor="#FFFFFF">
    <tr>
      <td align="center">
		  <a href="?id=test6">Mes d�fis</a> || 
		  <a href="?id=test6&var=enligne">D�fier un h�ros du village</a> || 
		  <a href="/index.php?page=combat&choix=3">Classement</a> || 
		  <a href="/index.php?page=combat&choix=5">Historique</a>
	  </td>
    </tr>
    <tr>
      <td align="center" width="74%" style="padding: 5px; " bordercolor="#FFFFFF">
         Vous avez gagn� <b><?php echo $heros["nbVictoire"];?></b> combats sur <b><?php echo $heros["nbCombat"];?></b> effectu�s<br /><br />
		Aujourd'hui vous avez particip� � <b><?php echo $heros["NbCombatDay"];?></b>/60 combats
	  </td>
    </tr>
   </table>
   <?php 	if (isset ($_GET['var'])){ 
			if ($_GET['var']=="enligne"){ include ("enligne.php"); }
			if ($_GET['var']=="combat") { include ("moduleCombat.php"); }
		}
		else { include ("adv.php"); }
   ?>  
  
	
   

</body>
</html>