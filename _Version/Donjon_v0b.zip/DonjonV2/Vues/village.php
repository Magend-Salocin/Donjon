<?php php 
	include ("../MesFonctions.php");
	include ("../Controleurs/ControleurMenu.php");	include ("../Controleurs/ControleurVillage.php");
	$HeureActuelle=time();							$_SESSION["time"]=$HeureActuelle;	
?>

<html>
<head><STYLE><?php php  include ("../Controleurs/css.php"); ?></STYLE></head>

<body>

	<center><img src="../image/carte/<?php php  echo $_SESSION["village"] ; ?>.jpg"  usemap="#zonesClic" ></center>
	<map name="zonesClic">	<?php php  GetAfficheVillage($_SESSION["village"]);?>	</map> 
    
</body></html>