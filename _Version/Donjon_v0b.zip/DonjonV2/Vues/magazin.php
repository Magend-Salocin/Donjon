<?php 	include ("../Controleurs/ControleurMagazin.php");	?>
<body> 
	
	<img src="../image/village/<?php echo $_SESSION["village"];?>.jpg"  usemap="#zonesClic" >
	<map name="zonesClic">	<?php 	GetAfficheMagazin($_SESSION["village"]);?>		</map> 
	
</body></html>