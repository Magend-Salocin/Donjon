<?php session_start();?>
<html>

<link rel="stylesheet" 			href="../Controleurs/cssGeneral.css" type="text/css" />
<script type="text/javascript" src="../Javascript/menu.js"></script>
<?php 	require ("../Secret/connect.php");	?>
<body>

	<div class="menu-general" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');">
	Etat Personnage
	</div> 
	<ul id="sous-menu1" class="habillage" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');"> 
	    <li><a href="?id=test">Etat Personnage</a></li> 
	    <li><a href="?id=test2">Inventaire</a></li> 
	    <li><a href="?id=test3&msg=msgall">Messagerie</a></li> 
	</ul>

	<div class="menu-general"><a href="?id=test4">Village</a></div>
	
	<div class="menu-general"><a href="?id=test5">Voyager</a></div>
	
	<div class="menu-general"><a href="?id=test6">Defis</a></div>
	
	<div class="menu-general"><a href="?id=test7">Aventure</a></div>

	
<br><br>

	<div><?php 
		if (isset($_GET['id'])){
			switch ($_GET['id']){
			
			case "test":	include ("EtatHero.php");		break;
			case "test2":	include ("inventaire.php");		break;
			case "test3":	include ("Messagerie.php");		break;
			case "test4":	include ("magazin.php");		break;
			case "test5":	include ("village.php");		break;
			case "test6":	include ("defis.php");			break;
			case "test7":	include ("aventure.php");			break;			
			
		
			}
		}

		else{ echo"Page d erreur";}
	?></div>


</body>
</html>