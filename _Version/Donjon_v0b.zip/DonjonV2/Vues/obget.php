<?php session_start();
require	("../Secret/connect.php");
include ("../Controleurs/ControleurMenu.php");
include ("../Controleurs/ControleurMagazin.php");
include ("../Controleurs/ControleurObjet.php");
include ("../Controleurs/ControleurInventaire.php");
include ("../MesFonctions.php");	

	$HeureActuelle=time();	$_SESSION["time"]=$HeureActuelle;

	if ( isset($_GET['magazin']) ){ $Controleur=GetLeMagazin($_SESSION["village"],$_GET['magazin']);}
	
	
	if ($Controleur==true){
	 if ( isset($_GET['item']) ){ GetAcheter($_GET['item'],$_SESSION["ors"],$_SESSION["num"],$_GET['magazin']); }
		$LesObjets=GetLesObjet($_GET['magazin']);

	
?>
<body> 
	<table border="1" width='100%'><tr>
	<td width='40%' align="center"><img width="40%" src="../image/08.JPG"></td>
	<td width='60%' align="justify">Bienvenue dans mon �chope alors une ptit �p�e?</td>
	</tr></table>
	<br><br>
	
	<center><IMG  width='95%' align="center" src='../image/Menu01.jpg' ></center>
    <TABLE  background='../image/Menu02.jpg' width="95%" align="center">
		<TR><TD colSpan="2" align="center"><br><H3 class="gris">La liste des objet du magazin</H3></TD></TR>
		<TR>	
			<TD colSpan="2" align="center">
				<?php  while($row=GetLigne($LesObjets))	{	
				echo " <table  background='../image/MenuB.jpg' width='94%'>
						<TR><TD width='20%' >
								<br><br>";
								if($row[8]==""){$row[8]="01.jpg";}
								echo"<center><IMG  width='60%' src='../image/inventaire/$row[8]'></center></a>
							</TD>
							<TD>
							<table>
							<TR><TD width='90%' align=center><b>$row[0]<b></TD><TD></TD></TR>
							<TR><TD width='90%'><b><hr color=#FF0033></hr><b></TD><TD></TD></TR>
							<TR><TD width='90%'><p align='justify'>$row[1]</p></TD><TD></TD></TR>
							</table>
							</TD>
						</TR>
					    <TR align=middle><TD colSpan=2>
							<B>Prix:</B>
							<a href='obget.php?item=$row[6]&magazin=$row[7]' onClick ='reload()'> 
							Pi�ce d'or: <b>$row[5]</b>  </a> 
							&nbsp&nbsp&nbsp&nbsp Stock:: $row[4] <br><br>
								
						</TD></TR>
						</table><br>";	
				}?>
			</TD>
		</TR>
		<TR><TD colSpan="2" align="center"><a href='magazin.php' target='cadreDroite' >
		<H3 class="gris">Retour au Village</H3>
		</a></TD></TR>
	</TABLE>
	<center><IMG  width='95%' align="center" src='../image/Menu03.jpg' ></center>
	
</body></html><?php }?>