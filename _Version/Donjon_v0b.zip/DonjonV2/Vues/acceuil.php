<?php session_start();
require ("../Secret/connect.php");	

include ("../MesFonctions.php");								include ("../Controleurs/ControleurMenu.php");  
include ("../Controleurs/ControleurAventure.php");				include ("../Controleurs/ControleurGrade.php"); 
include ("../Controleurs/ControleurOutil.php");  				include ("../Controleurs/ControleurVillage.php");

 

$Nivsup=false;	
	
	if ( isset($_GET['passage']) ){//V�rifie les identifiant de connection d'un utilisateur
			$Tuple=GetAuth($_GET['nom'],$_GET['mdp']);
			SetJoueur($Tuple);	Modif("Enligne",$HeureActuelle,$_SESSION["num"]);
	}
	
	if ( isset($_POST['finaventure'])  ) {//Permet de finir les mission quand le temps est �coul� 
		$goavan = $_POST['finaventure']; 
		SetFinMission($_POST['aventure'],$heros["num"]); 
		DelAventure($heros["num"]);
	}	else { $goavan =0; }
	
	if ( isset($_POST['finvoyage']) ) { //Permet de finir le voyage quand le temps est �coul�
		$goavan = $_POST['finvoyage']; 
		Modif("village",$_POST['village'],$heros["num"]); $_SESSION["village"]=$_POST['village'];
		DelAventure($heros["num"]);
	}	else { $govillage =0; }
	
	if(isset($_SESSION["num"])) { 
		$Auth=1; $heros=$_SESSION["tab"]; 	$exp=$heros["exp"];	 $nivsuv=$heros["nivsuv"];
		
		if($heros["codeexp"] > 1){ 
			$moy=$heros["nivsuv"] /3;	
			$exp=$heros["exp"]-$moy;	
			$nivsuv=$heros["nivsuv"]-$moy; 
		}
		
		if($heros["exp"]==$heros["nivsuv"]  || $heros["exp"] > $heros["nivsuv"] ){ //Permet de d�finir le niveau suivant
			if($heros["cexp"] ==0){
			Modif("cexp",1,$heros["num"]); 	Modif("nbexp",5,$heros["num"]); 
			$_SESSION["cexp"]=1;			 $_SESSION["nbexp"]=5; 
			$Nivsup=true;
			}
		}
		
		if ( isset($_GET['village']) && $goavan==0) 
		{ $dateAventure=time();	aventureRec($heros["num"],$_GET['village'],$dateAventure,"V"); }
		if ( isset($_GET['mission']) && $goavan==0) 
		{ $dateAventure=time();	aventureRec($heros["num"],$_GET['mission'],$dateAventure,"A");}
	}	
	else{ $Auth=0; }

	
	
	

?>

<html>
<title>Bienvenue Donjon Projet</title>
<meta name="author"  			content="Berger Nicolas">
<meta name="description" 		content="Donjon Projet">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<body width="100%">

	


<?php if($Auth==1) {?>
<table  border="1" width="100%"><tr><td width="33%">

	<table border="1" width="100%" >
	    <tr><td colSpan="2" align="center"><B>Etat de votre h�ro				           </B></td></tr>
		<tr><td align="center" width="50%">	Heros  :     <B><?php print $heros["nom"] ?>	   </B></td>
		    <td align="center" width="50%">	Niveau :     <B><?php print $heros["codeexp"] ?>   </B></td></tr>
		<tr><td align="center" width="50%">	Pi�ces d'or: <B><?php print $heros["ors"] ?>	   </B></td>
			<td align="center" width="50%">	Exp�rience : <B><?php print $heros["exp"] ?>	   </B></td></tr>
	
		<tr><td>			Prochain niveau:				</td>
		<td><?php 			getbarre2("barv.jpg",$exp,$nivsuv); ?>				</td></tr>
		
		
		<?php if($Nivsup==true ){
		echo"<tr><td align=center><a href='HNS.PHP' target='cadreDroite'>Niveau sup�rieur</a></td></tr>";}
		
		?></table></td><td>	<table border="0" width="100%" ><tr><td><?php 
		//BLOC DE VERIFICATION SI UNE AVENTURE OU UN VOYAGE ETAIT EN COUR POUR LE CONTINUER
	
		$encour=GetAventureEnCour($heros["num"]);
			if ($encour!=null){			$datenow=time();	$temps = $datenow - $encour[2];
				
				if ($encour[3]=="A"){
					$T=GetMissionAventure($encour[0]); 	$timer=$T[5]-$temps;
					if ($timer < 0)	{SetFinMission($encour[0],$heros["num"]);}
					else 			{timer($timer); $_GET['mission']=$encour[0]; 	$goavan=1; }
				}
				if ($encour[3]=="V"){
					$VIL=GetVoyage($heros["village"],$encour[0]);	 $timer=$VIL[0]-$temps;
					if ($timer < 0)	{Modif("village",$encour[0],$heros["num"]); $heros["village"]=$encour[0];}
					else 			{timer2($timer); $_GET['village2']=$encour[0];  $goavan=1; }
				}
			}
		//}
		?>
	</td></tr></table></td></tr></table>
  <?php }?>









	<?php  if ( isset($_GET['mission']) || isset($encour[3]) ) {
	if ($encour[3]=="A") { $FA=$encour[0];} else  { $FA=$_GET['mission'];}
	//if ( isset($_GET['mission'])) { $FA=$_GET['mission'];} else { $FA=$encour[0];}
	
	echo"<form method='POST' action='' name='aventure' >
		<input type='hidden' name='aventure' value='$FA' >
		<input type='hidden' name='finaventure' value='1' >	
	</form>";
	 } ?>
	<?php if ( isset($_GET['village']) || isset($encour[3]) ){ if ($encour[3]=="V") { ?>
	<form method="POST" action="" name="voyage" >
		<input type="hidden" name="village" 	value="<?php  if ( isset($_GET['village'])) { echo $_GET['village'];} else { echo  $encour[0];} ?>" >
		<input type="hidden" name="finvoyage" value="1" >	
	</form>
	<?php  }} ?>


</body></html>
