<?php session_start();
require ("../Secret/connect.php");	

include ("../MesFonctions.php");								include ("../Controleurs/ControleurMenu.php");  
include ("../Controleurs/ControleurAventure.php");				include ("../Controleurs/ControleurGrade.php"); 
include ("../Controleurs/ControleurOutil.php");  				include ("../Controleurs/ControleurVillage.php");

	
	
	if ( isset($_GET['passage']) ){//V�rifie les identifiant de connection d'un utilisateur
			$Tuple=GetAuth($_GET['nom'],$_GET['mdp']);	SetJoueur($Tuple);
	}
	
	if(isset($_SESSION["num"])) { 
		$Auth=1; $heros=$_SESSION["tab"]; 
		if($heros["codeexp"] > 1)
		{ $moy=$heros["nivsuv"] /3;	$exp=$heros["exp"]-$moy;	$nivsuv=$heros["nivsuv"]-$moy; }
		else{ $exp=$heros["exp"]; $nivsuv=$heros["nivsuv"]; }
	}	
	else{ $Auth=0; }

	if ( isset($_POST['finaventure'])  ) {//Permet de finir les mission quand le temps est �coul� 
		$goavan = $_POST['finaventure']; 
		SetFinMission($_POST['aventure'],$heros["num"]); 
		DelAventure($heros["num"]);
	}	else { $goavan =0; }
	
	if ( isset($_POST['finvoyage']) ) { //Permet de finir le voyage quand le temps est �coul�
		$goavan = $_POST['finvoyage']; 
		Modif("village",$_POST['village'],$heros["num"]); 
		echo $heros["village"]=$_POST['village']; SetJoueur($heros);
		DelAventure($heros["num"]);
		
	}	else { $goavan =0; }
	
	if ( isset($_GET['village']) && $goavan==0) 
		{ $dateAventure=time();	aventureRec($heros["num"],$_GET['village'],$dateAventure,"V"); }
	if ( isset($_GET['mission']) && $goavan==0) 
		{ $dateAventure=time();	aventureRec($heros["num"],$_GET['mission'],$dateAventure,"A");}
	
	

?>

<html>
<title>Bienvenue Donjon Projet</title>
<meta name="author"  			content="Berger Nicolas">
<meta name="description" 		content="Donjon Projet">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" 			href="../Controleurs/cssGeneral.css" type="text/css" />
<head>
<script type="text/javascript" src="menu.js"></script>
</head>
<body width="20%">

<a href="principale.html" target="cadreDroite">
<img alt="Retour � la page d'accueil" width="100%" border="0" src="../image/03.jpg"><br></a>

<br>
<hr color=#FF0033></hr>
	<?php if($Auth==0) {?>
	<form method="GET" action="" name="connect" >
		<br>Nom d utilisateur	<input type="text" 		name="nom" 		size="20">
		<br>Mot de passe     	<input type="password" 	name="mdp"  	value="">
								<input type="hidden" 	name="passage"  value='1'>
		<br>					<input type="button" 	name="valider" 	value="connecter" onClick ="test()">
	</form>
	<form method="POST" action="EtatHero.php" name="page" target="cadreDroite">
	
	
	<?php }else {?>	
	<table>
	    <tr><td align=center><B>Etat de votre h�ro						       	</B></td></tr>
		<tr><td>			Heros : 		<B><?php print $heros["nom"] ?>	  		</B></td></tr>
		<tr><td>			Pi�ces d'or: 	<B><?php print $heros["ors"] ?>	   		</B></td></tr>
		<tr><td>			Niveau : 		<B><?php print $heros["codeexp"] ?> 	</B></td></tr>
		<tr><td>			Exp�rience : 	<B><?php print $heros["exp"] ?>	   		</B></td></tr>
		<tr><td>			Prochain niveau:								    </td></tr>
		<tr><td>			<?php getbarre2("barv.jpg",$exp,$nivsuv); ?>			</td></tr>
		
		<?php //Permet de d�finir le niveau suivant
		if($heros["exp"]==$heros["nivsuv"]  || $heros["exp"] > $heros["nivsuv"] ){
		if($heros["cexp"] ==0)
		{Modif("cexp",1,$heros["num"]);Modif("nbexp",5,$heros["num"]);$_SESSION["cexp"]=1;$_SESSION["nbexp"]=5;}
		echo"<tr><td align=center><a href='HNS.PHP' target='cadreDroite'>Niveau sup�rieur</a></td></tr>";
		}
		
		//BLOC DE VERIFICATION SI UNE AVENTURE OU UN VOYAGE ETAIT EN COUR POUR LE CONTINUER
		$encour=GetAventureEnCour($heros["num"]);
			if ($encour!=null){			$datenow=time();	$temps = $datenow - $encour[2];
				
				if ($encour[3]=="A"){
					$T=GetMissionAventure($encour[0]); 	$timer=$T[5]-$temps;
					if ($timer < 0)	{SetFinMission($encour[0],$heros["num"]);}
					else 			{timer($timer); $_GET['mission']=$encour[0]; 	$goavan=1; }
				}
				if ($encour[3]=="V"){
					$VIL=GetVoyage($heros["village"],$encour[0]);	 $timer=$VIL[0]-$temps;
					if ($timer < 0)	{Modif("village",$encour[0],$heros["num"]); $heros["village"]=$encour[0];}
					else 			{timer2($timer); $_GET['village']=$encour[0];  $goavan=1; }
				}
			}
		
		?>
	</table>
  <?php }?>

<hr color=#FF0033></hr>
<div class="menu-general" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');">Menu 1</div> <!-- idem menu sans habillage -->
<ul id="sous-menu1" class="habillage" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');"> <!-- idem menu sans habillage -->
    <li><a href="#">Sous-menu1 1</a></li> <!-- idem menu sans habillage -->
    <li><a href="#">Sous-menu1 2</a></li> <!-- idem menu sans habillage -->
    <li><a href="#">Sous-menu1 3</a></li> <!-- idem menu sans habillage -->
</ul>


<div class="menu-general" onmouseover="montre('sous-menu2');" onmouseout="cache('sous-menu2');">Menu 2</div> <!-- idem pr�c�dent -->
<ul id="sous-menu2" class="habillage" onmouseover="montre('sous-menu2');" onmouseout="cache('sous-menu2');">
    <li><a href="#">Sous-menu2 1</a></li>
    <li><a href="#">Sous-menu2 2</a></li>
    <li><a href="#">Sous-menu2 3</a></li>
</ul>


<div class="menu-general"onmouseover="montre('sous-menu3');" onmouseout="cache('sous-menu3');">Menu 3</div> <!-- idem pr�c�dent -->
<ul id="sous-menu3" class="habillage" onmouseover="montre('sous-menu3');" onmouseout="cache('sous-menu3');">
    <li><a href="#">Sous-menu3 1</a></li>
    <li><a href="#">Sous-menu3 2</a></li>
    <li><a href="#">Sous-menu3 3</a></li>
</ul>
<br><font color=#FF0033><b><u>Menu</b></u><br><ul>
<?php if(isset($heros["num"])) { ?>

	<li><a  href="../Controleurs/deco.php" >Deconnextion 							      </a></li>
	<br><br><li><a  href='EtatHero.php' 	target="cadreDroite">Etat du personnage 	  </a></li>
	<br><br><li><a  href='inventaire.php'  	target="cadreDroite">Inventaire				  </a></li>
	<br><br><li><a  href='aventure.php' 	target="cadreDroite">Aventure 				  </a></li>
	<br><br><li><a  href='magazin.php' 	    target="cadreDroite">Village 				  </a></li>
	<br><br><li><a  href='village.php'  	target="cadreDroite">Voyager 				  </a></li>
	<br><br><li><a  href='defis.php'  		target="cadreDroite">Vos d�fis dans ce village</a></li>
	<br><br><li><a  href='menutest.php?msg=msgall'  		target="cadreDroite">Message</a></li>
<?php  } else { ?>
	<br><br><li><a href="inscription.php" 	target="cadreDroite">Inscription			  </a></li>


	<?php } 
	
	if ( isset($_GET['mission']) || isset($encour[3]) ) {
		if ($encour[3]=="A") { $FA=$encour[0];}
		if ( isset($_GET['mission'])) { $FA=$_GET['mission'];}		
		echo"<form method='POST' action='' name='aventure' ><input type='hidden' name='aventure' value='$FA' >
		<input type='hidden' name='finaventure' value='1' ></form>";
	} 
	 
	if ( isset($_GET['village']) || isset($encour[3]) ){
		if ($encour[3]=="V") { $FA=$encour[0];} else  { $FA=$_GET['village'];}
		echo"<form method='POST' action='' name='voyage' ><input type='hidden' name='village' value='$FA' >
		<input type='hidden' name='finvoyage' value='1' ></form>";
	}
	 
	
	 ?>
	

	
</body></html>