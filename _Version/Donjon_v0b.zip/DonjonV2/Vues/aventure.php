<?php 
include ("../Controleurs/ControleurAventure.php"); 
include ("../Controleurs/ControleurMenu.php");  
include ("../Controleurs/ControleurGrade.php"); 
 $HeureActuelle=time();	$_SESSION["time"]=$HeureActuelle;
 $codeheros=$_SESSION["num"]; 		$librang=$_SESSION["libellerang"]; 	$codevillage=$_SESSION["village"];
 
			$codeRang=GetGrade($librang);					$fatiguer=GetCapable($codeheros);
	
 ?>   

<html>
<head><STYLE><?php  include ("../Controleurs/css.php"); ?></STYLE></head>
<body >


	<TABLE class="tabAventure" border = 1  align=center>
        <TR align=middle><TD colSpan=2 >Ton grade actuel est <B><?php echo $librang;?></B></TD></TR>
		<?php  GetAfficheGrade($librang,$codeheros) ?>         
	</TABLE> 
	  
	<br>
	 
	<center><IMG  width="74%"  align="center" src="../image/Menu01.jpg" ></center>
    <TABLE  background="../image/Menu02.jpg" width="74%" align="center">
		<TR><TD  align="center"><H3 class="gris">La liste des aventures</H3></TD></TR>
		<TR>	
			<TD   align="center">
			    <?php //requete pour retourner le rang de mission � afficher
					$codeRang=$codeRang+1;	$LesAventure=GetAventure($codeRang,$codevillage);
					while($row=GetLigne($LesAventure))	{	
					echo " <table  background='../image/MenuA.jpg' width='94%'>
							<TR><TD  width='20%' align=center><br><br>";
					if( $row['rang'] > $fatiguer )
						{echo"<IMG  width='60%' src='../image/$row[7]' alt='Fatiguer'>";}
					else
						{echo"<a href='acceuil.php?mission=$row[0]' target='cadreGauche' >
						<IMG  width='60%' src='../image/$row[7]'></a>";}
						echo"   </TD>
								<TD>
								<table>
								<TR><TD width='90%' align=center><b>$row[1]<b></TD><TD></TD></TR>
								<TR><TD width='90%'><b><hr color=#FF0033></hr><b></TD><TD></TD></TR>
								<TR><TD width='90%'><p align='justify'>$row[2]</p></TD><TD></TD></TR>
								</table>
								</TD>
							</TR>
						    <TR align=middle><TD colSpan=2 height=30>
							<font color='blue'><B>Rapporte Pi�ce d'or: $row[3] et Experience: $row[4] 
							</B></font>
							</TD></TR>
							 </table><br>"; 	
					
					}
				?>
			</TD>
		</TR>
	</TABLE>
	<center><IMG  width="74%" align="center" src="../image/Menu03.jpg" ></center>
	
</body></html>