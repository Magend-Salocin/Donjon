<?php php
	function GetLesObjet($village){
		$LesMagazins="SELECT libelle , resumer , effet , valeur , nb , prix , num , magazin , image
		FROM objetproposer , objet WHERE magazin = '".$village."' and num=objet  ";
		return ExecuteRequete($LesMagazins);
	}
	
	function GetObjet($num){
		$Objet="SELECT * FROM  objet WHERE num = '".$num."'";
		return GetLigne(ExecuteRequete($Objet));
	}
	
	function GetObjetName($libelle){
		$Objet="SELECT * FROM  objet WHERE libelle = '".$libelle."'";
		return GetLigne(ExecuteRequete($Objet));
	}
	
	
	function GetObjetMagazin($item,$magazin){
		$Objet="SELECT * FROM objetproposer,objet WHERE num='".$item."' and magazin='".$magazin."' and num=objet ";
		return GetLigne(ExecuteRequete($Objet));
	}
		
	function GetAcheter($item,$ors,$heros,$magazin){
	
		$row=GetObjetMagazin($item,$magazin);
		if($ors < $row['prix'])	{ print "Vous n'avez pas assez d'or"; }
		else					{ print "Vous venez d'acquerir l'objet selectionner";
			
			$nb=GetPossedeObjet($item,$heros); 
			if($nb!=0)		{ AjoutObjet($heros,$item,$nb); }
			else 			{ CreeObjet($heros,$item,$nb);  }
			$ors= $ors - $row['prix'];
			Modif("ors",$ors,$heros);	$_SESSION["ors"] = $ors;
			if($row['nb']!=1) {UpStock($magazin,$item,$row['nb']);}
			else {DelStock($magazin,$item);}
		}	
	}
	
	function UpStock($magazin,$item,$nb){
		$nb = $nb - 1;
		$sql = "UPDATE objetproposer  SET nb = '".$nb."' WHERE magazin ='".$magazin."' AND objet='".$item."'"; 
		ExecuteRequete($sql);
	}
	
	function DelStock($magazin,$item){
		$sql = "DELETE FROM objetproposer  WHERE magazin ='".$magazin."' AND objet='".$item."'"; 
		ExecuteRequete($sql);
	}
	
	
?>