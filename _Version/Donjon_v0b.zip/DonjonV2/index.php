<html>
<head><title>Donjon projet </title></head>

<!-- divise la page en 2 parties une parties sera fixe (� gauche) l autre affichera la page voulu
<frameset  cols="23%,*" border="1" bordercolor="blue">
<frame noresize scrolling="no" src="Vues\acceuil.php" name="cadreGauche">
<frame noresize scrolling="yes" src="Vues\principale.html" name="cadreDroite">
</frameset>
 -->

<frameset rows="20,80" cols="*" framepadding="0" framespacing="0" frameborder="NO" border="0">
	<frame src="Vues/acceuil.php"     name="cadreGauche" scrolling="NO" frameborder="no">
	<frame src="Vues/Menu.php"  name="cadreDroite" scrolling="yes" frameborder="no" >
</frameset>

<noframes><body>Votre navigateur ne gere pas les frames !</body></noframes>

</html>