<?php 
	function GetMagazin($village){
		$LesMagazins="SELECT * FROM magazin WHERE  village = '".$village."' ";
		return ExecuteRequete($LesMagazins);
	}
	
	function GetLeMagazin($village,$magazin){
		$LeMagazin="SELECT code FROM magazin WHERE  village = '".$village."' and code = '".$magazin."'";
		$LeMagazin=GetLigne(ExecuteRequete($LeMagazin));
		return $LeMagazin[0]==$magazin;
	}

	function GetAfficheMagazin($village){
	$LesMagazin=GetMagazin($village);
		while($row=GetLigne($LesMagazin)){
		echo " <area shape='rect' coords='$row[2],$row[3],$row[4],$row[5]'  href='$row[7]' alt='$row[1]'  target='cadreDroite'>";
		if ($row[7]=="taverne.php"){$_SESSION["NomTaverne"]=$row[1];}
		}
	}
	
	/*
	function GetAfficheMagazin($village){
	$LesMagazin=GetMagazin($village);
		while($row=GetLigne($LesMagazin)){
			print"<form method='POST' action='MouvDecorMag.php' name='$row[7]'>
					<input type='hidden' name='code' value='$row[0]' >	
				  </form>";
		}
	}
	*/
?>