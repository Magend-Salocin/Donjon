<?php 
session_start();
session_destroy();
?>
<script language='javascript'>parent.cadreDroite.location.replace('../Vues/principale.html');</script>
<script language='javascript'>window.location.replace('../Vues/acceuil.php');</script>
