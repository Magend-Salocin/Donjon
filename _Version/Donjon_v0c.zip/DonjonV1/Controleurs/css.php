
	.tabover
	{
	background-color:blue; cursor:pointer; color:white; font-weight:bold;
	TEXT-ALIGN: center;
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; PADDING-TOP: 0px;
	FONT-SIZE: 10px ; FONT-FAMILY: Tahoma,sans-serif; color: black;
	}
	
	.tabheros{
	BORDER-RIGHT	: 1px solid; 
	BORDER-TOP		: 1px solid; 
	BACKGROUND		: #ececec; 
	BORDER-LEFT		: 1px solid; 
	WIDTH			: 98%; 
	BORDER-BOTTOM	: 1px solid; 
	TEXT-ALIGN		: left  ;
	borderColor		: #000000;
	}
	
	.tabAventure{
	BORDER-RIGHT: 1px solid; 
	BORDER-TOP: 1px solid; 
	BACKGROUND: #ececec; 
	BORDER-LEFT: 1px solid; 
	WIDTH: 90%; 
	BORDER-BOTTOM: 1px solid; 
	TEXT-ALIGN: left
	}
	
	.td{
	TEXT-ALIGN: center;
	FONT-SIZE: 13px ; 
	FONT-FAMILY: script; 

	
	PADDING-RIGHT: 0px; 
	PADDING-LEFT: 0px; 
	PADDING-BOTTOM: 0px; 
	PADDING-TOP: 0px;	
	}