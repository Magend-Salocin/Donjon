<?php 
	function GetRace(){
		$UneRace="SELECT code , libelle FROM race";
		return ExecuteRequete ($UneRace);
	}

	function GetInfoRace($idrace){
		$UneRaceInfo="SELECT * FROM race WHERE code ='".$idrace."'";
		return GetLigne(ExecuteRequete ($UneRaceInfo));
	}
?>