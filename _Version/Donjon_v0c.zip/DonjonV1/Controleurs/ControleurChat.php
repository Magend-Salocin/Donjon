<?php 
	Function OpenFichier(){
	
		$village="../Module/Chatte/" . $_SESSION["village"].".txt";
		$monfichier =fopen($village,"r+");
	return $monfichier ;
	}
	
	
	Function DelFichier(){
		$village="../Module/Chatte/" . $_SESSION["village"].".txt";
		$monfichier =fopen($village,"w+");
		fclose($monfichier); 
	}
	
	
	Function GetAllMessage(){
		//AFFICHAGE DES DONNEES 
		$monfichier =OpenFichier();
		echo "<select size='15' width='100' name='race'> ";
		echo '<OPTION> ------------Forum-----de-------la------taverne-------</OPTION><OPTION>  </OPTION>';
			while ($ligne= fgets($monfichier)){
				$text = split(";",$ligne); 	$long = strlen($text[1]);
				
				echo '<OPTION><b>' .$text[0]. '</b> a �crit :</OPTION>';
		
				if ($long<28){ echo '<OPTION>' .$text[1]. '</OPTION><OPTION>  </OPTION>'; }
				else{ 
					while ($long>28){
					echo '<OPTION>' .substr($text[1] ,$long,28). '</OPTION><OPTION> %%% </OPTION>';
					$long=$long-28;
					}
					echo '<OPTION>' .substr($text[1] ,$long,$long). '</OPTION><OPTION>  </OPTION>';
				}
			}	
		echo "</select> ";
		fclose($monfichier);
	}
	
	
	Function SetMessage($pseudo,$message){
		
		//ECRITURE DES VALEURS DANS UN TABLEAU
		$monfichier =OpenFichier();$i=0;
		while ($ligne= fgets($monfichier)){ 
			$row[$i]=$ligne; $i++; 
			}
		fclose($monfichier);
		
		//EFFACEMENT DU FICHIER 
		DelFichier(); 
		
		//ECRITURE DU TABLEAU DANS LE FICHIERS
			$monfichier =OpenFichier();
			$pop=$pseudo.';'.$message;	$i=0;
			fputs($monfichier,$pop);fputs($monfichier,"\n"); 
			while ($i<9){ 
			fputs($monfichier,$row[$i]);	$i++; 
			}
		fclose($monfichier);
	}
?>