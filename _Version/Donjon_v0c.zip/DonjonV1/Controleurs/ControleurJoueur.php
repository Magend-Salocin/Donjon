<?php 
	function SetJoueur($mail,$nom,$mdp,$idrace){

	$race=GetInfoRace($idrace);
	$Num= date("his");
	$UnJoueur="insert into joueur  values ('".$Num."','".$mail."','".$nom."','".$mdp."','".$nom."','".$race['r_pv']."','".$race['r_pv']."','".$race['r_pm']."','".$race['r_pm']."','".$race['r_for']."','".$race['r_end']."','".$race['r_int']."','".$race['r_dext']."','".$race['r_vit']."','".$race['r_cha']."','".$race['r_man']."','".$race['r_ppm']."','0','0','1','150','0','0','".$race['libelle']."','novice','".$race['r_village']."','".$race['r_image']."','0','0','0','0','rien','rien','rien','rien','rien','rien','rien')";
	ExecuteRequete ($UnJoueur);
	
		$LesAventure="SELECT code FROM aventure ";
		$LesAventure = ExecuteRequete($LesAventure);
		
		while($row=GetLigne($LesAventure))	{	
		$Un="insert into accomplir  values ('".$row[0]."','".$Num."','0') ";
		ExecuteRequete ($Un);
		}
	
	}

	function GetNom($nom){
		$MaRequete="SELECT nom FROM joueur WHERE nom= '".$nom."' ";
		$MonRs = GetLigne(ExecuteRequete($MaRequete));
		return $nom==$MonRs['nom'];
	}
	
	function GetMail($email){
		$MaRequete="SELECT email  FROM joueur WHERE email = '".$email."' ";
		$MonRs = GetLigne( ExecuteRequete($MaRequete));
		return $email==$MonRs['email'];
	}

?>
 
