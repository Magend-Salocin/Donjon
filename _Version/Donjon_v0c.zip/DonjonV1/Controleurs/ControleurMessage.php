<?php 
	function SetMessage($A,$DE,$sujet,$contenu){

	$Num= date('his');
	$UnMessage="insert into message  values ('".$Num."','".$A."','".$DE."','".$Num."','".$sujet."','".$contenu."','0') ";
	ExecuteRequete ($UnMessage);
	}

	function GetMessage($code,$nom){
		$MaRequete="SELECT * FROM message WHERE code= '".$code."' AND A= '".$nom."' ";
		$MonRs = ExecuteRequete($MaRequete);
		return  GetLigne($MonRs);
	}
	
	function Modif($num,$nom){	
		$MaRequete="UPDATE message SET lue=1 WHERE code='".$num."' AND A= '".$nom."'";
		ExecuteRequete($MaRequete);
	}
	
	function DelMessage($Id,$nom){
		$sql = "DELETE FROM message  WHERE  code= '".$Id."' AND A= '".$nom."'"; 
		ExecuteRequete($sql);
	}
	
	function GetAllMessage($nom){
		$MaRequete="SELECT * FROM message WHERE A= '".$nom."' ";
		$MaRequete=ExecuteRequete($MaRequete);
		while($row=GetLigne($MaRequete)){
		 echo"  <tr>
			<td width='35'  align='center' valign='top'><img src='../image/msg_int/$row[6].jpg' alt='' /> </td>
			<td width='107' valign='top'>$row[2]</td>
			<td width='170' valign='top'>$row[4]</td>
			<td width='108' valign='top'>$row[3]</td>
			<td width='54'  valign='top'><a href='?msg=msglook&name=$row[0]'>lire</a></td>
		
		   </tr>";
		}
		
	}

?>