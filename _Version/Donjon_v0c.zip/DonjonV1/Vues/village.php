<?php session_start();
require ("../Secret/connect.php");
	include ("../MesFonctions.php");
	include ("../Controleurs/ControleurMenu.php");	include ("../Controleurs/ControleurVillage.php");
	$HeureActuelle=time();							$_SESSION["time"]=$HeureActuelle;	
?>

<html>
<head><STYLE><?php  include ("../Controleurs/css.php"); ?></STYLE></head>

<body>
	<?php  include ("Menu.php"); ?>
	<center><img src="../image/carte/<?php  echo $_SESSION["village"] ; ?>.jpg"  usemap="#zonesClic" ></center>
	<map name="zonesClic">	<?php  GetAfficheVillage($_SESSION["village"]);?>	</map> 
    
</body></html>