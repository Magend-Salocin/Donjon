<?php 	session_start();
	require ("../Secret/connect.php");
	include ("../Controleurs/ControleurAventure.php"); 
	include ("../Controleurs/ControleurMenu.php");  
	include ("../Controleurs/ControleurGrade.php"); 

	$heros=$_SESSION["tab"]; 
 ?>   

<html>
	<head>
		<link rel="stylesheet" 	href="../Controleurs/cssTaverne.css" type="text/css" />
	</head>
<body>
	<?php 
		if (isset ($_GET['var']) ){include ("../Module/jeux/".$_SESSION['village']."/index.php");}
		else { include ("Menu.php"); }
	?>
	<table>
	<tr>
	<td><div id="Contenu"><?php include ("tavernier.php");?><div></td>
	<td><div id="Chate"  ><?php include ("Chat.php");?><div></td>
	</tr>
	<br>
	<tr>
	<td rowspan="2"><div id="Menu" >
		<a href="aventure.php">Aventure</a>
		<a href="defis.php">Defis</a>
		<?php  echo "<a href='../Module/jeux/".$_SESSION['village']."/index.php'>";?>
		Jeux</a>
	<div></td>
	</tr>
	</table>
	
</body>

</html>