<?php  set_time_limit(0);	
	$idheros=$_SESSION["numclient"];	$J2=$_GET['heros'];
	$J1=$_SESSION["tab"];	$J2=GetUtilisateur($J2);
	$esquive=false;		$nb=1;		$stop=false;


	$J1["att"]= $J1['forc'] + $J1['vit'];	$J1["def"]= $J1['dext'] + $J1['end'] ;	
	$J1["att"]= $J1['att']  * 2  ;		 	$J1["def"]= $J1['def']  * 2 ;	
	
	$J2["att"]= $J2['forc'] + $J2['vit'] ;  $J2["def"]= $J2['dext'] + $J2['end'] ;	
	$J2["att"]= $J2['att']  * 2  ;			$J2["def"]= $J2['def']  * 2 ;	$J2["def"]=20;
	

	echo"D�but du combat entre $J1[4] et $J2[4]<br><br>";

	
	while($stop==false)	{
	
		$J1dext=GetDext($J1['dext']);	$J2dext=GetDext($J2['dext']);
	
		if (GetVit($J1['vit']) > GetVit($J2['vit'])){
			$J1A=GetForceD�gat($J1['forc'],$J1['att']);		$J2D=GetDefence($J2["end"],$J2['def']);
			if($J1dext==1){$J1A=$J1A*2;}					if($J2dext==1){$J1A=0;}
						
						$PV=$J1A-$J2D;
			if ($PV>0){	$J2[6]=$J2[6]-$PV; $esquive=false; 
				if($J1dext==1)	{ Affichage(3,$J1[4],$PV,$J2[6],"blue",$nb); }
				else 			{ Affichage(1,$J1[4],$PV,$J2[6],"blue",$nb); }
			}
			else { if($esquive==false){Affichage(2,$J2[4],$PV,$J2[6],"blue",$nb);$esquive=true;}}
		
		}
		else {
			$J2A=GetForceD�gat($J2['forc'],$J2['att']);		$J1D=GetDefence($J1["end"],$J1['def']);
			if($J2dext==1){$J2A=$J2A*2;}					if($J1dext==1){$J2A=0;}
						
						$PV=$J2A-$J1D;
			if ($PV>0){	$J1[6]=$J1[6]-$PV; $esquive=false;	
				if($J2dext==1)	{ Affichage(3,$J2[4],$PV,$J1[6],"red",$nb); }
				else 			{ Affichage(1,$J2[4],$PV,$J1[6],"red",$nb); }
			}
			else { if($esquive==false){Affichage(2,$J1[4],$PV,$J1[6],"red",$nb);$esquive=true;}}
			
		}
		$nb=$nb+1;
		if ($J2[6] < 0 || $J1[6] < 0){$stop=true;}
	}
	Affichage(0,0,0,0,"green",$nb);
	if ($J1[6] < 0) 	{ 		$nb=$nb+1; FinCombatVictory($J2,$nb,false);	  	FinCombatD�faite($J1,true);  }
	else 				{ 		$nb=$nb+1; FinCombatVictory($J1,$nb,true); 	 	FinCombatD�faite($J2,false); } 
	$nb=$nb+1;
	DelDefis($_GET['combat']);
	?> 
	<script LANGUAGE=JavaScript>
       /* var temp=0;
			for (var i=1; i < <?php echo $nb?>; ++i){
				temp=200*i;
				setTimeout('document.getElementById("'+i+'").style.visibility = "visible";',temp);
			}*/
               
    </script>