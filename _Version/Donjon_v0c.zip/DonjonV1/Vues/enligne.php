<?php  $HeureActuelle=time(); $_SESSION["time"]=$HeureActuelle;	Modif("Enligne",$HeureActuelle,$_SESSION["num"]);?>

	<br><br><table border ="1" align='center'>
		<tr><td align="center" colSpan="2">
		<h4><b>Les joueurs en ligne pr�sent dans le village de <?php  echo $_SESSION["village"]; ?></b></h4>
		</td></tr>
		<tr>
		<td align="center">
			<b style="color:#FF0000;">Rouge  pour les novices		</b><br />
			<b style="color:#9100C7;">Violet pour les Aventuriers	</b><br />
		</td>
		<td align="center">
			<b style="color:#0000FF;">Bleu pour les legends			</b><br />
			<b style="color:#008000;">Vert pour les �cuyers			</b>
		</td>
	</tr>
	</table>
	
	<br><br><table align="center">
	<tr>
		<td align="center"><b style="color:#FF0000;">Nom du h�ros		</b></td>
		<td align="center"><b style="color:#9100C7;">Niveau				</b></td>
		<td align="center"><b style="color:#FF0000;">Combattre			</b></td>
		<td align="center"><b style="color:#9100C7;">Ecrire				</b></td>
	</tr>
	<tr><td colSpan="4"><br></td></tr>
	<?php 	$Personnes=GetConnecter($_SESSION["village"]);

	while($row=GetLigne($Personnes)){						 
	echo"<tr>
		<td align='center'><b style='color:#FF0000;'>$row[4]					</b></td>
		<td align='center'><b style='color:#9100C7;'>(<b>$row[2]</b>)			</b></td>
		<td align='center'><b style='color:#FF0000;'><a href='defis.php?adversaire=$row[0]'>Combattre		</a></b></td>
		<td align='center'><b style='color:#9100C7;'><a href='combat2.php?a=$row[0]'>Ecrire		</a></b></td>
		</tr>";	
	}
	?>
	</table>