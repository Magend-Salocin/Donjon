<?php session_start();
require ("../Secret/connect.php");	
include ("../Controleurs/ControleurMagazin.php");	?>
<body> 
	<?php  include ("Menu.php"); ?>
	<img src="../image/village/<?php echo $_SESSION["village"];?>.jpg"  usemap="#zonesClic" >
	<map name="zonesClic">	<?php 	GetAfficheMagazin($_SESSION["village"]);?>		</map> 
	
</body></html>