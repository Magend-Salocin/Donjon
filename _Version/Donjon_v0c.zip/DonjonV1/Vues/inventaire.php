<?php session_start();
require ("../Secret/connect.php");
include ("../Controleurs/ControleurMenu.php");
include ("../Controleurs/ControleurInventaire.php");
include ("../Controleurs/ControleurObjet.php");
	
	
	$HeureActuelle=time();	$_SESSION["time"]=$HeureActuelle;	$numclient=$_SESSION["num"];	
	if ( isset($_GET['item']) )		{ GetUtiliseObjet($_GET['item'],$numclient); 	}	
	if ( isset($_GET['Equiper']) )	{ GetEquipeObjet($_GET['Equiper'],$numclient); }

	

?>
<body> 
	<?php  include ("Menu.php"); ?>
	<center><IMG  width="95%" align="center" src="../image/Menu01.jpg" ></center>
    <TABLE width="95%" background="../image/Menu02.jpg"  align="center">
		<TR><TD colSpan="2" align="center"><H3 class="gris">La liste des objet de votre Inventaire</H3></TD></TR>
		<TR>	
			<TD colSpan="2" align="center">
				<?php $Inventaire=GetInventaire($numclient); while($row=GetLigne($Inventaire))	
				if ($row[0]==null){ echo "Vous ne possedez aucun objet"; } 
				else 			  {	
				echo " <table  background='../image/MenuB.jpg' width='94%'>
						<TR><TD width='20%' align=center><br><br>";
						if($row[8]==""){$row[8]="01";}
				echo"				<IMG  width='60%' src='../image/inventaire/$row[8]'></a>
							</TD>
							<TD>
							<table>
							<TR><TD width='90%' align=center><b>$row[4]<b></TD><TD></TD></TR>
							<TR><TD width='90%'><b><hr color=#FF0033></hr><b></TD><TD></TD></TR>
							<TR><TD width='90%'><p align='justify'>$row[5]</p></TD><TD></TD></TR>
							<TR><TD><br></TD></TR>
							<TR><TD width='90%' align=center>Vous possedez $row[2]</TD></TR>
							</table>
							</TD>
						</TR>
					    <TR align=middle><TD colSpan=2 height=30>
								<a href='inventaire.php?item=$row[3]&text=$row[4]'>utiliser</a>
						</TD></TR>
						</table><br>"; 	
				}?>
			</TD>
		</TR>
	</TABLE>
	
	<TABLE  background='../image/Menu02.jpg' width="95%" align="center">
		<TR><TD colSpan="2" align="center"><H3 class="gris">
			La liste des equipements de votre Inventaire
		</H3></TD></TR>
		<TR><TD colSpan="2" align="center">
				<?php  $Equipement=GetEquipement($numclient);while($row=GetLigne($Equipement))	
				if ($row[0]==null){ echo "Vous ne possedez aucun equipement"; } 
				else 			  {	
				echo " <table  background='../image/MenuB.jpg' width='94%'>
						<TR><TD width='20%' align=center><br><br>";
						if($row[8]==""){$row[8]="01";}
				echo"				<IMG  width='60%' src='../image/inventaire/$row[8]'></a>
							</TD>
							<TD>
							<table>
							<TR><TD width='90%' align=center><b>$row[4]<b></TD><TD></TD></TR>
							<TR><TD width='90%'><b><hr color=#FF0033></hr><b></TD><TD></TD></TR>
							<TR><TD width='90%'><p align='justify'>$row[5]</p></TD><TD></TD></TR>
							<TR><TD><br></TD></TR>
							<TR><TD width='90%' align=center>Vous possedez $row[2]</TD></TR>
							</table>
							</TD>
						</TR>
					    <TR align=middle><TD colSpan=2 height=30>
								<a href='inventaire.php?Equiper=$row[3]&text=$row[4]'>Equiper</a>
						</TD></TR>
						</table><br>"; 	
				}?>
		</TD></TR>
	</TABLE>
	
	<center><IMG width="95%" src="../image/Menu03.jpg"></center>
</body></html>