
Bienvenue au <?php  echo $_SESSION["NomTaverne"]; ?>
	<table >
	
	<tr>
		<td colspan="2"  align="center" > </td>	
	</tr>
	
	<tr>
	<td align="center" ></td>
	
	<td align="center" ></td>

	</tr>
	</table>