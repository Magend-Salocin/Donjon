<html>
	<link rel="stylesheet" 			href="../Controleurs/cssGeneral.css" type="text/css" />
	<script type="text/javascript" src="../Javascript/menu.js"></script>
<body>

	<div class="menu-general" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');">
	Etat Personnage
	</div> 
	<ul id="sous-menu1" class="habillage" onmouseover="montre('sous-menu1');" onmouseout="cache('sous-menu1');"> 
	    <li><a href="EtatHero.php" >Etat Personnage</a></li> 
	    <li><a href="inventaire.php">Inventaire</a></li> 
	    <li><a href="Messagerie.php?msg=msgall">Messagerie</a></li>
	</ul>

	<div class="menu-general"><a href="magazin.php">Village</a></div>
	
	<div class="menu-general"><a href="village.php">Voyager</a></div>
	
	<div class="menu-general"><a href="defis.php">Defis</a></div>
	
	<div class="menu-general"><a href="../Controleurs/deco.php">Deconnexion</a></div>
	<br><br>

</body></html>