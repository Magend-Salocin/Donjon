 <table align="center" border="0" cellpadding="0" style="border-collapse: collapse" bordercolor="#111111" width="90%" >
        <tr>
          <td align="left" width="98%" style="padding: 5">
           <b>Tes d�fis :<br />
		   </b>Vous avez<b> 0</b> demandes de combats en attente<b><br /><br />

			Envoy�s :</b><table border="0" style="border-collapse: collapse; border-style: solid; border-width: 1px" width="100%" cellpadding="0" bordercolor="#000000">
		
			<tr>
				<td align="center"><b>Adversaire</b></td>
				<td align="center" width="68"> <b>XP</b></td>
				<td align="center" width="91"> <b><font size="1">Nb.Combats  </font></b></td>
				<td align="center" width="100"><b><font size="1">Nb.Victoires</font></b></td>
				<td align="center" width="67"> <b>Action</b></td>
			</tr>
			
	<?php $Defis=GetDefis1($heros["num"],$heros["village"]);
	while($row=GetLigne($Defis)){						 
	echo"<tr>
			<td align='center'><font face='Verdana' size='1' color='#008000'>$row[0]</font></td>
			<td width='68'><p align='center'><font face='Verdana' size='1' color='#008000'>$row[1]</font></td>
			<td width='91'><p align='center'><font face='Verdana' size='1' color='#008000'>	$row[2]</font></td>
			<td width='100'><p align='center'><font face='Verdana' size='1' color='#008000'>$row[3]</font></td>
			<td width='67'>	<p align='center'><font face='Verdana' size='1' color='#008000'><img src='images/combat/x.jpg' border='0' /></font></td>
		</tr>";	
	}?>
			
						</table>
<font face="Verdana" size="1"><a href="?page=combat&efface=allsend">Tout supprimer</a></font>
			<p align="left">
          <b>

          <font face="Verdana, Arial, Helvetica, sans-serif" size="1">Re�us :</font></b>
		  <table border="0" style="border-collapse: collapse; border-style: solid; border-width: 1px" width="100%" cellpadding="0" bordercolor="#000000">
		
			<tr>
				<td align="center"><b>Adversaire</b></td>
				<td align="center" width="68"><b>XP</b></td>
				<td align="center" width="91"><b><font size="1">Nb</font><font size="1">. Combats</font></b></font></td>
				<td align="center" width="100"><b><font size="1">Nb</font><font size="1">. Victoires</font></b></td>
				<td align="center" width="67"><b>Action</b></td>
			</tr>
			
			<?php $Defis=GetDefis($heros["num"],$heros["village"]);
		while($row=GetLigne($Defis)){						 
		echo"<tr>
				<td align='center'><font face='Verdana' size='1' color='#008000'>$row[2]</font></td>
				<td width='68'><p align='center'><font face='Verdana' size='1' color='#008000'>$row[3]</font></td>
				<td width='91'><p align='center'><font face='Verdana' size='1' color='#008000'>	$row[4]</font></td>
				<td width='100'><p align='center'><font face='Verdana' size='1' color='#008000'>$row[5]</font></td>
				<td width='67'>	<p align='center'><font face='Verdana' size='1' color='#008000'><a href='defis.php?var=combat&&heros=$row[1]&&combat=$row[0]'><img src='images/combat/x.jpg' border='0' /></a></font></td>
			</tr>";	
	}?>
			
			</table><font face="Verdana" size="1"><a href="?page=combat&efface=allget">Tout supprimer</a></font>
			<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
			<form action="?page=combat" method=post>
				<p align="center">
				<input class="formulaire" type="submit" value="Actualiser" name="Submit0"></p>
			</form></font>
			</td>
        </tr>
      </table>      