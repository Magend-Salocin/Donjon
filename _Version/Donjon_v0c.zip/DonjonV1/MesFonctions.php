<script language="javascript">


function test()
{
var stop=0;

        if(connect.nom.value=="")
	{	alert('Veuillez selectionner un login.');stop=1;
        }
         if(connect.mdp.value=="")
	{
		alert('Veuillez selectionner un mot de passe.');stop=1;	
        }

        if (stop==0){
		connect.submit();
		page.submit();
		//reload()
	}	
}

	function reload(){
	parent.cadreGauche.location.reload();
	}


</script>
<?php 
function deco()
{
session_start();
session_destroy();
?>
<script language='javascript'>parent.cadreDroite.location.replace('Vues/principale.html');</script>
<script language='javascript'>window.location.replace('Vues/acceuil.php');</script>
<?php 
}
?>