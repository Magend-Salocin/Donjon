<div id="CarteJoueurAventure" >

	<table border="0" align="center" id="FenetreCombat" style="display:block;"  class="test" width="450px">
			<tr>
				<td rowspan="2" align="center">
					<img id="Attaquant" style="display:none;" src="">
				</td>
			<td width="50%">
			<div>
				
				<span style="float:left;width:60px;" >Attaque</span>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA0' name='DA0'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA1' name='DA1'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA2' name='DA2'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA3' name='DA3'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA4' name='DA4'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA5' name='DA5'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA6' name='DA6'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA7' name='DA7'>
				</div>
			</td>
				<td rowspan="2" align="center">
					<img id="Defenceur" style="display:none;" src="">
				</td>
			</tr>
			
			<tr>
			<td width="50%">
				<span style="float:left;width:60px;" >Defence</span>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD0' name='DD0'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD1' name='DD1'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD2' name='DD2'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD3' name='DD3'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD4' name='DD4'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD5' name='DD5'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD6' name='DD6'>
				<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD7' name='DD7'>
			</td>
			</tr>
		</table>

	<table align="center" width="100%">
		<tr>
			<td width="70%">	
				<span id="TourMonstre"></span><br />
				<?php print $heros["nom"] ?>: <?php print $heros["libellerace"]?> - Niveau : <?php print $heros["codeexp"] ?> Pieces d'or: 	<B><span id="MyHeroOrs"><?php print $heros["ors"] ?></span>	   </B>		
				<br /><B>Nombre de Monstre restant: </B>	<span id="NbMonstre"></span>
				<br /><B>Prochain niveau: </B><?php  getbarre2("barv.jpg",$exp,$nivsuv); ?>	
				<br /><B>Vie: </B><span id="MyHeroPv"><?php print $heros["pv2"]?></span>/<span id="MyHeroPv2"><?php print $heros["pv"]?></span>		
				<?php  getbarre("barv.jpg",$heros["pv2"],$heros["pv"]); ?>			
				<br /><B>Magie: </B><?php print $heros["pm"]?>/<?php print $heros["pm2"]?>		
				<?php  getbarre("barb.jpg",$heros["pm2"],$heros["pm"]); ?>								
			</td>
			<td width="30%">
				<img  src="<?php echo GetImageRace($heros["libellerace"]);?>">
			</td>
		</tr>
	</table>
	
	<div align="left"  >
		<br />
		&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="-_-" onclick="LancerdeeAttaque()" id="Mn_Attaquer">Attaquer</a>
		&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="-_-" onclick="Lancerdee()" id="Mn_Deplacement">Lancer les d&eacute;e</a>
		&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="-_-" onclick="TirerUneCarteTresor()" id="Mn_Tresor">Tirer Une Carte Tresor</a>
		&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="-_-" onclick="AfficherElement('myHeroItem')" id="Mn_Objet">Utiliser Objet</a>
		&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="-_-" onclick="FinTour()" id="Mn_FinTour">Fin de tour</a>
		D&eacute;placement restant:
		<!-- <input type='hidden' name='Move' value='99' />-->
		&nbsp;&nbsp;<img src='Javascript/HeroQuest_V2/images/dee/Dee.GIF' id='Dee1' name='Dee1'>
		&nbsp;&nbsp;<img src='Javascript/HeroQuest_V2/images/dee/Dee.GIF' id='Dee2' name='Dee2'>
		<br />
		
	</div>


</div>