<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">
	<?php 	if ($ControleurMagazin==true){ ?>
	
		<br><br>	<br><br>
	
	
		<div align="center"  style="background:url(image/EmoteFn1.png);width:500px;height:86px" >
			<div align="left" style="padding-left:9px;padding-top:8px;float:left;" ><img width="65%" src="image/A.png"></div>
			<div align="rigth" style="padding-top:15px;position:relative;width:300px;float:left;" > NomPersonnage <br /> Bienvenue dans mon echope alors une ptit epee</div>
		</div>
	

		<br><br>
		
		
		<center><IMG style="width:500px;"  align="center" src="image/Menu01.jpg" ></center>
		<TABLE  style="width:500px;color:#694421;" background="image/Menu02.jpg" align="center">
			<TR><TD colSpan="2" align="center"><br><H3 class="gris">La liste des objet du magazin</H3></TD></TR>
			<TR>	
				<TD colSpan="2" align="center">
					<?php  while($row=GetLigne($LesObjets))	{
					if($row[8]==""){$row[8]="01.jpg";}					
					echo " 
					<table style='width:450px;height:165px;background:url(image/MenuB.jpg);background-repeat:no-repeat;'  >				
						<TR>
							<TD width='20%' align=center><br><br>
								<IMG style='padding-left:25px;width:100px;' src='image/inventaire/$row[8]'></a>
							</TD>
							<TD>
									<div style='padding-top:15px;width:290px;padding-right:15px;' >
										<b>$row[0]<b>
										<b><hr color=#FF0033></hr><b>
										<p align='justify'>$row[1]</p>
									</div>
							</TD>
						</TR>
						<TR>
							<TD colspan='2' width='90%' align=center>
								<div style='width:250px;position:relative'><b>
								Prix:
								<a href='?page=Magazin&MagazinItem=$row[6]&magazin=$row[7]' onClick ='reload()'> Piece d'or: <b>$row[5]</b>  </a> 
								&nbsp;&nbsp;&nbsp;
								Stock: $row[4] 
								</b></div>
							</TD>
						</TR>
						</table><br>
						";	
					}?>
				</TD>
			</TR>
			<TR><TD colSpan="2" align="center"><a href='?page=Village'>
			<H3 class="gris">Retour au Village</H3>
			</a></TD></TR>
		</TABLE>
		<center><IMG  style="width:500px;"  align="center" src="image/Menu03.jpg" ></center>
		
	<?php }?>
</div>