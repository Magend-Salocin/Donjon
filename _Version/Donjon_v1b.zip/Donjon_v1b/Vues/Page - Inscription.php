<?php 

	function testVide($champ,$name){
		$okey=true;

		if ($champ=='') { 
		echo $champ;
		echo "<div align=left><font color=red>";echo "* ".$name." est obligatoire!" ;echo "</font></div>";
		$okey=false;
		}
		return $okey;
	}

	function testchamps($champs,$test){
		$okey=true;
		if(!ereg($test,$champs))
			{$okey=false;}
	return $okey;
	}

if ( isset($_POST['passage']) )

	{
	$message="";
	$test="^[qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM]";
	
	$name="Votre Nom de Heros";$okey=testVide($_POST['nom'],$name);
		if ($okey==true && testchamps($_POST['nom'],$test)==false){
				$message=$message.'* Votre Nom de Heros ne doit contenir que des lettres.<br>';
		}
		else{ if ($okey==true && GetNom($_POST['nom'])==true){$message=$message.'* Votre Nom de Heros existe d�ja dans la base.<br>';} } 
		
			
	$name="l'email";$okey=testVide($_POST['email'],$name);
		if ($okey==true && testchamps($_POST['email'],"^(.+)@(.+)\\.(.+)$")==false){
			  $message=$message.'* L\' email  doit corespondre � un format valide.<br>';

			  
			  }
	    else{ if ($okey==true && GetMail($_POST['email'])==true){$message=$message.'* Votre e-mailexiste d�ja dans la base.<br>';} } 
	
	
	$name="le mot de passe";$okey=testVide($_POST['mdp'],$name);$okey=testVide($_POST['mdp2'],$name);
		if ($okey==true && $_POST['mdp']!=$_POST['mdp2'])
		      {$message=$message.'* Les mots de passe doivent etre identique.<br>';}
			  
		if ($_POST['race']=="choix")
			{$message=$message.'* Selectionner une race dans la liste d�roulente.<br>';}
			
	if($message=="" && $okey==true)
	{
	SetJoueurInscription($_POST['email'],$_POST['nom'],$_POST['mdp'],$_POST['race']);
	$message='Adh�sion enregistr�e!';
	echo "<p align=left><font color=blue>Votre Inscripton est valider </font></p>";
	}

	else
	{
	
	echo "<p align=left><font color=red>".$message; echo "</font></p>";
	}


	}




	
?>

<div id="body-fullside" style="padding:80px 15px 5px 5px;background-image:url(./image/img/body_sword_handle.jpg);margin-top:27px;.margin-top:0px;_margin-top:0px;float:none;">
	<div style="background-image:url(./image/Autre/FondInscription.jpg);background-position:center center;background-repeat:no-repeat;color:black;height:353px;">
	
	
		<form  NAME="FormClient"  METHOD="post"  ACTION="">
			<table border="0"  align="center" width="45%" >

			<input type="hidden" 	name="passage"  value='1'>
			<tr>
				<td><br /><br /><br /><br /><br /><br /></td>
				<td><br /><br /><br /><br /><br /><br /></td>
			</tr>
			<tr>
				<td><font size="3" >Votre E-mail:</font></td>
				<td><input type="text" name="email"      size="14" maxlength= "30" ></td>
			</tr>
			<tr>
				<td><font size="3" >Votre Nom de Heros:</font></td>
				<td><input type="text" name="nom"      size="14" maxlength= "30" ></td>
			</tr>
			<tr>
				<td><font size="3" >Votre Mot de passe:</font></td>
				<td><input type="password" name="mdp"      size="14" maxlength= "30" ></td>
			</tr>
			<tr>
				<td><font size="3" >Confirmer votre mot de passe:</font></td>
				<td><input type="password" name="mdp2"      size="14" maxlength= "30" ></td>
			</tr>
			<tr>
				
			<td colspan="2" align="center"><select size="1" name="race">
				<option value="choix">Selectionner votre race:</option>
					<?php 
						$LesRaces=GetRace();$UneRace=GetLigne($LesRaces);				
						while ($UneRace)
						{
						print "<OPTION value='$UneRace[code]'>$UneRace[libelle]</OPTION>";
						$UneRace=GetLigne($LesRaces);
						}
					?>
			</select></td>
			</tr>

			<tr>
				<td colspan="2" align="center">
					<input type="submit" name="Enregister" value="Enregister" >
				</td>
			</tr>
			</table>
		</form>
	</div>
</div>