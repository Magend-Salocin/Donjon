<?php 

	function GetContenu(){
		$MyTexte = GetAllMessage();
	RestaureParm($MyTexte );
	}


	function RestaureParm($chaine){
	echo	$W = split(",",$chaine);
		for($i=0;$i<sizeof($W);$i++){
				echo  "AfficheHeros(".$W[$i].");";		
		}
	}
	
	
	Function OpenFichier(){
				$LeFichier="../temp/0001.php";
		$MonFichier =fopen($LeFichier,"r+");
		return $MonFichier ;
	}
	
	
	Function DelFichier(){
			$LeFichier="../temp/0001.php";
		$MonFichier =fopen($LeFichier,"w+");
		fclose($MonFichier); 
	}
	
	Function SetMessage($Variable){
		//EFFACEMENT DU FICHIER 
		DelFichier(); 
		
		//ECRITURE DU TABLEAU DANS LE FICHIERS
		$monfichier =OpenFichier();
		fputs($monfichier,$Variable);fputs($monfichier,"\n"); 
		fclose($monfichier);
	}
	
	
	Function GetAllMessage(){
		//AFFICHAGE DES DONNEES 
		$monfichier =OpenFichier();

			while ($ligne= fgets($monfichier)){
				$text = split(";",$ligne); 	$long = strlen($text[1]);
				
			
			}	
		fclose($monfichier);
		return 	$ligne;
	}
	
	


?>