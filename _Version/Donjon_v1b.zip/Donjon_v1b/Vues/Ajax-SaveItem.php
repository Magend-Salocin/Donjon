<?php 
	include ("../config.php");	
	
	$Action = $_POST['Action'];	
	$IdHero = $_POST['IdHero'];	
	$IdItem = $_POST['IdItem'];	
	$Quantite = $_POST['Quantite'];	
	
	
	if($Action == "EnleverObjet"){
		SuppItem($IdHero,$IdItem,$Quantite);
	}
	
	if($Action == "AjoutObjet"){
		AddItem($IdHero,$IdItem,$Quantite);
	}
?>