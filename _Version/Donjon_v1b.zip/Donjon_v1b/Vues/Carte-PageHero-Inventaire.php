<?php
			if(isset($_POST['MyHero'])){
				$IdMyHero = $_POST['MyHero'];	
				session_start($IdMyHero);
				$numclient = $_SESSION["num"] ;
				require ("../Secret/connect.php");			
				include ("../DAO/Dao_ActionJoueur.php");  
				include ("../DAO/Dao_ActionJoueur_Combat.php");				
				include ("../DAO/Dao_ActionJoueur_Inventaire.php"); 
			}

?>

	
		<table  style="width:500px;color:#694421;" background="image/menu02.jpg" align="center">
		<tr>
		<td  align="center"><h3 class="gris">la liste des objet de votre inventaire</h3></td>
		</tr>
		<tr>	
			<td  align="center">
			<?php 

				$Inventaire=GetInventaire($numclient); 
				$num=0;
			while($row=GetLigne($Inventaire))
			{	
				if ($row[0]==null){ echo "Vous ne possedez aucun objet"; } 
				else {			  
				echo "
				
					<script type='text/javascript'> MesObjet[$num] = new Array('$row[0]','$row[1]','$row[2]','$row[3]','$row[4]','$row[6]','$row[7]','$row[8]','$row[9]','$row[10]');</script>
				
						<table style='width:450px;height:165px;background:url(image/menub.jpg);background-repeat:no-repeat;'  >				
						<tr>
							<td width='20%' align=center style='width:100px;height:96px;background-position:16px 5px;background:url(image/inventaire/$row[8]);background-repeat:no-repeat;'>
						
							</td>
							<td>
									<div style='padding-top:15px;width:290px;padding-right:15px;' >
										<b>$row[4]</b>
										<b><hr color=#ff0033></hr></b>
										<p align='justify'>$row[5]</p>
									</div>
							</td>
						</tr>
						<tr>
							<td colspan='2' width='90%' align='center'>
								vous possedez <span id='_item$row[1]'>$row[2]</span>&nbsp;&nbsp;&nbsp;
								<a onclick='UtiliserObjet($num);' >utiliser</a>
							</td>

						</tr>
						</table><br />"; 	
						$num++;
				}
			}
			?>
				<a href="#" title="RetireStyle" onclick="CacherElement('myHeroItem')" id="y">Fermer</a>
			</td>
		</tr>
	</table>	

