<?php if(isset($_SESSION["num"])) { ?>
<ul>
	<li><a href="index.php" class="sword_menu"><span class="shadow">&nbsp;H&nbsp;</span><span class="text">&nbsp;H&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="javascript:void(0)" onclick="NavigationPage('Village');"  class="sword_menu"><span class="shadow">&nbsp;Village&nbsp;</span><span class="text">&nbsp;Village&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="javascript:void(0)" onclick="NavigationPage('Aventure');" class="sword_menu"><span class="shadow">&nbsp;Aventure&nbsp;</span><span class="text">&nbsp;Aventure&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="javascript:void(0)" onclick="NavigationPage('Voyager');"  class="sword_menu"><span class="shadow">&nbsp;Voyager&nbsp;</span><span class="text">&nbsp;Voyager&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="?page=Deco" class="sword_menu"><span class="shadow">&nbsp;X&nbsp;</span><span class="text">&nbsp;X&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>  
	</ul>
<?php } else { ?>

<ul>
	<li><a href="index.php" class="sword_menu"><span class="shadow">&nbsp;Accueil&nbsp;</span><span class="text">&nbsp;Accueil&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="index.php?page=Inscription" class="sword_menu"><span class="shadow">&nbsp;Inscription&nbsp;</span><span class="text">&nbsp;Inscription&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="index.php?page=Aide" class="sword_menu"><span class="shadow">&nbsp;Aide&nbsp;</span><span class="text">&nbsp;Aide&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="index.php?page=Version" class="sword_menu"><span class="shadow">&nbsp;Version&nbsp;</span><span class="text">&nbsp;Version&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
</ul>
<?php } ?>

