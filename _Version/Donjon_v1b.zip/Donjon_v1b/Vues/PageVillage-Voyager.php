<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-fullside" style="padding:80px 15px 5px 5px;">
	<div style="float:none;">
	<center><img src="image/carte/<?php  echo $_SESSION["village"] ; ?>.jpg" style='width:750px;' usemap="#zonesClic" ></center>
	<map name="zonesClic">	
	<?php  
		$LesDestinations = GetAutreVillage($_SESSION["village"]);
		while($row=GetLigne($LesDestinations)){
			echo " <area shape='rect' coords='$row[2],$row[3],$row[4],$row[5]'  href='?page=EtatPersonnage&&village=$row[0]' alt='dur�e du trajet : $row[9]' >"; 
		}
	?>	
	</map> 
	</div>
</div>