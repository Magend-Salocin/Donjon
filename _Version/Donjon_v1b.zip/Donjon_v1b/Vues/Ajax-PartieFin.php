<?php 
	include ("../config.php");	
	
	$MyHero = $_POST['MyHero'];	
	session_start($MyHero);
	
	$_SESSION['LesJoueurs'] 			= null;
	$_SESSION['MesPieces'] 				= null;
	$_SESSION['MesPortes'] 				= null;	
	$_SESSION['MesPortesPieceActive'] 	= null;	
	$_SESSION['MesMonstres'] 			= null;
	$_SESSION['LesMonstres'] 			= null;		
	$_SESSION['NbMonstre'] 				= null;
	$_SESSION['PieceFouiller'] 			= null;
	$_SESSION['PieceActiver'] 			= null;		
	$_SESSION["AventureEnCour"] 		= null;
	$_SESSION['ReloadPartie']  			= false;
	
	$IdAventure = $_SESSION["AventureEnCour"];
	$IdHero		= $_SESSION["num"]; 
	
	
	SetFinMission($IdAventure,$IdHero); 
	DelAventure($IdHero);
	
?>