<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">
		
		<!--
		<TABLE class="tabAventure" border = 1  align=center>
			<TR align=middle><TD colSpan=2 >Ton grade actuel est <B><?php // echo $librang;?></B></TD></TR>
			<?php // GetAfficheGrade($librang,$codeheros) ?>         
		</TABLE> 
		  -->
		<br>

		<center><IMG style="width:500px;"  align="center" src="image/Menu01.jpg" ></center>
		<TABLE  style="width:500px;color:#694421;" background="image/Menu02.jpg" align="center">
			<TR><TD  align="center"><H3 class="gris">La liste des aventures</H3></TD></TR>
			<TR>	
				<TD   align="center">
					<?php //requete pour retourner le rang de mission ?fficher
						$LesAventure= Aventure::MaListe_aventure($codeRang,$_SESSION["village"]);
						while($row=GetLigne($LesAventure))	{	
						echo " <table style='width:450px;height:165px;background:url(image/MenuA.jpg);background-repeat:no-repeat;'  >
								<TR><TD  width='20%' align=center><br><br>";
						//if( $row['rang'] > $fatiguer )
						//	{echo"<img  style='padding-left:25px;width:100px;border:none;'  src='image/$row[7]' alt='Fatiguer'>";}
						//else{
							echo"<a href='index.php?page=Jeu&mission=$row[0]' style='border:none;'><IMG  style='padding-left:25px;width:100px;border:none;' src='image/$row[7]'></a>";
						//}
							echo"   </TD>
									<TD>
									<div style='padding-top:15px;width:290px;' >
										<b>$row[1]<b>
										<b><hr color=#FF0033></hr><b>
										<p align='justify'>$row[2]</p>
									</div>
									</TD>
								</TR>
								<TR><TD colSpan=2 align='center'>
								<font style='width:250px;' color='blue'><B>Rapporte pi&egrave;ce d'or: $row[3] et Experience: $row[4] 
								</B></font>
								</TD></TR>
								 </table><br>"; 	
						
						}
					?>
				</TD>
			</TR>
		</TABLE>
		<center><IMG  style="width:500px;"  align="center" src="image/Menu03.jpg" ></center>
</div>