<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">

	<?php 
		if (isset ($_GET['var']) ){include ("../Module/jeux/".$_SESSION['village']."/index.php");}
	?>

	<div id="Tarvene_Contenu" style="width:540px;">
		<h2>Bienvenue &agrave; la taverne  <?php  echo $_SESSION["NomTaverne"]; ?></h2><br />
		
		<img src="image/taverne/<?php echo $_SESSION['village']; ?>.png" alt="" />
		<br />
		<div id="Tarvene_News" style="float:left;width:205px;" >
			Bient&ocirc;t disponible &agrave; la taverne:<br />
			&nbsp;- News sur les derni&egrave;re aventure<br />
			&nbsp;- News sur les prochaine arme<br />
			&nbsp;- News sur evolution du village<br />
			&nbsp;- Cr&eacute;ation du tavernier<br />
		</div>
		<div id="Tarvene_Chate" style="float:left;width:300px;" ><?php include ("Module/Chatte/Chat.php");?></div>
	<div id="Menu" style="display:none;">
		<a href="?page=Aventure">Aventure</a>
		<a href="?page=Defis">Defis</a>
		<?php  echo "<a href='../Module/jeux/".$_SESSION['village']."/index.php'>";?>Jeux</a>
	</div>
</div>
	

	
</div>