<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">
	<div id="CarteJoueur" >
		<table Align="center" width="300px">
			<tr>
				<td width="50%">
				<br /> Nom hero 	 : <?php print $heros["nom"] ?>
				<br /> Libelle Race	 : <?php print $heros["libellerace"]?>
				<br /> Niveau 		 : <?php print $heros["codeexp"] ?>
				</td>
				<td width="50%">
					<IMG  src="<?php echo GetImageRace($heros["libellerace"]);?>">
				</td>
			</tr>
		</table>
		<div>
		<h2>Changer mon mot de passe</h2>
			<form method="POST" action="#" name="ChangePassword" >
				Votre ancien mot de passe &nbsp;&nbsp;&nbsp;&nbsp;: <input type="password" 		name="oldMdp" 	size="15px"><br />
				Votre Nouveau mot de passe &nbsp;: <input type="password" 	name="newMDP" 	size="15px"><br />
				Confirmation du  mot de passe : <input type="password" 	name="confMDP" 	size="15px"><br />
				<input type="hidden" 	name="ChangePassword" 	value="ChangePassword" >
				<input type="submit" 	name="ChangePassword" 	value="Valider" >
				&nbsp;
			</form>
		</div>
	</div>
	
	<div style="height : 100px;width:250px;margin:auto;">
		<?php include("Vues/PageHero-Timer.php"); ?>
	</div>
	
</div>
