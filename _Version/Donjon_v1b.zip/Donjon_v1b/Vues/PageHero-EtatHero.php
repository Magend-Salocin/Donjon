<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">
	<div id="CarteJoueur" >
		<div Align="center"><?php print $heros["nom"] ?>: <?php print $heros["libellerace"]?> - Niveau : <?php print $heros["codeexp"] ?> </div>

		<br/><br/>
		<div>
			Experience: <?php print $heros["exp"]?>  
			<table>
				<tr><td align="center">			<B>Prochain niveau: </B>		</td></tr>
				<tr><td>							<?php  getbarre2("barv.jpg",$exp,$nivsuv); ?>				</td></tr>
			</table>		
		
		</div>
		<br/><br/>
		<div>
			Maniment des armes: <?php print $heros["man"];?> 
			<br/>Puissance magique: <?php print $heros["ppm"];?>   
		</div>
		<br/><br/>
		<div >
			<table Align="center" width="300px">
				<tr>
					<td width="50%">
							Force:  			<?php print $heros["forc"] ;?>   
						<br/>Dexterit&eacute; 			<?php print $heros["dext"] ;?>  
						<br/>Intelligence: 		<?php print $heros["inti"] ;?>    
						<br/>Charisme:  		<?php print $heros["cha"];?>  
						<br/>Vitesse:  			<?php print $heros["vit"] ;?> 
						<br/>Endurance:  		<?php print $heros["end"] ;?>   
						<br/>Attaque:  			<?php print $attaque;?>  
						<br/>Defense:  			<?php print $defence;?>  
					</td>
					<td width="50%">
						<IMG  src="<?php echo GetImageRace($heros["libellerace"]);?>">
					</td>
				</tr>
			</table>
		</div>
		
		<div>
			<table>
				<tr><td align="center">			<B>Vie: </B><?php print $heros["pv2"]?>/<?php print $heros["pv"]?>			</td></tr>
				<tr><td>							<?php  getbarre("barv.jpg",$heros["pv2"],$heros["pv"]); ?>				</td></tr>
				<tr><td align="center">			<B>Magie: </B><?php print $heros["pm"]?>/<?php print $heros["pm2"]?>		</td></tr>
				<tr><td>							<?php  getbarre("barb.jpg",$heros["pm2"],$heros["pm"]); ?>				</td></tr>
			</table>
		</div>
		
	</div>
	<div style="height : 100px;width:250px;margin:auto;">
		<?php include("Vues/PageHero-Timer.php"); ?>
	</div>
</div>