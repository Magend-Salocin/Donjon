<?php
	if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } 
		//BLOC DE VERIFICATION SI UNE AVENTURE OU UN VOYAGE ETAIT EN COUR POUR LE CONTINUER
		$encour=GetAventureEnCour($heros["num"]);
		if ($encour!=null){			$datenow=time();	$temps = $datenow - $encour[2];
			
			
			if ($encour[3]=="A"){
				$T=GetMissionAventure($encour[0]); $timer=$T[5]-$temps;
				if ($timer < 0)	{SetFinMission($encour[0],$heros["num"]);}
				else 			{timer($timer); $_GET['mission']=$encour[0]; 	$goavan=1; }
			}
			
			if ($encour[3]=="V" && $govillage==0){
				$VIL=GetVoyage($heros["village"],$encour[0]);	 $timer=$VIL[0]-$temps;
				if ($timer < 0)	{Modif("village",$encour[0],$heros["num"]); $heros["village"]=$encour[0];}
				else 			{timer2($timer); $_GET['village']=$encour[0];  $goavan=1; }
			}
		}
		
		if ( isset($_GET['mission']) || isset($encour[3]) ) {	
			if ($encour[3]=="A") { $FA=$encour[0];
			echo"<form method='POST' action='#' name='aventure' ><input type='hidden' name='aventure' value='$FA' >
			<input type='hidden' name='finaventure' value='1' ></form>";
			} 
			
			if ( isset($_GET['mission'])) { $FA=$_GET['mission'];
			echo"<form method='POST' action='#' name='aventure' ><input type='hidden' name='aventure' value='$FA' >
			<input type='hidden' name='finaventure' value='1' ></form>";
			}		
			
		} 
		
		 
		if ( isset($_GET['village']) || isset($encour[3])){
			if($govillage==0){
				if ($encour[3]=="V") 			{  $FA=$encour[0];		}
				if ( isset($_GET['village'])) 	{  $FA=$_GET['village'];}	
				
				echo"<form method='POST' action='#' name='voyage' ><input type='hidden' name='village' value='$FA' >
				<input type='hidden' name='finvoyage' value='1' ></form>";
			}
		}
		
		
		?>