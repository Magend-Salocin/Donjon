<?php 
	$IdMyHero = $_POST['MyHero'];	session_start($IdMyHero);	include ("../config.php");	$Action = $_POST['Action'];	
	if($Action == "SaveJoueur"){
		$_SESSION["pv"] 			= $_POST['MyHero_pv'];				
		$_SESSION["pv2"] 			= $_POST['MyHero_pv2'];	
		$_SESSION["pm"] 			= $_POST['MyHero_pm'];				
		$_SESSION["pm2"] 			= $_POST['MyHero_pm2'];	
		$_SESSION["forc"] 			= $_POST['MyHero_forc'];			
		$_SESSION["end"] 			= $_POST['MyHero_end'];	
		$_SESSION["inti"] 			= $_POST['MyHero_inti'];			
		$_SESSION["dext"] 			= $_POST['MyHero_dext'];	
		$_SESSION["vit"] 			= $_POST['MyHero_vit'];			
		$_SESSION["cha"] 			= $_POST['MyHero_cha'];
		$_SESSION["man"] 			= $_POST['MyHero_man'];			
		$_SESSION["ppm"] 			= $_POST['MyHero_ppm'];

		$_SESSION["exp"] 			= $_POST['MyHero_exp'];			
		$_SESSION["ors"] 			= $_POST['MyHero_ors'];
		$_SESSION["codeexp"] 		= $_POST['MyHero_codeexp'];		
		$_SESSION["nivsuv"] 		= $_POST['MyHero_nivsuv'];	

		$_SESSION["cexp"] 			= $_POST['MyHero_cexp'];			
		$_SESSION["nbexp"] 			= $_POST['MyHero_nbexp'];	


		$_SESSION["Arme"] 			= $_POST['MyHero_Arme'];			
		$_SESSION["Bouclier"] 		= $_POST['MyHero_Bouclier'];	
		$_SESSION["Casque"] 	    = $_POST['MyHero_Casque'];			
		$_SESSION["Plastron"]		= $_POST['MyHero_Plastron'];	
		$_SESSION["AvantBras"] 		= $_POST['MyHero_AvantBras'];		
		$_SESSION["Botte"] 			= $_POST['MyHero_Botte'];	
		$_SESSION["Jambiere"] 		= $_POST['MyHero_Jambiere'];		

		$_SESSION['LesJoueurs'] 	= $_POST['LesJoueurs'];
	}
	if($Action == "SavePartie"){
		$_SESSION['LesJoueurs'] 			= $_POST['LesJoueurs'];
		$_SESSION['MesPieces'] 				= $_POST['MesPieces'];	
		$_SESSION['MesPortes'] 				= $_POST['MesPortes'];	
		$_SESSION['MesPortesPieceActive'] 	= $_POST['MesPortesPieceActive'];	
		$_SESSION['MesMonstres'] 			= $_POST['MesMonstres'];
		$_SESSION['MesPieges'] 				= $_POST['MesPieges'];
		$_SESSION['LesMonstres'] 			= $_POST['LesMonstres'];		
		$_SESSION['PieceFouiller'] 			= $_POST['PieceFouiller'];	
		$_SESSION['PieceActiver'] 			= RestaureParmAjax($_POST['PieceActiver']);	
		$_SESSION['FinAventure'] 			= $_POST['FinAventure'];	
		
		$_SESSION['ReloadPartie']  = true;
	}
	if($Action == "SaveFinPartie"){
		$_SESSION['LesJoueurs'] 			= null;
		$_SESSION['MesPieces'] 				= null;
		$_SESSION['MesPortes'] 				= null;	
		$_SESSION['MesPortesPieceActive'] 	= null;	
		$_SESSION['MesMonstres'] 			= null;
		$_SESSION['LesMonstres'] 			= null;		
		$_SESSION['NbMonstre'] 				= null;
		$_SESSION['PieceFouiller'] 			= null;
		$_SESSION['PieceActiver'] 			= null;		
		$_SESSION["AventureEnCour"] 		= null;
		$_SESSION['ReloadPartie']  			= false;
		
		$IdAventure = $_SESSION["AventureEnCour"];
		$IdHero		= $_SESSION["num"]; 
		
		SetFinMission($IdAventure,$IdHero); 
		DelAventure($IdHero);
	}

?>