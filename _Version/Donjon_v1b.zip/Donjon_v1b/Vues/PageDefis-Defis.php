<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="580">
	<tr>
	  <td align="center">
		  <a href="?page=Defis">Mes d?s</a> || 
		  <a href="?page=DefierHeros">D?er un h?s du village</a> || 
		  <a href="#">Classement</a> || 
		  <a href="#">Historique</a>
	  </td>
	</tr>
	<tr>
	  <td align="center" width="74%" style="padding: 5px; ">
		Vous avez gagn?b><?php echo $heros["nbVictoire"];?></b> combats sur <b><?php echo $heros["nbCombat"];?></b> effectu?br /><br />
		Aujourd'hui vous avez particip? <b><?php echo $heros["NbCombatDay"];?></b>/60 combats
	  </td>
	</tr>
</table>