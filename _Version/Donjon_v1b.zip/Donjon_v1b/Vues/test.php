<?php 

include('Ajax-RestorTour.php');


//SetMessage("4,4,4,4,4,4,4,4,4,5");

GetContenu();




?>