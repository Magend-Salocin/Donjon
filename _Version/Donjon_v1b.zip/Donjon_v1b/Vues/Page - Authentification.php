<div id="body-fullside" style="padding:80px 15px 5px 5px;background-image:url(./image/img/body_sword_handle.jpg);margin-top:27px;.margin-top:0px;_margin-top:0px;float:none;">
	<div style="left:50%;margin-left:-300px;position:relative;font-family:Georgia;font-size:large;">
		<form method="GET" action="" name="connect" >
		
		

		<!--
			<input type="hidden" 	name="passage"  value='1'>
			Authentification  : <br />
			<strong>Nom d utilisateur</strong><input type="text" 		name="nom" 	size="20"><br />
			<strong>Mot de passe</strong><input type="password" 	name="mdp" value=""><br />
			<input type="submit" name="valider" 	value="connecter" ><br />
			-->
			Authentification  
			

					<table style='width:450px;height:165px;background:url(image/MenuA.jpg);background-repeat:no-repeat;'  >
							<tr><td></td><td>	<br /></td></tr>
						<tr><td><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nom d utilisateur</strong></td><td><input type="text" 		name="nom" 	size="20"></td></tr>
						<tr><td><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mot de passe</strong></td><td><input type="password" 	name="mdp" value=""></td></tr>
						<tr><td></td><td>	<input type="submit" name="valider" 	value="connecter" ></td></tr>
					</table>

	

		</form>
		

	</div>
</div>