<?php if(isset($_SESSION["num"])) { ?>
	<div class="hr"><hr/></div>
	<div class="left" style="margin:-5px 0 0 0px">
		<a href="index.php?page=Aide" class="low_menu">Aide</a>
		<a href="index.php?page=Version" class="low_menu">Version</a>
		<a href="" class="low_menu"></a>
		<a href="" class="low_menu"></a>
	</div>
	<div class="designedby">
		Magend  2009<br/>
	</div>
<?php } else { ?>
	<div class="hr"><hr/></div>
	<div class="left" style="margin:-5px 0 0 0px">
		<a href="index.php?page=Aide" class="low_menu"></a>
		<a href="index.php?page=Version" class="low_menu"></a>
		<a href="" class="low_menu"></a>
		<a href="" class="low_menu"></a>
	</div>
	<div class="designedby">
		Magend  2009<br/>
	</div>
<?php } ?>