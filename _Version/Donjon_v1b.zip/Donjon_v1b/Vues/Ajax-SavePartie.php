<?php 

	$MyHero = $_POST['MyHero'];	
	session_start($MyHero);
	
	

	
	$_SESSION['LesJoueurs'] 			= $_POST['LesJoueurs'];
	$_SESSION['MesPieces'] 				= $_POST['MesPieces'];	
	$_SESSION['MesPortes'] 				= $_POST['MesPortes'];	
	$_SESSION['MesPortesPieceActive'] 	= $_POST['MesPortesPieceActive'];	
	$_SESSION['MesMonstres'] 			= $_POST['MesMonstres'];
	$_SESSION['MesPieges'] 				= $_POST['MesPieges'];
	$_SESSION['LesMonstres'] 			= $_POST['LesMonstres'];		
	$_SESSION['PieceFouiller'] 			= $_POST['PieceFouiller'];	
	$_SESSION['PieceActiver'] 			= RestaureParmAjax($_POST['PieceActiver']);	
	$_SESSION['FinAventure'] 			= $_POST['FinAventure'];	
	
	
	
	$_SESSION['ReloadPartie']  = true;
	
?>