<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">
		<center><IMG style="width:500px;"  align="center" src="image/Menu01.jpg" ></center>
		<TABLE  style="width:500px;color:#694421;" background="image/Menu02.jpg" align="center">
		<TR><TD colSpan="2" align="center"><H3 class="gris">La liste des objet de votre Inventaire</H3></TD></TR>
		<TR>	
			<TD colSpan="2" align="center">
			<?php 
				$Inventaire=GetInventaire($IdHero); 
			while($row=GetLigne($Inventaire))
			{	
				if ($row[0]==null){ echo "Vous ne possedez aucun objet"; } 
				else {			  
				echo "
						<table style='width:450px;height:165px;background:url(image/MenuB.jpg);background-repeat:no-repeat;'  >				
						<tr><td width='20%' align=center><br><br>
							<img style='padding-left:25px;width:100px;' src='image/inventaire/$row[8]'></a>
							</td>
							<td>
									<div style='padding-top:15px;width:290px;padding-right:15px;' >
										<b>$row[4]<b>
										<b><hr color=#FF0033></hr><b>
										<p align='justify'>$row[5]</p>
									</div>
							</td>
						</tr>
							<tr><td colspan='2' width='90%' align=center>
									Vous possedez $row[2]&nbsp;&nbsp;&nbsp;
									<a href='?page=Inventaire&item=$row[3]&text=$row[4]'>Utiliser</a>
							</td></tr>
							</td>
						</tr>
						</table><br>"; 	
				}
			}
			?>
			</TD>
		</TR>
	</TABLE>
	<center><IMG  style="width:500px;"  align="center" src="image/Menu03.jpg" ></center>
	
	<br /><br />
	
	<center><IMG style="width:500px;"  align="center" src="image/Menu01.jpg" ></center>
	<TABLE  style="width:500px;color:#694421;" background="image/Menu02.jpg" align="center">
		<TR><TD colSpan=2 align=center><H3 class=gris>La liste des equipements de votre Inventaire</H3></TD></TR>
		<TR>	
			<TD colSpan=2 align=center>
				<?php  $Equipement=GetEquipement($IdHero);while($row=GetLigne($Equipement))	
				if ($row[0]==null){ echo "Vous ne possedez aucun equipement"; } 
				else {
					if($row[8]==""){$row[8]="01.png";}
					
						

						
				echo "
						<table style='width:450px;height:165px;background:url(image/menub.jpg);background-repeat:no-repeat;'  >				
						<tr><td width='20%' align=center><br><br>
							<img style='padding-left:25px;width:100px;' src='image/inventaire/$row[8]'></a>
							</td>
							<td>
									<div style='padding-top:15px;width:290px;padding-right:15px;' >
										<b>$row[4]<b>
										<b><hr color=#ff0033></hr><b>
										<p align='justify'>$row[5]</p>
									</div>
							</td>
						</tr>
							<tr><td colspan='2' width='90%' align=center>
								vous possedez $row[2] &nbsp;&nbsp;&nbsp;
								<a href='?page=Inventaire&Equiper=$row[3]&text=$row[4]'>Equiper</a>
							</td></tr>
							</td>
						</tr>
						</table><br>"; 	
				
				}?>
			</TD>
		</TR>
	</TABLE>
	
	<center><IMG  style="width:500px;"  align="center" src="image/Menu03.jpg" ></center>
</div>