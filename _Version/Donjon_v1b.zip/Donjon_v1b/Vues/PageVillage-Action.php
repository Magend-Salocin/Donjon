<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">
	<?php if($Auth==1) {?>
	<table  border="1" width="100%"><tr><td width="33%">

		<table border="1" width="100%" >
			<tr><td colSpan="2" align="center"><B>Etat de votre h?				           </B></td></tr>
			<tr><td align="center" width="50%">	Heros  :     <B><?php print $heros["nom"] ?>	   </B></td>
				<td align="center" width="50%">	Niveau :     <B><?php print $heros["codeexp"] ?>   </B></td></tr>
			<tr><td align="center" width="50%">	Pi?s d'or: <B><?php print $heros["ors"] ?>	   </B></td>
				<td align="center" width="50%">	Exp?ence : <B><?php print $heros["exp"] ?>	   </B></td></tr>
		
			<tr><td>			Prochain niveau:				</td>
			<td><?php 			getbarre2("barv.jpg",$exp,$nivsuv); ?>				</td></tr>
			
			
			<?php if($Nivsup==true ){
			echo"<tr><td align=center><a href='HNS.PHP' target='cadreDroite'>Niveau sup?eur</a></td></tr>";}
			
			?></table></td><td>	<table border="0" width="100%" ><tr><td><?php 
			//BLOC DE VERIFICATION SI UNE AVENTURE OU UN VOYAGE ETAIT EN COUR POUR LE CONTINUER
		
			$encour=GetAventureEnCour($heros["num"]);
				if ($encour!=null){			$datenow=time();	$temps = $datenow - $encour[2];
					
					if ($encour[3]=="A"){
						$T=GetMissionAventure($encour[0]); 	$timer=$T[5]-$temps;
						if ($timer < 0)	{SetFinMission($encour[0],$heros["num"]);}
						else 			{timer($timer); $_GET['mission']=$encour[0]; 	$goavan=1; }
					}
					if ($encour[3]=="V"){
						$VIL=GetVoyage($heros["village"],$encour[0]);	 $timer=$VIL[0]-$temps;
						if ($timer < 0)	{Modif("village",$encour[0],$heros["num"]); $heros["village"]=$encour[0];}
						else 			{timer2($timer); $_GET['village2']=$encour[0];  $goavan=1; }
					}
				}
			//}
			?>
		</td></tr></table></td></tr></table>
	  <?php }?>



		<?php  if ( isset($_GET['mission']) || isset($encour[3]) ) {
		if ($encour[3]=="A") { $FA=$encour[0];} else  { $FA=$_GET['mission'];}
		//if ( isset($_GET['mission'])) { $FA=$_GET['mission'];} else { $FA=$encour[0];}
		
		echo"<form method='POST' action='' name='aventure' >
			<input type='hidden' name='aventure' value='$FA' >
			<input type='hidden' name='finaventure' value='1' >	
		</form>";
		 } ?>
		<?php if ( isset($_GET['village']) || isset($encour[3]) ){ if ($encour[3]=="V") { ?>
		<form method="POST" action="" name="voyage" >
			<input type="hidden" name="village" 	value="<?php  if ( isset($_GET['village'])) { echo $_GET['village'];} else { echo  $encour[0];} ?>" >
			<input type="hidden" name="finvoyage" value="1" >	
		</form>
		<?php  }} ?>
</div>