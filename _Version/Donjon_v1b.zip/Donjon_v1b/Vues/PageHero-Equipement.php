<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside"><br /><br />
<H2>Equipement</H2>
	<table  border="0" bordercolor="red"  width="50%" align="center" ><tr><td><img style="width:420px"  align="center" src='image/msg_int/Menu01.jpg' >
		<table align="center" style="width:420px"  background='image/msg_int/Menu03.jpg' cellpadding="0" cellspacing="0" class="tabheros" >
			<tr>
				<td align="center" width="30%"><b>arme:	</b>	</td>
				<td align="center" width="30%"><?php print $heros["Arme"] ;?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=Arme">Enlever</a>		</td>
			</tr>
			<tr>
				<td align="center" width="30%"><b>bouclier:	</b></td>
				<td align="center" width="30%"><?php print $heros["Bouclier"];?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=Bouclier">Enlever</a>		</td>
			</tr>
			<tr>
				<td align="center" width="30%"><b>casque:	</b>	</td>
				<td align="center" width="30%"><?php print $heros["Casque"];?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=Casque">Enlever</a>		</td>
			</tr>
			<tr>
				<td align="center" width="30%"><b>plastron:	</b>	</td>
				<td align="center" width="30%"><?php print $heros["Plastron"];?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=Plastron">Enlever</a>		</td>
			</tr>
			<tr>
				<td align="center" width="30%"><b>avantbras:	</b></td>
				<td align="center" width="30%"><?php print $heros["AvantBras"];?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=AvantBras">Enlever</a>		</td>
			</tr>
			<tr>
				<td align="center" width="30%"><b>botte:	</b></td>
				<td align="center" width="30%"><?php print $heros["Botte"] ; ?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=Botte">Enlever</a>		</td>
			</tr>
			<tr>
				<td align="center" width="30%"><b>jambi&eacute;:	</b></td>
				<td align="center" width="30%"><?php print $heros["Jambiere"] ; ?>	</td>
				<td align="left" width="30%"><a href="?page=Equipement&RetirerEquipement=Jambiere">Enlever</a>		</td>
			</tr>
		</table>
	<img  style="width:420px"  align="center" src='image/msg_int/Menu02.jpg' ></td></tr></table>
		
</div>