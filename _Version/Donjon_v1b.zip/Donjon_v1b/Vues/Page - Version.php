<div id="body-fullside" style="padding:80px 15px 5px 5px;background-image:url(./image/img/body_sword_handle.jpg);margin-top:27px;.margin-top:0px;_margin-top:0px;float:none;">
	<div style="left:50%;margin-left:-300px;position:relative;font-family:Georgia;font-size:large;">
		Version
		
	</div>
</div>