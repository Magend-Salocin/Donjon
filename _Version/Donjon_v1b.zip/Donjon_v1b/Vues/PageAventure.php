<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-fullside">
	<?php include("Javascript/HeroQuest_V2/index.php"); ?>
</div>