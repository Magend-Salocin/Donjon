<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-leftside">
	<?php include("Menu.php"); ?>
</div>
<div id="body-rightside">

		<center>
			<a href="?page=Messagerie&msg=msgall">Boite de reception</a> ||  
			<a href="?page=Messagerie&msg=msgsend">Envoyer message</a>  ||  
		</center><br>
		<table  border="0" bordercolor="red"  width="50%" align="center" ><tr><td>
			<IMG   style="width:420px" align="center" src='image/msg_int/Menu01.jpg' >
	<?php if(isset($_GET["msg"])){ 

	if ($_GET["msg"]=="msgall"){

	 if(isset($_GET["del"]))    {	DelMessage($_GET["del"],$_SESSION["nom"]); }
	 if(isset($_POST["action"])){	SetMessage($_POST["pseudo_msg"],$_SESSION["nom"],$_POST["sujet_msg"],$_POST["text_msg"]) ; }
	?>	
		
		<table style="width:420px" background='image/msg_int/Menu03.jpg' align="center" cellpadding="0" cellspacing="0">
			<tr>
				<td height="27" align="center" colspan="5" valign="top">Boite de reception</td>
			</tr>
			<tr style="border:colapse; background:#0066FF">
				<td width="35"  valign="top"></td>
				<td width="107" valign="top"><b>Pseudo</b></td>
				<td width="170" valign="top"><b>Sujet </b></td>
				<td width="108" valign="top"><b>Date  </b></td>
				<td width="54"  valign="top"><b>Action</b></td>
				
			</tr>
			<?php  GetAllMessage($_SESSION["nom"]); ?>
		</table>
		
		
	<?php } if ($_GET["msg"]=="msgsend"){	 ?>


		<table style="width:420px" background='image/msg_int/Menu03.jpg'    cellpadding="0" cellspacing="0">
		 <form  action="?page=Messagerie&msg=msgall" method="post" >
		<input type="hidden" name="action" value="send_msg_int" />
		  <tr>
			<td  align="center" width="20%" valign="top"><b>A</b>:</td>
			<td><input name="pseudo_msg" value="<?php if(isset($_GET["name"])){echo $_GET["name"];}?>" type="text" size="25" maxlength="25" /></td>
		  </tr>
		  <tr>
			<td align="center" width="20%"   valign="top"><b>Sujet</b>: </td>
			<td><input name="sujet_msg" type="text" size="25" maxlength="255" /></td>
		  </tr>
		  <tr>
			<td align="center" colspan="2"  valign="top">
				<textarea name="text_msg" cols="45" rows="10"></textarea>
			</td>
		  </tr>
		  <tr><td><br></td></tr>
		  <tr>
			<td align="center" colspan="2"  valign="top"><input type="submit" name="submit" value="Envoyer" /></td>
		  </tr>
		</form>
		</table>
		
	<?php } if ($_GET["msg"]=="msglook"){ $Message=GetMessage($_GET["name"],$_SESSION["nom"]);
	if($Message[6]=="0"){ModifMessage($_GET["name"],$_SESSION["nom"]);}
	?>

	<table  style="width:420px"  background='image//msg_int/Menu03.jpg' cellpadding="0" cellspacing="0">
		  <tr>
			<td    width="20%" align="center" valign="top"><b >De</b>: </td>
			<td><?php  echo $Message[2];?> </td>
		  </tr>
		  <tr>
			<td width="20%" align="center"  valign="top"><b>Le</b>: </td>
			<td><?php  echo $Message[3];?></td>
		  </tr>
		  <tr>
			<td  width="20%" align="center"  valign="top"><b>Sujet</b>: </td>
			<td><?php  echo $Message[4];?></td>
		  </tr>
		  <tr>
			<td align="center" colspan="2"  valign="top"><textarea name="" cols="45" rows="10">
			<?php  echo $Message[5];?>
			</textarea></td>
		  </tr>
		  <tr>
			<td align="center" colspan="2"  valign="top">
			<a href="?page=Messagerie&msg=msgall&del=<?php echo$Message[0];?>">Effacer message</a>  ||  
			<a href="?page=Messagerie&msg=msgsend&name=<?php echo$Message[2];?>">Repondre</a>  
			</td>
		  </tr>
		</table>
		
	<?php }}?>
	<IMG  style="width:420px"  align="center" src='image/msg_int/Menu02.jpg' >
	</td></tr></table>
</div>