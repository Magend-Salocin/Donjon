	<div id="scroll_top"><span id="scroll_header">MENU&nbsp;</span></div>
	<div id="scroll_middle">
	<!--	<a href="?page=Village" class="main_menu">Village</a>
		<a href="?page=Aventure" class="main_menu">Aventure</a>
		<a href="?page=Voyager" class="main_menu">Voyager</a>
		<a href="?page=Defis" class="main_menu">Defis</a> 
		<div class="menu_separator">
			<div class="separator_text">Etat Personnage</div>
		</div>
				<a href="?page=EtatPersonnage" onclick="NavigationPage()" class="main_menu">Personnage</a>
		<a href="?page=Equipement" class="main_menu">Equipement</a>	
		<a href="?page=Inventaire" class="main_menu">Inventaire</a>																							
		<a href="?page=Messagerie&msg=msgall" class="main_menu">Messagerie</a>	
		<div class="menu_separator">

		</div>
		<a href="?page=MonCompte" class="main_menu">Mon Compte</a>

		-->
		<a href="javascript:void(0)" onclick="NavigationPage('EtatPersonnage');" class="main_menu">Personnage</a>
		<a href="javascript:void(0)" onclick="NavigationPage('Equipement');" class="main_menu">Equipement</a>	
		<a href="javascript:void(0)" onclick="NavigationPage('Inventaire');" class="main_menu">Inventaire</a>																							
		<a href="?page=Messagerie&msg=msgall" class="main_menu">Messagerie</a>	
		<div class="menu_separator">
			<div class="separator_text"><?php print $heros["nom"]; ?></div>
		</div>
		<a  href="javascript:void(0)" onclick="NavigationPage('MonCompte');" class="main_menu">Mon Compte</a>
		<a  href="#" class="main_menu"> Niveau : <?php print $heros["codeexp"]; ?></a>
		<a  href="#" class="main_menu"> Ors : <?php print $_SESSION["ors"]; ?></a>


	
		
		
		
	</div>
	
	
	<div id="scroll_bottom"></div>