<?php if(isset($_POST["Ajax"])){ $IdMyHero = $_POST['MyHero'];	session_start($IdMyHero); include ("../config.php");  } ?>
<div id="body-fullside" style="padding:80px 15px 5px 5px;">
	<div style="float:none;">
		<img src="image/village/<?php echo $_SESSION["village"];?>.jpg"  usemap="#zonesMagazin" >
		<map name="zonesMagazin">	<?php 	GetAfficheMagazin($_SESSION["village"]);?>		</map> 
	</div>
</div>