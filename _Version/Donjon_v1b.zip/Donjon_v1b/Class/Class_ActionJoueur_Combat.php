<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				   ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		   ****	
	***	Le:				  			   ****	
	***	Motif:			  			   ****											
	***********************************************/

	Class ActionJoueur_Combat 
	{ 
		/*********************************/
		/*		Table Avant Combat 	*/
		/*********************************/
		public function MaListe_avantcombat()
		{
			return Getavantcombat();
		}
		
		public function Obtenir_avantcombat($Idavantcombat){
			return GetavantcombatId($Idavantcombat);
		}
		
		public function Ajouter_avantcombat($num,$heros,$MoiHeros){
			Insertavantcombat($num,$heros,$MoiHeros);
		}
		
		public function Modifier_avantcombat($num,$heros,$MoiHeros{
			Updateavantcombat($num,$heros,$MoiHeros);
		}
		
		public function Supprimmer_avantcombat($Idavantcombat){
			Deleteavantcombat($Idavantcombat);
		}		
	}
	?>