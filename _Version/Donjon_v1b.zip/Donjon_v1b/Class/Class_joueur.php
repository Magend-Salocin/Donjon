<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				           ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		       ****	
	***	Le:				  			           ****	
	***	Motif:			  			           ****											
	***********************************************/

	Class joueur 
	{ 
		public function MaListe_joueur()
		{
			return Getjoueur();
		}
		
		public function Obtenir_joueur($Idjoueur){
			return GetjoueurId($Idjoueur);
		}
		
		public function Ajouter_joueur($num,$email,$login,$mdp,$nom,$pv,$pv2,$pm,$pm2,$forc,$end,$inti,$dext,$vit,$cha,$man,$ppm,$exp,$ors,$codeexp,$nivsuv,$cexp,$nbexp,$libellerace,$libellerang,$village,$image,$Enligne,$nbCombat,$nbVictoire,$NbCombatDay,$Arme,$Bouclier,$Casque,$Plastron,$AvantBras,$Botte,$Jambiere){
			Insertjoueur($num,$email,$login,$mdp,$nom,$pv,$pv2,$pm,$pm2,$forc,$end,$inti,$dext,$vit,$cha,$man,$ppm,$exp,$ors,$codeexp,$nivsuv,$cexp,$nbexp,$libellerace,$libellerang,$village,$image,$Enligne,$nbCombat,$nbVictoire,$NbCombatDay,$Arme,$Bouclier,$Casque,$Plastron,$AvantBras,$Botte,$Jambiere);
		}
		
		public function Modifier_joueur($num,$email,$login,$mdp,$nom,$pv,$pv2,$pm,$pm2,$forc,$end,$inti,$dext,$vit,$cha,$man,$ppm,$exp,$ors,$codeexp,$nivsuv,$cexp,$nbexp,$libellerace,$libellerang,$village,$image,$Enligne,$nbCombat,$nbVictoire,$NbCombatDay,$Arme,$Bouclier,$Casque,$Plastron,$AvantBras,$Botte,$Jambiere{
			Updatejoueur($num,$email,$login,$mdp,$nom,$pv,$pv2,$pm,$pm2,$forc,$end,$inti,$dext,$vit,$cha,$man,$ppm,$exp,$ors,$codeexp,$nivsuv,$cexp,$nbexp,$libellerace,$libellerang,$village,$image,$Enligne,$nbCombat,$nbVictoire,$NbCombatDay,$Arme,$Bouclier,$Casque,$Plastron,$AvantBras,$Botte,$Jambiere);
		}
		
		public function Supprimmer_joueur($Idjoueur){
			Deletejoueur($Idjoueur);
		}


		

		
	}
	?>