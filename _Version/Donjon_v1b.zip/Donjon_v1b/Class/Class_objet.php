<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				           ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		       ****	
	***	Le:				  			           ****	
	***	Motif:			  			           ****											
	***********************************************/

	Class objet 
	{ 
	
	
	/*********************************/
	/*		Table Objet 		*/
	/*********************************/
	
	public function MaListe_objet()
	{
		return Getobjet();
	}
	
	public function Obtenir_objet($Idobjet){
		return GetobjetId($Idobjet);
	}
	
	public function Ajouter_objet($num,$libelle,$resumer,$effet,$valeur,$image,$catheg,$autre){
		Insertobjet($num,$libelle,$resumer,$effet,$valeur,$image,$catheg,$autre);
	}
	
	public function Modifier_objet($num,$libelle,$resumer,$effet,$valeur,$image,$catheg,$autre{
		Updateobjet($num,$libelle,$resumer,$effet,$valeur,$image,$catheg,$autre);
	}
	
	public function Supprimmer_objet($Idobjet){
		Deleteobjet($Idobjet);
	}
		
	/*********************************/
	/*		Table Objet Hero		*/
	/*********************************/
		
	public function MaListe_objethero()
	{
		return Getobjethero();
	}
	
	public function Obtenir_objethero($Idobjethero){
		return GetobjetheroId($Idobjethero);
	}
	
	public function Ajouter_objethero($hero,$objet){
		Insertobjethero($hero,$objet);
	}
	
	public function Modifier_objethero($hero,$objet{
		Updateobjethero($hero,$objet);
	}
	
	public function Supprimmer_objethero($Idobjethero){
		Deleteobjethero($Idobjethero);
	}

	/*********************************/
	/*	Table Objet Proposer 		*/
	/*********************************/
	public function MaListe_objetproposer()
	{
		return Getobjetproposer();
	}
	
	public function Obtenir_objetproposer($Idobjetproposer){
		return GetobjetproposerId($Idobjetproposer);
	}
	
	public function Ajouter_objetproposer($magazin,$objet,$nb){
		Insertobjetproposer($magazin,$objet,$nb);
	}
	
	public function Modifier_objetproposer($magazin,$objet,$nb{
		Updateobjetproposer($magazin,$objet,$nb);
	}
	
	public function Supprimmer_objetproposer($Idobjetproposer){
		Deleteobjetproposer($Idobjetproposer);
	}
		
	}
	?>