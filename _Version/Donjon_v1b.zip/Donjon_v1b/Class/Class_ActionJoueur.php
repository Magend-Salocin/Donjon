<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				   ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		   ****	
	***	Le:				  			   ****	
	***	Motif:			  			   ****											
	***********************************************/

	Class ActionJoueur 
	{ 
		
		
		/*********************************/
		/*		Table Grade   		*/
		/*********************************/
		public function MaListe_grade()
		{
			return Getgrade();
		}
		
		public function Obtenir_grade($Idgrade){
			return GetgradeId($Idgrade);
		}
		
		public function Ajouter_grade($code){
			Insertgrade($code);
		}
		
		public function Modifier_grade($code{
			Updategrade($code);
		}
		
		public function Supprimmer_grade($Idgrade){
			Deletegrade($Idgrade);
		}
		
		/*********************************/
		/*		Table Race   		*/
		/*********************************/
		
		public function MaListe_race()
		{
			return Getrace();
		}
		
		public function Obtenir_race($Idrace){
			return GetraceId($Idrace);
		}
		
		public function Ajouter_race($code,$libelle,$r_pv,$r_pm,$r_for,$r_end,$r_vit,$r_int,$r_dext,$r_cha,$r_man,$r_ppm,$r_village){
			Insertrace($code,$libelle,$r_pv,$r_pm,$r_for,$r_end,$r_vit,$r_int,$r_dext,$r_cha,$r_man,$r_ppm,$r_village);
		}
		
		public function Modifier_race($code,$libelle,$r_pv,$r_pm,$r_for,$r_end,$r_vit,$r_int,$r_dext,$r_cha,$r_man,$r_ppm,$r_village{
			Updaterace($code,$libelle,$r_pv,$r_pm,$r_for,$r_end,$r_vit,$r_int,$r_dext,$r_cha,$r_man,$r_ppm,$r_village);
		}
		
		public function Supprimmer_race($Idrace){
			Deleterace($Idrace);
		}


		

		
	}
	?>