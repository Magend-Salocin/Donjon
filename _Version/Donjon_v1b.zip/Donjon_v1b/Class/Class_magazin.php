<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				           ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		       ****	
	***	Le:				  			           ****	
	***	Motif:			  			           ****											
	***********************************************/

	Class magazin 
	{ 
		public function MaListe_magazin()
		{
			return Getmagazin();
		}
		
		public function Obtenir_magazin($Idmagazin){
			return GetmagazinId($Idmagazin);
		}
		
		public function Ajouter_magazin($code,$libelle,$coord01,$coord02,$coord03,$coord04,$village){
			Insertmagazin($code,$libelle,$coord01,$coord02,$coord03,$coord04,$village);
		}
		
		public function Modifier_magazin($code,$libelle,$coord01,$coord02,$coord03,$coord04,$village{
			Updatemagazin($code,$libelle,$coord01,$coord02,$coord03,$coord04,$village);
		}
		
		public function Supprimmer_magazin($Idmagazin){
			Deletemagazin($Idmagazin);
		}		
	}
	?>