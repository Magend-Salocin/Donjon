<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				           ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		       ****	
	***	Le:				  			           ****	
	***	Motif:			  			           ****											
	***********************************************/

	Class message 
	{ 
		public function MaListe_message()
		{
			return Getmessage();
		}
		
		public function Obtenir_message($Idmessage){
			return GetmessageId($Idmessage);
		}
		
		public function Ajouter_message($code,$a,$de,$date,$sujet,$contenu){
			Insertmessage($code,$a,$de,$date,$sujet,$contenu);
		}
		
		public function Modifier_message($code,$a,$de,$date,$sujet,$contenu{
			Updatemessage($code,$a,$de,$date,$sujet,$contenu);
		}
		
		public function Supprimmer_message($Idmessage){
			Deletemessage($Idmessage);
		}


		

		
	}
	?>