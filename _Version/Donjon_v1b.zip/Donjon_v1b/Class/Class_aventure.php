<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				           ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		       ****	
	***	Le:				  			           ****	
	***	Motif:			  			           ****											
	***********************************************/

	class Aventure 
	{ 
	
		/*********************************/
		/*	Table New		*/
		/*********************************/
		
		function Aventure_Valide($IdAventure,$codeRang,$codevillage) //V�rifie si une aventure est bien rattach� au village  tag =>  Aventure::Aventure_Valide()
		{
		
			$Valide = "false";
			$LesAventure= Aventure::MaListe_aventure($codeRang,$codevillage);
			while($row=GetLigne($LesAventure))	{	
				if($row[0]==$IdAventure){ $Valide = "true"; }
			}
			return $Valide;
		}
		
	
		/*********************************/
		/*	Table Old Aventure		*/
		/*********************************/
		
		
		
	
		/*********************************/
		/*	Table Aventure			*/
		/*********************************/
	
		function MaListe_aventure($rang,$village)
		{
			$rang=$rang+1;
			return Getaventure($rang,$village);
		}
		
		function Obtenir_aventure($Idaventure){
			return GetaventureId($Idaventure);
		}
		
		function Ajouter_aventure($code,$libelle,$resumer,$nbor,$nbexp,$temps,$rang,$image){
			Insertaventure($code,$libelle,$resumer,$nbor,$nbexp,$temps,$rang,$image);
		}
		
		function Modifier_aventure($code,$libelle,$resumer,$nbor,$nbexp,$temps,$rang,$image){
			Updateaventure($code,$libelle,$resumer,$nbor,$nbexp,$temps,$rang,$image);
		}
		
		function Supprimmer_aventure($Idaventure){
			Deleteaventure($Idaventure);
		}
		
		/*********************************/
		/*	Table Aventure En Cour		*/
		/*********************************/
		
		function MaListe_aventureencour()
		{
			return Getaventureencour();
		}
		
		function Obtenir_aventureencour($Idaventureencour){
			return GetaventureencourId($Idaventureencour);
		}
		
		function Ajouter_aventureencour($aven_num,$jou_num,$sec){
			Insertaventureencour($aven_num,$jou_num,$sec);
		}
		
		function Modifier_aventureencour($aven_num,$jou_num,$sec){
			Updateaventureencour($aven_num,$jou_num,$sec);
		}
		
		function Supprimmer_aventureencour($Idaventureencour){
			Deleteaventureencour($Idaventureencour);
		}

		/*********************************/
		/*		Table Accomplir		*/
		/*********************************/
		function MaListe_accomplir()
		{
			return Getaccomplir();
		}
		
		function Obtenir_accomplir($Idaccomplir){
			return GetaccomplirId($Idaccomplir);
		}
		
		function Ajouter_accomplir($aven_num,$jou_num){
			Insertaccomplir($aven_num,$jou_num);
		}
		
		function Modifier_accomplir($aven_num,$jou_num){
			Updateaccomplir($aven_num,$jou_num);
		}
		
		function Supprimmer_accomplir($Idaccomplir){
			Deleteaccomplir($Idaccomplir);
		}
		

		
	}
	?>