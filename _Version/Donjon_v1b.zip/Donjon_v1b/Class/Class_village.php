<?php

	/******AUTEUR*********************************
	***	BERGER NICOLAS 				           ****
	***	EMAIL: Berger.n@hotmail.fr     		   ****
	***	Code Auto-G�n�r�					   ****
	***	Modifi� par  :			  		       ****	
	***	Le:				  			           ****	
	***	Motif:			  			           ****											
	***********************************************/

	Class village 
	{ 
	
		public function MaListe_village()
		{
			return Getvillage();
		}
		
		public function Obtenir_village($Idvillage){
			return GetvillageId($Idvillage);
		}
		
		public function Ajouter_village($code,$libelle,$coord01,$coord02,$coord03){
			Insertvillage($code,$libelle,$coord01,$coord02,$coord03);
		}
		
		public function Modifier_village($code,$libelle,$coord01,$coord02,$coord03{
			Updatevillage($code,$libelle,$coord01,$coord02,$coord03);
		}
		
		public function Supprimmer_village($Idvillage){
			Deletevillage($Idvillage);
		}

		
		/*********************************/
		/*		Table Village Aller	*/
		/*********************************/
		public function MaListe_villagealler()
		{
			return Getvillagealler();
		}
		
		public function Obtenir_villagealler($Idvillagealler){
			return GetvillageallerId($Idvillagealler);
		}
		
		public function Ajouter_villagealler($villagedep,$villagearv,$temps){
			Insertvillagealler($villagedep,$villagearv,$temps);
		}
		
		public function Modifier_villagealler($villagedep,$villagearv,$temps{
			Updatevillagealler($villagedep,$villagearv,$temps);
		}
		
		public function Supprimmer_villagealler($Idvillagealler){
			Deletevillagealler($Idvillagealler);
		}
		

		
	}
	?>