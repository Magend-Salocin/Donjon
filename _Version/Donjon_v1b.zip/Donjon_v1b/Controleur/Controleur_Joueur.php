<?php 
	function GetAuth($nom,$mdp){
		$MaRequete="SELECT * FROM joueur WHERE login= '".$nom."' AND mdp='".$mdp."' ";
		return GetLigne(ExecuteRequete($MaRequete));
	}
	
	function Modif($champs,$nb,$num){	
		$MaRequete="UPDATE joueur SET ".$champs."='".$nb."' WHERE num='".$num."'";
		ExecuteRequete($MaRequete);
	}
	
	function Select($champs,$num){	
		$MaRequete="SELECT ".$champs." FROM  joueur  WHERE num= ".$num." ";
		$MonRs = GetLigne(ExecuteRequete($MaRequete));
		return $MonRs[0];
	}
	
	function GetUtilisateur($num){
		$MaRequete="SELECT * FROM joueur WHERE num= '".$num."'";
		return GetLigne(ExecuteRequete($MaRequete));
	}
	
	function SetJoueur($Tuple){
		$_SESSION["num"] 			= $Tuple['num'];			$_SESSION["nom"] 			= $Tuple['nom'];		
		$_SESSION["pv"] 			= $Tuple['pv'];				$_SESSION["pv2"] 			= $Tuple['pv2'];	
		$_SESSION["pm"] 			= $Tuple['pm'];				$_SESSION["pm2"] 			= $Tuple['pm2'];	
		$_SESSION["forc"] 			= $Tuple['forc'];			$_SESSION["end"] 			= $Tuple['end'];	
		$_SESSION["inti"] 			= $Tuple['inti'];			$_SESSION["dext"] 			= $Tuple['dext'];	
		$_SESSION["vit"] 			= $Tuple['vit'];			$_SESSION["cha"] 			= $Tuple['cha'];
		$_SESSION["man"] 			= $Tuple['man'];			$_SESSION["ppm"] 			= $Tuple['ppm'];
		
		$_SESSION["exp"] 			= $Tuple['exp'];			$_SESSION["ors"] 			= $Tuple['ors'];
		$_SESSION["codeexp"] 		= $Tuple['codeexp'];		$_SESSION["nivsuv"] 		= $Tuple['nivsuv'];	
		
		$_SESSION["cexp"] 			= $Tuple['cexp'];			$_SESSION["nbexp"] 			= $Tuple['nbexp'];	
		$_SESSION["libellerace"] 	= $Tuple['libellerace'];	$_SESSION["libellerang"]	= $Tuple['libellerang'];	
		$_SESSION["village"] 		= $Tuple['village'];		$_SESSION["numclient"] 		= $Tuple['num'];	
		$_SESSION["nomclient"] 		= $Tuple['nom'];			$_SESSION["image"] 			= $Tuple['image'];	
					                
        $_SESSION["Enligne"] 		= $Tuple['Enligne'];		$_SESSION["nbCombat"] 		= $Tuple['nbCombat'];	
		$_SESSION["nbVictoire"] 	= $Tuple['nbVictoire'];		$_SESSION["NbCombatDay"] 	= $Tuple['NbCombatDay'];	
		
		$_SESSION["Arme"] 			= $Tuple['Arme'];			$_SESSION["Bouclier"] 		= $Tuple['Bouclier'];	
		$_SESSION["Casque"] 	    = $Tuple['Casque'];			$_SESSION["Plastron"]		= $Tuple['Plastron'];	
		$_SESSION["AvantBras"] 		= $Tuple['AvantBras'];		$_SESSION["Botte"] 			= $Tuple['Botte'];	
		$_SESSION["Jambiere"] 		= $Tuple['Jambiere'];		
		$_SESSION["tab"] 			= $Tuple;
		
	}
	

	function SetOtherJoueurJavascript($IdJoueur){	
		$OtherHero = GetUtilisateur($IdJoueur);
		SetJoueurJavascript($OtherHero);
	}
	
	function SetJoueurJavascript($heros){
	
		$_SESSION['LesJoueurs'] 			= null;
		$_SESSION['MesPieces'] 				= null;	
		$_SESSION['MesPortes'] 				= null;
		$_SESSION['MesPortesPieceActive'] 	= null;	
		$_SESSION['MesMonstres'] 			= null;
		$_SESSION['LesMonstres'] 			= null;		
		$_SESSION['PieceFouiller'] 			= null;
		$_SESSION['PieceActiver'] 			= null;	

	
			echo " var LeMagend = new Array();" ;
			echo " LeMagend[0]  = '$heros[num]';" ;
			echo " LeMagend[1]  = '$heros[nom]';" ;
			echo " LeMagend[2]  = '$heros[pv]';" ;
			echo " LeMagend[3]  = '$heros[pv2]';" ;
			echo " LeMagend[4]  = '$heros[pm]';" ;
			echo " LeMagend[5]  = '$heros[pm2]';" ;
			echo " LeMagend[6]  = '$heros[forc]';" ;
			echo " LeMagend[7]  = '$heros[end]';" ;
			echo " LeMagend[8]  = '$heros[inti]';" ;
			echo " LeMagend[9]  = '$heros[dext]';" ;
			echo " LeMagend[10] = '$heros[vit]';" ;
			echo " LeMagend[11] = '$heros[dext]';" ;
			echo " LeMagend[12] = '$heros[man]';" ;
			echo " LeMagend[13] = '$heros[ppm]';" ;
			echo " LeMagend[14] = '$heros[exp]';" ;
			echo " LeMagend[15] = '$heros[ors]';" ;
			echo " LeMagend[16] = '$heros[codeexp]';" ;
			echo " LeMagend[17] = '$heros[nivsuv]';" ;
			echo " LeMagend[18] = '$heros[cexp]';" ;
			echo " LeMagend[19] = '$heros[nbexp]';" ;
			echo " LeMagend[20] = '$heros[libellerace]';" ;
			echo " LeMagend[21] = '$heros[libellerang]';" ;
			echo " LeMagend[22] = '$heros[village]';" ;
			echo " LeMagend[23] = '$heros[image]';" ;
			echo " LeMagend[24] = '$heros[Arme]';" ;
			echo " LeMagend[25] = '$heros[Bouclier]';" ;
			echo " LeMagend[26] = '$heros[Casque]';" ;
			echo " LeMagend[27] = '$heros[Plastron]';" ;
			echo " LeMagend[28] = '$heros[AvantBras]';" ;
			echo " LeMagend[29] = '$heros[Botte]';" ;
			echo " LeMagend[30] = '$heros[Jambiere]';" ;
			$img = GetImageRaceJeu($heros['libellerace']);
			$img2 = GetImageRaceJeu2($heros['libellerace']);
			
echo "
	//  Nom - Attaque -  Defence - Corp - Esprit - Position - Image - Piece - Attaquer	-ChercherTresor	 - Or	- deplacement	JOUEUR - otherimg
	//   0  -   1     -    2     -  3  -    4   -    5     -   6   -   7    -  8 -          9              10 -          11         12 -     13
LesJoueurs[LesJoueurs.length] = new Array('$heros[nom]','$heros[forc]','$heros[end]','$heros[pv2]','2',PositionDepart,'$img','PieceDepart','0','0','$heros[ors]','0','LeMagend','$img2');
PositionDepart = PositionDepart-1;	
";			
	}
	
	
	function GetJoueurJavascript(){
		echo " var LeMagend = new Array();" ;
		echo " LeMagend[0]  = '$_SESSION[num]';" ;
		echo " LeMagend[1]  = '$_SESSION[nom]';" ;
		echo " LeMagend[2]  = '$_SESSION[pv]';" ;
		echo " LeMagend[3]  = '$_SESSION[pv2]';" ;
		echo " LeMagend[4]  = '$_SESSION[pm]';" ;
		echo " LeMagend[5]  = '$_SESSION[pm2]';" ;
		echo " LeMagend[6]  = '$_SESSION[forc]';" ;
		echo " LeMagend[7]  = '$_SESSION[end]';" ;
		echo " LeMagend[8]  = '$_SESSION[inti]';" ;
		echo " LeMagend[9]  = '$_SESSION[dext]';" ;
		echo " LeMagend[10] = '$_SESSION[vit]';" ;
		echo " LeMagend[11] = '$_SESSION[dext]';" ;
		echo " LeMagend[12] = '$_SESSION[man]';" ;
		echo " LeMagend[13] = '$_SESSION[ppm]';" ;
		echo " LeMagend[14] = '$_SESSION[exp]';" ;
		echo " LeMagend[15] = '$_SESSION[ors]';" ;
		echo " LeMagend[16] = '$_SESSION[codeexp]';" ;
		echo " LeMagend[17] = '$_SESSION[nivsuv]';" ;
		echo " LeMagend[18] = '$_SESSION[cexp]';" ;
		echo " LeMagend[19] = '$_SESSION[nbexp]';" ;
		echo " LeMagend[20] = '$_SESSION[libellerace]';" ;
		echo " LeMagend[21] = '$_SESSION[libellerang]';" ;
		echo " LeMagend[22] = '$_SESSION[village]';" ;
		echo " LeMagend[23] = '$_SESSION[image]';" ;
		echo " LeMagend[24] = '$_SESSION[Arme]';" ;
		echo " LeMagend[25] = '$_SESSION[Bouclier]';" ;
		echo " LeMagend[26] = '$_SESSION[Casque]';" ;
		echo " LeMagend[27] = '$_SESSION[Plastron]';" ;
		echo " LeMagend[28] = '$_SESSION[AvantBras]';" ;
		echo " LeMagend[29] = '$_SESSION[Botte]';" ;
		echo " LeMagend[30] = '$_SESSION[Jambiere]';" ;
		
	}
	
	function RestaureParmAjax($chaine){
		$MaChaine = null;
		$W = split(",,",$chaine);
		for($i=0;$i<sizeof($W);$i++){
		if($W[$i]!=null && $W[$i]!=""){
			$MaChaine .= "".$W[$i].",";
			}
		}
		$MaChaine .= "".$W[$i++]."";
		return $MaChaine;
	}
	

	
	function RestaureParm($chaine){
	$Firt=false;
		$MaChaine = null;
		$W = split(",",$chaine);
		for($i=0;$i<sizeof($W);$i++){
			if($W[$i]!=""){
				if($Firt==false){
				$MaChaine .= "'".$W[$i]."'";
				$Firt=true;
				}
				else{
				$MaChaine .= ",'".$W[$i]."'";
				}
			}
		}
		//$MaChaine .= "'".$W[$i++]."'";
		return $MaChaine;
	}
	
	function RestaureParmMonstre($chaine){
		$MaChaine = null;
		$Firt=false;
		$LesMonstre = split("@",$chaine);
		for($i=0;$i<sizeof($LesMonstre)-1;$i++){
		
		
	    
			$UnMonstre = split(",",$LesMonstre[$i]);
			$MaChaine .= "LesMonstres[$i]  = new Array(";
			for($j=0;$j<sizeof($UnMonstre);$j++){
			
			
				if($Firt==false){
				$MaChaine .= "'".$UnMonstre[$j]."'";
				$Firt=true;
				}
				else{
				$MaChaine .= ",'".$UnMonstre[$j]."'";
				}
				
			}
			$Firt=false;
			$MaChaine .= ");\n ";
			//$MaChaine .= "'".$UnMonstre[$j++]."');";
		}
			
		return $MaChaine;
	}
	
	
	
	function ReloadPartieMyHero(){
	
		$LesJoueurs 			= RestaureParm($_SESSION['LesJoueurs']);
		$MesPieces 				= RestaureParm($_SESSION['MesPieces']);
		$MesPortes 				= RestaureParm($_SESSION['MesPortes']);
		$MesPortesPieceActive 	= RestaureParm($_SESSION['MesPortesPieceActive']);
		$MesMonstres 			= RestaureParm($_SESSION['MesMonstres']);
		$MesPieges 				= RestaureParm($_SESSION['MesPieges']);
		$LesMonstres 			= RestaureParmMonstre($_SESSION['LesMonstres']);
		$PieceFouiller 			= RestaureParm($_SESSION['PieceFouiller']);
		$PieceActiver 			= RestaureParm($_SESSION['PieceActiver']);
		$FinAventure 			= $_SESSION['FinAventure'];
		GetJoueurJavascript();
		echo "\n  LesJoueurs   		= new Array();\n";
		echo "LesJoueurs[0] 			= new Array($LesJoueurs);\n";
		echo "LesJoueurs[0][12] 			= LeMagend; \n";
		echo "LesJoueurs[0][13] 			= '".GetImageRaceJeu2($_SESSION['libellerace'])."' ; \n";
		echo " MesPieces   			= new Array($MesPieces);\n";
		echo " MesPortes   			= new Array($MesPortes);\n";
		echo " MesPortesPieceActive  = new Array($MesPortesPieceActive);\n";
		echo " MesMonstres   		= new Array($MesMonstres);\n";
		echo " MesPieges   		= new Array($MesPieges);\n";
		echo " LesMonstres   		= new Array();\n";
		
		
		echo $LesMonstres ;
		echo "\n  PieceFouiller   		= new Array($PieceFouiller);\n";
		echo "\n  PieceActiver   		= new Array($PieceActiver);\n";
		//echo "\n var FinAventure   		= $FinAventure;  \n $FinAventure ";
		
		
	}
	
	function aventureRec($heros,$aventure,$date,$libelle){
		DelAventure($heros);
		$sql = "INSERT INTO aventureencour  ( aven_num, jou_num ,  sec , libelle ) VALUES ('$aventure', '$heros' , '$date' , '$libelle')";
		ExecuteRequete($sql);
	}
	
	function GetAventureEnCour($heros){
		$MaRequete="SELECT * FROM  aventureencour  WHERE jou_num= '".$heros."' ";
		return GetLigne(ExecuteRequete($MaRequete));
	}
	
	function DelAventure($IdHeros){
		$sql = "DELETE FROM aventureencour  WHERE  jou_num= '".$IdHeros."'"; 
		ExecuteRequete($sql);
	}
	
	function affichErreur($erreur){
		if ($erreur=="pv"){$text="Vous ne pouvez utiliser cette objet votre vie est au max";}
		if ($erreur=="pm"){$text="Vous ne pouvez utiliser cette objet vos point de magie sont au max";}
		return  "<div align=left><font color=red> $text </font></div>";
	}
	
	function afficheText($id,$type){
		if ($type=="item"){$text="Vous venez d'utiliser $id";}
		if ($type=="equip"){$text="Vous etez &eacute;qiper de $id";}
		if ($type=="dequip"){$text="Vous etez d'&eacute;quiper de $id";}

		return "<div align=left><font color=green> $text </font></div>";
	}
	
	
	
	
	
	
	function GetImageRaceJeu($LibelleRace){
		$iconImage=null;
		switch ($LibelleRace){	
		   case "Nain":		$iconImage='Javascript/HeroQuest_V2/images/avatars/02.jpg';	break;
		   case "Elfe":		$iconImage='Javascript/HeroQuest_V2/images/avatars/03.jpg';	break;
		   case "Humain":	$iconImage='Javascript/HeroQuest_V2/images/avatars/00.jpg';	break;
		   case "Ogre":		$iconImage='Javascript/HeroQuest_V2/images/avatars/09.bmp';	break;
		   }
		return 	$iconImage;
	}
	
	function GetImageRaceJeu2($LibelleRace){
		$iconImage=null;
		switch ($LibelleRace){	
		   case "Nain":		$iconImage='Javascript/HeroQuest_V2/images/avatars/W02.png';	break;
		   case "Elfe":		$iconImage='Javascript/HeroQuest_V2/images/avatars/W03.png';	break;
		   case "Humain":	$iconImage='Javascript/HeroQuest_V2/images/avatars/W00.png';	break;
		   case "Ogre":		$iconImage='Javascript/HeroQuest_V2/images/avatars/W09.png';	break;
		   }
		return 	$iconImage;
	}
	
	
		function GetImageRace($LibelleRace){
		$iconImage=null;
		switch ($LibelleRace){	
		   case "Nain":		$iconImage='image/personnage/NLB_nain.png';	break;
		   case "Elfe":		$iconImage='image/personnage/NLB_elfe.png';	break;
		   case "Humain":	$iconImage='image/personnage/NLB_aventurier.png';	break;
		   case "Ogre":		$iconImage='image/personnage/NLB_ogre.png';	break;
		   }
		return 	$iconImage;
	}
	
?>