<?php

	if(!isset($_SESSION["tab"])) $_SESSION["tab"]=null;
	if(!isset($_SESSION["num"])) $_SESSION["num"]=null;
	if(!isset($_SESSION["libellerang"])) $_SESSION["libellerang"]=null;
	$ControleurMagazin = false;
	
	
	if ( isset($_GET['passage']) ){//V?fie les identifiant de connection d'un utilisateur
			$Tuple=GetAuth($_GET['nom'],$_GET['mdp']);
			SetJoueur($Tuple);//	Modif("Enligne",$HeureActuelle,$_SESSION["num"]);
	}


	$Nivsup=false;	
	$HeureActuelle=time();	$_SESSION["time"]=$HeureActuelle;	
	$heros=$_SESSION["tab"];	$IdHero=$_SESSION["num"]; 
	$attaque= $heros["forc"]  + $heros["vit"]   ;	$attaque=$attaque*2;
	$defence= $heros["dext"]  + $heros["end"]  ;	$defence=$defence*2;
	$MyTexte = null;
	//echo $IdHero." <========<br />";
	
/*INVENTAIRE*/
	if ( isset($_GET['item']) )					{ GetUtiliseObjet($_GET['item'],$IdHero); 	}	
	if ( isset($_GET['Equiper']) )				{ GetEquipeObjet($_GET['Equiper'],$IdHero); }
	if ( isset($_GET['RetirerEquipement']) )	{ GetDeequipeObjet($_GET['RetirerEquipement'],$IdHero); }
/*INVENTAIRE*/	
	
/*DEFIS*/	
	if(isset($_GET['adversaire'])){	if ($heros['NbCombatDay']<60) {	SetDefis($HeureActuelle,$_GET['adversaire'],$heros["num"],$heros["village"]); }		}
/*DEFIS*/

/*MAGAZIN*/		

	
	if ( isset($_GET['magazin']) ){ $ControleurMagazin=GetLeMagazin($_SESSION["village"],$_GET['magazin']);}
	if ( isset($_POST['PostMagazin']) ){ $ControleurMagazin=GetLeMagazin($_SESSION["village"],$_POST['PostMagazin']);}
	if ($ControleurMagazin==true){

		if ( isset($_GET['MagazinItem']) ){ GetAcheter($_GET['MagazinItem'],$_SESSION["ors"],$IdHero,$_GET['magazin']); }
		if ( isset($_POST['PostMagazin']) ){ $LesObjets=GetLesObjet($_POST['PostMagazin']); }
		else{ $LesObjets=GetLesObjet($_GET['magazin']); }
	}
/*MAGAZIN*/	

/*AVENTURE*/
	$codeRang=GetGrade($_SESSION["libellerang"]);					$fatiguer=GetCapable($IdHero);
/*AVENTURE*/

	if (isset($_GET["var"])){
		$toto=$_GET["var"];	$heros["$toto"]="rien";
		Modif($toto,"rien",$IdHero);	SetJoueur($heros);
	}
	


	if ( isset($_POST['finaventure'])  ) {//Permet de finir les mission quand le temps est ?ul?
		$goavan = $_POST['finaventure']; 
		SetFinMission($_POST['aventure'],$IdHero); 
		DelAventure($IdHero);
	}	else { $goavan =0; }

	if ( isset($_POST['finvoyage']) ) { //Permet de finir le voyage quand le temps est ?ul?		$goavan = $_POST['finvoyage']; 
		Modif("village",$_POST['village'],$IdHero); $_SESSION["village"]=$_POST['village'];
		DelAventure($IdHero); 
		$govillage =1;
	}	else { $govillage =0; }
	
	if(isset($_SESSION["num"])) { 
		$Auth=1; $heros=$_SESSION["tab"]; 	$exp=$heros["exp"];	 $nivsuv=$heros["nivsuv"];
		
		if($heros["codeexp"] > 1){ 
			$moy=$heros["nivsuv"] /3;	
			$exp=$heros["exp"]-$moy;	
			$nivsuv=$heros["nivsuv"]-$moy; 
		}
		
		if($heros["exp"]==$heros["nivsuv"]  || $heros["exp"] > $heros["nivsuv"] ){ //Permet de d?nir le niveau suivant
			if($heros["cexp"] ==0){
			Modif("cexp",1,$IdHero); 	Modif("nbexp",5,$IdHero); 
			$_SESSION["cexp"]=1;			 $_SESSION["nbexp"]=5; 
			$Nivsup=true;
			}
		}
		
		if ( isset($_GET['village']) && $goavan==0) 
		{ $dateAventure=time();	aventureRec($IdHero,$_GET['village'],$dateAventure,"V"); }
		if ( isset($_GET['mission']) && $goavan==0) 
		{ 	
	
			if(Aventure::Aventure_Valide($_GET['mission'],$codeRang,$_SESSION["village"])==true){
				$dateAventure=time();	aventureRec($IdHero,$_GET['mission'],$dateAventure,"A");
				$_SESSION["AventureEnCour"]= $_GET['mission'];
			}
	
		}
	}	
	else{ $Auth=0; }
	
	
	/***MON COMPTE***/
	if ( isset($_POST['ChangePassword']) ){
		if($heros["mdp"] == $_POST['oldMdp'] && $_POST['newMDP'] == $_POST['confMDP'] ){
		
			Modif("mdp",$_POST['newMDP'],$IdHero);
			$MyTexte ="Mot de passe Changer";
		}
	}
	
?>