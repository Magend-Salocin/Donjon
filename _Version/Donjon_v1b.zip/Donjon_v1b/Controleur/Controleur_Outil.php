<?php 
	function getbarre($couleur,$min,$max){
		$barre=$min*300/$max;
		echo"<TABLE  style='PADDING-RIGHT: 4px; PADDING-LEFT: 4px; PADDING-BOTTOM: 1px; PADDING-TOP: 1px; BORDER-COLLAPSE: collapse' borderColorDark=#000000 cellPadding=0 width=300  borderColorLight=#000000>";
		echo "<tr><TD width='75%' style='BORDER-RIGHT: #000000 1px solid; 
						PADDING-RIGHT: 0px; 
						BORDER-TOP: #000000 1px solid; 
						PADDING-LEFT: 0px; 
						PADDING-BOTTOM: 0px; 
						BORDER-LEFT: #000000 1px solid; 
						PADDING-TOP: 0px; 
						BORDER-BOTTOM: #000000 1px solid' 
		                bgColor=#f3f3f3 width='10%'>";
		echo "<IMG id='MyHeroBarrePv' height=10 src='image/$couleur' width=$barre border='0'></td></tr></table>";
	}

	function getbarre2($couleur,$min,$max){
		$min=$min*2;
		$barre=$min*100/$max;
		echo"<TABLE  style='PADDING-RIGHT: 4px; PADDING-LEFT: 4px; PADDING-BOTTOM: 1px; PADDING-TOP: 1px; BORDER-COLLAPSE: collapse' borderColorDark=#000000 cellPadding=0 width=200  borderColorLight=#000000>";
		echo "<tr><TD width='50%' style='BORDER-RIGHT: #000000 1px solid; 
						PADDING-RIGHT: 0px; 
						BORDER-TOP: #000000 1px solid; 
						PADDING-LEFT: 0px; 
						PADDING-BOTTOM: 0px; 
						BORDER-LEFT: #000000 1px solid; 
						PADDING-TOP: 0px; 
						BORDER-BOTTOM: #000000 1px solid' 
		                bgColor=#f3f3f3 width='10%' >";
				
		echo "<IMG height=10 src='image/$couleur' width=$barre border='0'></td></tr></table>";
	}
	
	function timer($temps){?>
		<div class="menu_separator">
				<div class="separator_text">Temps pour </div>
			<div id="generals">
				<p><strong>Mission en cours.</strong></p>
				<div id="missiontime">Chargement...</div>
			</div>
		</div>
		<script type="text/javascript">
		  v=new Date();
		  var bxx=document.getElementById('missiontime');
		  function t(ss){
		    n=new Date();
		    s=ss-Math.round((n.getTime()-v.getTime())/1000.);
		    m=0;h=0;
		    if(s<0){
		      bxx.innerHTML='Mission terminee!<br />';
			  document.aventure.submit();
			 
			
		    }else{
		      if(s>59){
		        m=Math.floor(s/60);
		        s=s-m*60
		      }
		      if(m>59){
		        h=Math.floor(m/60);
		        m=m-h*60
		      }
		      if(s<10){
		        s="0"+s
		      }
		      if(m<10){
		        m="0"+m
		      }
		      bxx.innerHTML=h+":"+m+":"+s+"  restant<br />"
		    }
		    window.setTimeout("t('<?php echo $temps;?>');",999);
		  }
		  window.onload=t;
		</script>
		<?php 
	
	}
	
		function timer2($temps){?>
		<div class="menu_separator">
			<div class="separator_text">Temps pour </div>
			<div id="generals">
				<p><strong>Voyage en cours.</strong></p>
				<div id="missiontime">Chargement...</div>
			</div>
		</div>
		<script type="text/javascript">
		  v=new Date();
		  var bxx=document.getElementById('missiontime');
		  function t(ss){
		    n=new Date();
		    s=ss-Math.round((n.getTime()-v.getTime())/1000.);
		    m=0;h=0;
		    if(s<0){
		      bxx.innerHTML='Voyage terminee!<br />';
			  document.voyage.submit();
			
		    }else{
		      if(s>59){
		        m=Math.floor(s/60);
		        s=s-m*60
		      }
		      if(m>59){
		        h=Math.floor(m/60);
		        m=m-h*60
		      }
		      if(s<10){
		        s="0"+s
		      }
		      if(m<10){
		        m="0"+m
		      }
		      bxx.innerHTML=h+":"+m+":"+s+"  restant<br />"
		    }
		    window.setTimeout("t('<?php echo $temps;?>');",999);
		  }
		  window.onload=t;
		</script><?php 
	
	}
?>