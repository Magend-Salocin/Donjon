<?php 
	Function OpenFichierChat(){
	
		$village="Module/Chatte/" . $_SESSION["village"].".txt";
		$monfichier =fopen($village,"r+");
	return $monfichier ;
	}
	
	
	Function DelFichierChat(){
		$village="Module/Chatte/" . $_SESSION["village"].".txt";
		$monfichier =fopen($village,"w+");
		fclose($monfichier); 
	}
	
	
	Function GetAllMessageChat(){
		//AFFICHAGE DES DONNEES 
		$monfichier =OpenFichierChat();
		echo "<select size='15' width='100' name='race'> ";
		echo '<OPTION> ------------Forum-----de-------la------taverne-------</OPTION><OPTION>  </OPTION>';
			while ($ligne= fgets($monfichier)){
				$text = split(";",$ligne); 	$long = strlen($text[1]);
				
				echo '<OPTION><b>' .$text[0]. '</b> a ecrit :</OPTION>';
		
				if ($long<28){ echo '<OPTION>' .$text[1]. '</OPTION><OPTION>  </OPTION>'; }
				else{ 
					while ($long>28){
					echo '<OPTION>' .substr($text[1] ,$long,28). '</OPTION><OPTION> %%% </OPTION>';
					$long=$long-28;
					}
					echo '<OPTION>' .substr($text[1] ,$long,$long). '</OPTION><OPTION>  </OPTION>';
				}
			}	
		echo "</select> ";
		fclose($monfichier);
	}
	
	
	Function SetMessageChat($pseudo,$message){
		
		//ECRITURE DES VALEURS DANS UN TABLEAU
		$monfichier =OpenFichierChat();$i=0;
		while ($ligne= fgets($monfichier)){ 
			$row[$i]=$ligne; $i++; 
			}
		fclose($monfichier);
		
		//EFFACEMENT DU FICHIER 
		DelFichierChat(); 
		
		//ECRITURE DU TABLEAU DANS LE FICHIERS
			$monfichier =OpenFichierChat();
			$pop=$pseudo.';'.$message;	$i=0;
			fputs($monfichier,$pop);fputs($monfichier,"\n"); 
			while ($i<9){ 
			fputs($monfichier,$row[$i]);	$i++; 
			}
		fclose($monfichier);
	}
?>