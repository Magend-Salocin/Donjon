	<?php
		include ("ControleurChat.php");  
		
		if ( isset($_POST['message'])){
			//RECUPERATION DES VARIABLE DU FORMULAIRE
		    $message = htmlspecialchars($_POST['message']); 
		    $message = nl2br($message); 
			
			//ENREGISTREMENT DU NOUVEAU MESSAGE
			SetMessageChat($heros["nom"],$message);
		}
		GetAllMessageChat()
	?>
	 Message :
	<table ><tr><td colspan="2"  align="center" >
	<form method="post" action="">
	    <p>
	       
	        <input type="text" name="message" size="30" width="130" /></td></tr>
	        <tr><td align="center" ><input type="submit" value="Clamer" ></td>
	    </p>
    </form>

	<td align="center"><form method="post" action=""><input type="submit" value="Ouir" ></form></td></tr>
	</table>