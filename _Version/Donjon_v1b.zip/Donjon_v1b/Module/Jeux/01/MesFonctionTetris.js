	var  ok      = null;
	var formCour = null;
	var formNext = null;
	var cases    = new Array();
	var formes   = new Array();
	var niveau   = 1;
	var point    = 0;
	var ligne = 0;
	var pause = false;
	var fin = true;
	// couleurs de diff�rentes formes du jeux
	var coulForme = new Array("#81e0f5","#0eb16c","#404fff","#fcd836","#c681f5","#7ffd29","#ff0000");
	// Tableaux qui donnes la position g�ographique de chaque cube (4 cubes) 
	//  qui compose une formes a partir de la coordonn� 0,0 (y,x) du coin inferieur gauche
	//  d'un tableau de 4X4 et ce pour chacune des rotations possibles 
	//  donc 4 cubes par formes *  4 rotations = 16 coordonn�es (y,x) par formes
	formes[0] = new Array(-1,0,-1,1,0,1,0,2,-2,1,-1,1,-1,0,0,0,-1,0,-1,1,0,1,0,2,-2,1,-1,1,-1,0,0,0);
	formes[1] = new Array(0,0,0,1,-1,1,-1,2,-2,0,-1,0,-1,1,0,1,0,0,0,1,-1,1,-1,2,-2,0,-1,0,-1,1,0,1);
	formes[2] = new Array(-1,1,-1,2,0,1,0,2,-1,1,-1,2,0,1,0,2,-1,1,-1,2,0,1,0,2,-1,1,-1,2,0,1,0,2);
	formes[3] = new Array(0,2,0,1,0,0,-1,0,0,1,-1,1,-2,1,-2,2,-1,0,-1,1,-1,2,0,2,-2,1,-1,1,0,1,0,0);
	formes[4] = new Array(0,0,0,1,0,2,-1,2,-2,1,-1,1,0,1,0,2,-1,2,-1,1,-1,0,0,0,0,1,-1,1,-2,1,-2,0);
	formes[5] = new Array(0,0,0,1,0,2,0,3,-3,1,-2,1,-1,1,0,1,0,0,0,1,0,2,0,3,-3,1,-2,1,-1,1,0,1);
	formes[6] = new Array(-1,0,-1,1,-1,2,0,1,-2,1,-1,1,0,1,-1,0,0,2,0,1,0,0,-1,1,0,0,-1,0,-2,0,-1,1);
	var tailleCase = 25;
	var nbCaseX  = 12;
	var nbCaseY  = 22;
	var taille = tailleCase + (document.all?0:-2);
	var rebord = (document.all)?0:2;
	var posx,posy; 
	var formCour, formSuiv;

	// objet cube (un simple DIV) qui fait partie d'un objet forme
	function cube(y,x,py,px,coul){
	  this.el = document.createElement("div");
	  this.el.style.position = "absolute";
	  this.el.style.top = ((taille+rebord)*(y+py))+"px";
	  this.el.style.left = ((taille+rebord)*(x+px))+"px";
	  this.el.style.display = (y+py>=0)?"block":"none";
	  this.el.style.width = taille+"px";
	  this.el.style.height = taille+"px";
	  this.el.style.backgroundColor = coul;
	  this.el.style.border="1px black solid";
	  this.el.style.fontSize = "0px";
	}

	// objet forme (une des formes du jeu de 0-6) avec ses 4 objets cubes (4 DIVs)
	function forme(no,py,px,leDiv){
	  var i,j;
	  this.cubes = new Array();
	  this.rotation = 0;
	  this.no = no;
	  for (i =0, j=0;i<8;i = i+2,j++){
	    this.cubes[j] = new cube(formes[no][i],formes[no][i+1],py,px,coulForme[no])
		leDiv.appendChild(this.cubes[j].el);
	  }
	}

	// fonction qui g�re les d�placement d'une formes dans le jeu (gauche, droite, rotation), 
	// si la forme ne peut pas se d�placer, la fonction retourne un booleen faux
	function deplacerForme(nbY, nbX, plusRotation,py,px){ 
	   var i,j,x,y,rotation;
	   rotation = (formCour.rotation + plusRotation);
	   rotation = rotation<0?3:rotation>3?0:rotation;
	   // v�rifier avant le d�placement si les cubes peuvent se d�placer dans des cases vides
	   for (i =rotation*8,j=0;i<(rotation*8)+8;i = i+2,j++){ 
		  y = formes[formCour.no][i] + py + nbY;
		  x = formes[formCour.no][i+1] + px + nbX;
		  if (x==-1 || y==nbCaseY || x==nbCaseX || (cases[y] && cases[y][x]!=null)) return false;
	   }
	    formCour.rotation = rotation;
	    py = py + nbY;
	    px = px + nbX;
		// faire le d�placement de cubes de la forme (droite, gauche ou rotation)
	   for (i =rotation*8,j=0;i<(rotation*8)+8;i = i+2,j++){ 
		y = (formes[formCour.no][i] + py);
		formCour.cubes[j].el.style.display = (y>=0)?"block":"none";
		formCour.cubes[j].el.style.top = ((taille+rebord) * y)+"px";
	    formCour.cubes[j].el.style.left = ((taille+rebord) * (formes[formCour.no][i+1] + px))+"px";
	  }
	  return true;
	}

	// initialisation du jeu, cr�ation du tableau du jeu, appel� une seul fois  
	function initialiserJeux(){
	   var tbl,tb,cols,rows,row,col;
	   bord = document.getElementById("jeux");
	   prochain = document.getElementById("next");
	   bord.style.width = tailleCase * nbCaseX;
	   bord.style.height = tailleCase * nbCaseY;  
	   bord.style.backgroundColor = "#8f8f8f"; 
	   tbl = document.createElement("table");
	   tb= document.createElement("tbody");
	   tbl.appendChild(tb);
	   tbl.cellSpacing="0";
	   tbl.cellPadding="0";
	   tbl.width = tailleCase * nbCaseX;
	   tbl.height = tailleCase * nbCaseY;
	   for (rows=0;rows<nbCaseY;rows++){
	     row = document.createElement("TR");
		 for (cols=0;cols<nbCaseX;cols++){
		    col = document.createElement("td");
			col.className="caseTB";
			col.innerHTML="&nbsp;";
			row.appendChild(col);
		 }
		 tbl.lastChild.appendChild(row);
	   }
	   bord.appendChild(tbl);
	   document.key.down.focus();
	   document.key.down.onkeydown = verifierActionJoueur;
	}

	// d�buter une nouvelle partie, initialisation des variables, appel� a chaques d�but de partie.
	function nouvellePartie(){
	   var i;
	   initCases();
	   if (formCour && !fin){
	      for (i=0; i<4;i++)
		      bord.removeChild(formCour.cubes[i].el);
	   }
	   posx = ((nbCaseX / 2)-2);
	   posy = -1;
	   vitesse = 650;
	   niveau = 1;
	   point   = 0;
	   ligne = 0;
	   fin = false;
	   // cr�ation des deux obet forme.  La forme suivante et la forme courante
	   formNext =new forme( Math.floor(Math.random()*formes.length),1,0,prochain);
	   formCour =new forme( Math.floor(Math.random()*formes.length),posy,posx,bord);
	   pts = setInterval("majPointage()",1000);
	   setTimeout("partieEnCour()",vitesse);
	}

// fonction qui boucle en interuption a une vitesse variable pour le d�placement vers le bas des formes du jeu.  
//   elle d�termine si 'une forme ne peut plus se d�placer vers le bas.
//   elle d�termine si une ligne a �t� complet� et la d�truit si c'est le cas
//   elle �value la fin de la partie lorqu'une forme ne peu plus �tre ajouter dans le tableau.
	function partieEnCour(){ 
	    var x,y,i,cols;
		if (!deplacerForme(1,0,0,posy,posx)){
		   point = point + niveau;
		   var Y = new Array();
	       for (i =formCour.rotation*8,j=0;i<(formCour.rotation*8)+8;i = i+2,j++){ 
			  prochain.removeChild(formNext.cubes[j].el);
			  y = formes[formCour.no][i] + posy;
			  Y[Y.length] = y;
		      x = formes[formCour.no][i+1] + posx;
			  if (y>=0) {
			    cases[y][x] = formCour.cubes[j].el;
			  } 
	       }
		   Y.sort();
		   for (i=0;i<Y.length;i++){
		   	   if (i==0 || ( i>0 && Y[i]!=Y[i-1])){
			      for (cols=0;cols<nbCaseX;cols++)
		            if (cases[Y[i]] && cases[Y[i]][cols]==null) break;
			      if (cols==nbCaseX) enleverLignePleine(Y[i]);
			   }
		   }
	       if (posy==-1) {
		      fin = true;
		      clearTimeout(ok);
			  clearInterval(pts);
			  majPointage();
			  document.main.start.value = "COMMENCER";
			  alert("Partie Termin�e!!!");
			  return;
		   }
		   posx = ((nbCaseX / 2)-2);
	       posy = -1;
	       formCour = new forme(formNext.no,posy,posx,bord);
		   formNext = new forme( Math.floor(Math.random()*formes.length),1,0,prochain);
	    }
		else{posy++;}
	    ok = setTimeout("partieEnCour()",vitesse);
	}

	// fonction qui enl�ves les lignes pleines.  chacun des cubes (DIV) de la ligne Y sont retir�s et les cubes au dessus decendes d'une rang�e
	function enleverLignePleine(y){ 
	   ligne++;
	   point = point + 100;
	   niveau = Math.floor(ligne/5)+1;
	   vitesse = 700 - (niveau * 65)
	   var rows,cols;
	   for (rows=y;rows>=0;rows--)
		 for (cols=0;cols<nbCaseX;cols++){
	         if (rows!=y){
			    if (cases[rows][cols]!=null)
				   cases[rows][cols].style.top = (cases[rows][cols].offsetTop + taille + rebord)+"px";
			    cases[rows+1][cols] = cases[rows][cols];
				cases[rows][cols]= null;
			 }
			 else
	 		    bord.removeChild(cases[rows][cols]);
		 } 
	}

	// vide le tableau cases qui contient les cubes (objet DIV) qui se sont fix� au tableau du jeux lorsqu'un forme ne bouge plus. 
	function initCases(){
	   var rows,cols;
	   for (rows=0;rows<nbCaseY;rows++){
	      if (!cases[rows]) cases[rows] = new Array();
		 for (cols=0;cols<nbCaseX;cols++){
	         if (cases[rows][cols])
				  bord.removeChild(cases[rows][cols]);
			 cases[rows][cols] = null;
		 } 
	   }
	}

	// v�rification des touches fl�che et espace et effectus le d�placement correspondant
	function verifierActionJoueur(ev){
	    if (pause) return;
		var keyPress = document.all?event.keyCode:ev.which;
		if (keyPress == 37) 
		   if (deplacerForme(0,-1,0,posy,posx)) posx--; 
	    if (keyPress == 39) 
		   if(deplacerForme(0,1,0,posy,posx)) posx++;
		if (keyPress == 38) deplacerForme(0,0,-1,posy,posx)
		if (keyPress == 40) deplacerForme(0,0,1,posy,posx)
	    if (keyPress == 32) {while(deplacerForme(1,0,0,posy,posx)){posy++;point = point + niveau;}}
	}

	function majPointage(){
	   document.main.points.value = point;
	   document.main.niveaux.value = niveau;
	   document.main.lignes.value = ligne;
	}

	function topElement(e){ 
	   return  ((e && topElement != topElement.caller)?e.offsetTop:0) + ((e && e.offsetParent)?e.offsetParent.offsetTop + topElement(e.offsetParent):0);
	}

	function leftElement(e){
	   return ((e && leftElement != leftElement.caller)?e.offsetLeft:0) + ((e && e.offsetParent)?e.offsetParent.offsetLeft + leftElement(e.offsetParent):0);
	}

	function help(){
	   var h = document.getElementById("aide");
	   var j = document.getElementById("posJeux");
	   h.style.top = topElement(j)
	  h.style.left = leftElement(j)
	  if (!pause && !fin) document.main.start.onclick();
	  h.style.display = "block"
	}