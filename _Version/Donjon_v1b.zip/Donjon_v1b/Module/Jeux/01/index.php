<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Tetris By Chupetta</title>
	

<STYLE type="text/css">
  body {background-color:#d2d2d2;color:#000000;font-family:tahoma;}
  input {background-color:#e6e6e6;width:120px;}
  .caseTB {background-color:#8f8f8f;border:1px #f8cc8b inset;width:25px;height:25px;font-size:5px;}
  .inpText {background-color:#9f9f9f;width:70px;border:0px;border-bottom:1px black solid;text-align:right;}
  #aide {width:430px;height:400px;background-color:#d2d2d2;overflow:auto;font-family:arial;font-size:14px;position:absolute;display:none;}
   p {margin:5px;}
   p.para {text-align:justify;text-justify:auto;}
   p.para:first-letter {font-weight:bold;}
</STYLE>
<script src="MesFonctionTetris.js"></script>
</head>
<body onload="initialiserJeux()" onclick="document.key.down.focus();">
<table width="100%" height="100%" border="0" bgcolor="#d2d2d2">
<tr><td align="center" valign="middle">
<table id="posJeux" style="border:6px #8f8f8f groove;" width="530" height="500" border="0" cellpadding="0" cellspacing="0" bgcolor="#e6e6e6">
<tr>
<td width="55%" align="center">
<div style="position:relative;">
<div style="position:relative;" id="jeux"></div></div></td>
<td width="45%" align="center" bgcolor="#9f9f9f"><span style="font-size:22px;font-weight:bold;">TETRIS ^!^</span></br></br>
    <table border="0" width="110px"  height="60px" bgcolor="#8f8f8f">
	            <tr><td height="30px;" align="center">
				<div>
				<div id="next"  style="position:relative;">
				  <table cellpadding="0" cellspacing="0" bgcolor="#8f8f8f" width="100px" height="50px">
				  <tr><td class="caseTB">&nbsp;</td><td class="caseTB">&nbsp;</td><td class="caseTB">&nbsp;</td><td class="caseTB">&nbsp;</td></tr>
				  <tr><td class="caseTB">&nbsp;</td><td class="caseTB">&nbsp;</td><td class="caseTB">&nbsp;</td><td class="caseTB">&nbsp;</td></tr>
				  </table>
				</div></div></td></tr>
	</table>
	<br><br>
	<form name="main">
	&nbsp;<input type="button" name="start" value="COMMENCER" onclick="clearTimeout(ok);if (pause) {pause=false;partieEnCour();this.value='PAUSE'} else {if (this.value=='COMMENCER') {nouvellePartie();this.value='PAUSE'} else {this.value='CONTINUER';pause = true;}}">
	<br><br><input type="button" value="AIDE" onclick="help();">
	<br><br>
	<table>
	<tr><td>Pointage</td><td>:&nbsp;<input class="inpText" name="points" type="text" value="0" size="6"></td></tr>
	<tr><td>Niveau</td><td>:&nbsp;<input class="inpText" name="niveaux" type="text" value="0" size="6"></td></tr>
	<tr><td>Lignes</td><td>:&nbsp;<input class="inpText" name="lignes" type="text" value="0" size="6"></td></tr>
	<tr><td  rowspan="2"><a href="../../../Vues/taverne.php">Retour � la taverne</a></td></tr>
	</table>
	</form>		
</td>
</tr>
</table>
</td></tr>
</table>

<div style="position:absolute;top:-100px;left:0px;">
<form name="key" onsubmit="return false;"><input name="down" type="texte" value=""></form>
</div>
<div id="aide">
<b>R�gles du jeu.</b>
<p class="para">Le jeu est bas� sue le jeu classique TETRIS.  Le but est de placer des formes (7 formes cubiques diff�rentes) qui descendent du haut vers la bas d'un tableau pour en former des lignes horizontales pleines.  D�s qu'elle est pleine, la ligne est d�truite et tous les cubes au-dessus de la ligne descendent d'une rang�e.</p>
<p class="para">Les touches de directions (fl�ches) et la barre d'espacement sont utilises dans le jeu.  Les fl�ches droite et gauche pour contr�ler horizontalement la forme qui descend.  Les fl�ches du haut et bas pour contr�ler la rotation de la forme.</p>
<p class="para">A chaque multiple de cinq lignes compl�t�es, le niveau de difficult� augmente de 1 et la vitesse de descente �galement.</p>
<p class="para">Le jeu se termine lorsqu'il n'est plus possible de faire descendre des formes sur le tableau.</p>
<br>
<b>Attribution des points :</b>
<p>(1 point * niveau de difficult�) est attribu�e lorsqu'une forme est plac�e sur le tableau ainsi qu'a chaque rang�e descendu par la forme lors de l'utilisation  de la barre d'espacement.</p>  
<p>100 points sont attribu�s lorsqu'une ligne est compl�t�e.</p>
<p style="float:left;">Bonne partie.</p><div style="float:right;"><button onclick="document.getElementById('aide').style.display='none';">Quitter</button></div>
</div>
</body>
</html>
