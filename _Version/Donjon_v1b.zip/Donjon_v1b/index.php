<?php	
$MySessionId = session_id();	session_start();
	require ("Secret/connect.php");	
							
	include ("DAO/Dao_ActionJoueur.php");  
	include ("DAO/Dao_ActionJoueur_Combat.php");				
	include ("DAO/Dao_ActionJoueur_Inventaire.php"); 
	include ("DAO/Dao_Aventure.php");  				
	include ("DAO/Dao_Joueur.php");
	include ("DAO/Dao_Magazin.php");
	include ("DAO/Dao_Message.php");
	include ("DAO/Dao_Objet.php");	
	include ("DAO/Dao_Village.php"); 

	
	include ("Class/Class_aventure.php");  	
	
	include ("Controleur/Controleur_Joueur.php");
	include ("Controleur/Controleur_Outil.php");
	include ("Controleur/ControleurPrincipal.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<script language="javascript">AC_FL_RunContent = 0;</script>
	<script language="javascript" src="Javascript/AC_RunActiveContent.js" ></script>
	<script Language="JavaScript" src="Javascript/Navigation.js"></script> 
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/old.css" />
	<title>Donjon de Naheulbeuk</title>
</head>
<body>
<div id="megabg_container">
<div id="bg_container">
<div id="container">
	<div id="header">
		<!-- <img src="img/top_img.jpg" alt="" style="margin:0 auto 0 auto;"/> -->
		<span id="header_text"></span>
	</div>
	<div id="menu_sword">
		<div id="tabs" class="noprint">
		<h3 class="noscreen">Navigation</h3>
			<?php	include ("Vues/Menu-Header.php");	?>
        <hr class="noscreen" />
        </div>
	</div>
	<img src="image/img/menu_sword_right.jpg" alt="" style="float:right;"/>
	<div id="body">
			<?php
			if (isset($_GET['page'])){
				if(!isset($_SESSION["num"])) { 
				switch ($_GET['page']){	

						case "welcome":			include("Vues/Page - Authentification.php");	break;
						case "MonCompte":		include("Vues/PageHero-MonCompte.php");			break;
						case "Inscription":		include("Vues/Page - Inscription.php");			break;
						case "Aide":			include("Vues/Page - Aide.php");				break;	
						case "Version":			include("Vues/Page - Version.php");				break;					
						case "Deco":			include("Controleur/ControleurDeco.php");		break;
						
					}
					}
					if(isset($_SESSION["num"])) { 
					switch ($_GET['page']){	
					
						
						case "EtatPersonnage":	include("Vues/PageHero-EtatHero.php");			break;
						case "Equipement":		include("Vues/PageHero-Equipement.php");		break;
						case "Inventaire":		include("Vues/PageHero-Inventaire.php");		break;
						case "Messagerie":		include("Vues/PageHero-Messagerie.php");		break;

						case "Village":			include("Vues/PageVillage-Village.php");		break;
						case "Magazin":			include("Vues/PageVillage-Magazin.php");		break;
						case "Aventure":		include("Vues/PageVillage-Aventure.php");		break;
						case "Voyager":			include("Vues/PageVillage-Voyager.php");		break;
						case "Taverne":			include("Vues/PageVillage-taverne.php");		break;

						case "Defis":			include("Vues/PageDefis-Adv.php");				break;	
						case "DefierHeros":		include("Vues/PageDefis-Enligne.php"); 	    	break;	
						case "combat":			include("Vues/PageDefis-ModuleCombat.php");		break;	
						
						case "welcome":			include("Vues/Page - Authentification.php");	break;
						case "MonCompte":		include("Vues/PageHero-MonCompte.php");			break;
						case "Inscription":		include("Vues/Page - Inscription.php");			break;					
						case "Deco":			include("Controleur/ControleurDeco.php");		break;
			
						case "Jeu":		
							if(isset($_SESSION["AventureEnCour"])){ if($_SESSION["AventureEnCour"]!=null){ include("Vues/PageAventure.php");	break; } }
							else{ include("Vues/PageHero-EtatHero.php"); break; }
					}
					}
				
				
			}
			else{
				if(isset($_SESSION["num"])) { 	include("Vues/PageHero-EtatHero.php");			}
				else{							include("Vues/Page - Authentification.php");	}
			}
?>
	</div>
	<div id="footer">
	<?php
		if($MyTexte!=null){ echo $MyTexte; $MyTexte=null;}
		include ("Vues/Menu-Footer.php");
		echo '<script type="text/javascript">';	SetJoueurJavascript($heros);	
		echo "   var MyHeroId ='";echo session_id();echo "'";
		echo"</script>";
	?>
	</div>
</div>
</div>
</div>
</body>

</html>
