	var tourjoueur = false;
	var	v=new Date();	
	var MaxTour= LesJoueurs.length +1;
	var ControleFinTour  = false;

	function Horloge(ss){
	/*
		if(ControleFinTour == false){
			n=new Date();	m=0;	h=0; s=ss-Math.round((n.getTime()-v.getTime())/1000.);
			var bxx=document.getElementById('TourJoueur');
			bxx.innerHTML=ControleFinTour+'__'+ss+'__'+s+'<br />'; 
			if(s>-1){
				if(s==0){ 
					ControleFinTour=true;
					OtherTour();
				}
				else{
					if(s>59){ m=Math.floor(s/60);  s=s-m*60 }
					if(m>59){ h=Math.floor(m/60);	m=m-h*60 }
					if(s<10){	s="0"+s	}
					if(m<10){	m="0"+m	}
					bxx.innerHTML=h+":"+m+":"+s+"  restant " + LesJoueurs[ConstIdJoueur][0]+"_ _"+ConstIdJoueur+"<br />";
					window.setTimeout("Horloge("+ss+");",999);
				}
			}
			else{
				ControleFinTour=true;
				OtherTour();
			}
		}
		*/
	}
	
	function OtherTour(){
	/*
		var bxx=document.getElementById('TourJoueur');	bxx.innerHTML=LesJoueurs[ConstIdJoueur][0]+'Tour Fini<br />';
		if(ConstIdJoueur==MaxTour){ 
			FinTour();  
			ConstIdJoueur = 0;
			bxx.innerHTML='Tour Monstre<br />'; 
		}
		else{ 
			//alert(ConstIdJoueur +"==" +MaxTour +"___OtherTour" );
			ConstIdJoueur = ConstIdJoueur +1; 
			ReloadTimer();
			DebutTour(); 
		}		
		*/
	}
	
	function ReloadTimer(){
	/*
		ControleFinTour = false;
		v=new Date();
	*/
	}
	