
	function TirerUneCarteTresor(){
		PieceJoueur = LesJoueurs[ConstIdJoueur][7];
		if(IsFouiller(PieceJoueur)==false &&  IsFouillerPieceVide(PieceJoueur)==false && LesJoueurs[ConstIdJoueur][9]==0){
			var LeTresor = GetAleaCarte();
			AffecterPiece(PieceJoueur);
			SetEffet(LeTresor);
			GetAfficheCarte(LeTresor,ConstIdJoueur);
			LesJoueurs[ConstIdJoueur][9] = 1;
			ActiveAction("Mn_Tresor");
		}
	}

	function AffecterPiece(Piece){
		PieceFouiller[PieceFouiller.length+1] =Piece;
	}
	
	function IsFouiller(Piece){
		var Controle = false;
		for (i=0;i<PieceFouiller.length;i++){
			if(Piece==PieceFouiller[i]){
				Controle = true;
			}
		}
		return Controle;
	}
	
	function IsFouillerPieceVide(Piece){
		var Controle = false;
		for (i=0;i<LesMonstres.length;i++){ 
			if (LesMonstres[i][9]==Piece && LesMonstres[i][8]==1){
				Controle = true;
			}
		}
		return Controle;
	}
	
	function GetAleaCarte(){
		Valeur = Math.floor(Math.random()*(LesTresors.length -1+1))+1;
		return LesTresors[Valeur];
		//return LesTresors[18];
	}
	
	function SetEffet(LeTresor,Id){
		
		if(LeTresor[0]==0){
			MyItemAjout(LesJoueurs[ConstIdJoueur][12][0],LeTresor[6],1);
			MyHeroReloadItem();
		}
		if(LeTresor[0]==1){
			LesJoueurs[ConstIdJoueur][10] = parseInt(LesJoueurs[ConstIdJoueur][10]) + parseInt(LeTresor[4]);
			ReloadCaracHero();
		}
		if(LeTresor[0]==2){
			LesJoueurs[ConstIdJoueur][3] = parseInt(LesJoueurs[ConstIdJoueur][3]) + parseInt(LeTresor[4]);
			ReloadCaracHero();
		}
		if(LeTresor[0]==3){
			//Monstre errant
			//Inventaire[Inventaire.length+1] = LeTresor;
		}
		
		$('CarteTitre').innerHTML = "====="  + LesJoueurs[ConstIdJoueur][10]  ;
		$('CarteDescription').innerHTML = "=========" + LesJoueurs[ConstIdJoueur][3] ;
		AffecteStyle('myOtherElement');
	
	}
	
	function GetAfficheCarte(LeTresor){
		$('CarteTitre').innerHTML = LeTresor[1] ;
		$('CarteDescription').innerHTML = LeTresor[5];
		if(LeTresor[0]==42){  $('FermerTresor').href=LeTresor[2]; }
		AffecteStyle('myOtherElement');
	}
	
	function AffecteStyle(id){
		var otherEl = $(id);
		var morph = new Fx.Morph(id);
		otherEl.style.display='block';
		otherEl.morph('.myClass');
	}
	
	function RetireStyle(id){
		var otherEl = $(id);
		var morph = new Fx.Morph(id);
		$('CarteTitre').innerHTML = '' ;
		$('CarteDescription').innerHTML = '';
		otherEl.erase('style');
		otherEl.style.display='none';
		otherEl.morph('.demoElement');
	}


	function CacherElement(id){
		$(id).style.display='none';
	}
	
	function AfficherElement(id){
		$(id).style.display='block';
	}
	