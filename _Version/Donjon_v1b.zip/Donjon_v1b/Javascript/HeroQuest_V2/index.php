
<?php 

$IdAventure = $_SESSION["AventureEnCour"];

?>

<html>
<head>
	<link rel="stylesheet" href="Javascript/HeroQuest_V2/default.css" type="text/css" />
	<script type="text/javascript" src="Javascript/HeroQuest_V2/mootools.js"></script>
	<!-- <script type="text/javascript" src="Javascript/HeroQuest_V2/EngineMagend.js"></script> -->
	<script Language="JavaScript" src="Javascript/HeroQuest_V2/MesItem.js"></script> 

	
</head>

<body  onload="initialiserJeux()">
	
	<div id="Centre"  class="Centre" >
		<div id="myOtherElement"  class="demoElement">
			<div id="body-leftside">
				<div id="scroll_top"><span id="scroll_header">
					<span id="CarteTitre"></span>
				</span></div>
				<div id="scroll_middle">
					<div id="CarteDescription" style="padding-left:30px;width:70%;"></div>
				</div>
				<div id="scroll_bottom">
					<a href="#" title="RetireStyle" onclick="RetireStyle('myOtherElement')" id="FermerTresor">Fermer</a>
				</div>
			</div>
				
		</div>
		
		<div id="myHeroItem" style="left:50%;margin-left:-450px;" class="demoElement">
			<?php  include("./Vues/Carte-PageHero-Inventaire.php");?>

		</div>
					
	</div>
 
	<form name="test">
		<table border="0" align="center" style='width:731px;height:534px'  background="Javascript/HeroQuest_V2/quest/quest<?php echo $IdAventure;  ?>.jpg" > 
		<?php			$case=-1; 
		for($j=0; $j <19 ; $j++) { 
			echo "<tr>"; 
				for($i=0; $i <26 ; $i++) { 
					$case=   $case + 1;					
					echo "<td class='FondNoir'><img src='Javascript/HeroQuest_V2/images/08.jpg' title='$case' id='$case' /></td>";
				}
			echo "</tr>";
		}
		?>
		</table>
		<A style="CURSOR: n-resize" href="javascript:void(0)" id="atop" 	name="atop"></A>
		<A style="CURSOR: w-resize" href="javascript:void(0)" id="aleft" 	name="aleft"></A>
		<A style="CURSOR: e-resize" href="javascript:void(0)" id="aright"   name="aright"></A>
		<A style="CURSOR: s-resize" href="javascript:void(0)" id="abottom"  name="abottom" ></A>
	</form>

	


		<div id="CarteJoueurAventure" style="height:90px;width:700px;background-color:white;background-position:center center;background-image:url('image/img/CarteHeroAventure_Nain.jpg');" >
			<div id="MenuJoueur">
			<div align="center"  >
				&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="Attaquer" onclick="DeactiverLesPieges()" id="Mn_Piege">Piege</a>
				&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="Attaquer" onclick="LancerdeeAttaque()" id="Mn_Attaquer">Attaquer</a>
				&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="Lancer les d&eacute;e" onclick="Lancerdee()" id="Mn_Deplacement">Lancer les d&eacute;s</a>
				&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="Tirer Une Carte Tresor" onclick="TirerUneCarteTresor()" id="Mn_Tresor">Tirer Une Carte Tresor</a>
				&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="Utiliser Obje" onclick="AfficherElement('myHeroItem')" id="Mn_Objet">Utiliser Objet</a>
				&nbsp;&nbsp;<a href="javascript:void(0)" class="ActionJeu" title="Fin de tour" onclick="FinTour()" id="Mn_FinTour">Fin de tour</a>	
			</div>
			<table align="center" width="100%" >
				<tr>
					<td >	

						<span  style="float:left;padding-left:75px;height:33px;">
						<?php print $heros["nom"] ?>: <?php print $heros["libellerace"]?> - Niveau : <?php print $heros["codeexp"] ?> Pieces d'or: 	<B><span id="MyHeroOrs"><?php print $heros["ors"] ?></span>	   </B>		
						</span>	
						<span  style="float:right;padding-right:75px;height:33px;">	
							D&eacute;placement restant:
							&nbsp;&nbsp;<img src='Javascript/HeroQuest_V2/images/dee/Dee.GIF' id='Dee1' name='Dee1'>
							&nbsp;&nbsp;<img src='Javascript/HeroQuest_V2/images/dee/Dee.GIF' id='Dee2' name='Dee2'>
							<span id="NbMonstre" style="display:none;"></span>
						</span>	
						
						<span  style="float:left;width:300px;">
							<span style="float:right;"><B>Vie: </B><span id="MyHeroPv"><?php print $heros["pv2"]?></span>/<span id="MyHeroPv2"><?php print $heros["pv"]?></span>	</span>	
							<?php  getbarre("barv.jpg",$heros["pv2"],$heros["pv"]); ?>	
						</span>	
						<span  style="float:right;width:300px;">				
							<B>Magie: </B><?php print $heros["pm"]?>/<?php print $heros["pm2"]?>		
							<?php  getbarre("barb.jpg",$heros["pm2"],$heros["pm"]); ?>	
						</span>				
					</td>
				
				</tr>
			</table>
			</div>
			
			<div id="MenuCombat" style="display:none;">		
			<table border="0" align="center" id="FenetreCombat" style="display:block;"  class="test" width="600px">
					<tr>
						<td rowspan="2" width="100px" align="center">
							<img id="Attaquant" style="display:none;" src="">
						</td>
						<td width="400px">
								<span style="float:left;width:60px;" >Attaque</span>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA0' name='DA0'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA1' name='DA1'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA2' name='DA2'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA3' name='DA3'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA4' name='DA4'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA5' name='DA5'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA6' name='DA6'>
								<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DA7' name='DA7'>
						</td>
						<td rowspan="2" width="100px"  align="center">
							<img id="Defenceur" style="display:none;" src="">
						</td>
					</tr>
					<tr>
						<td width="50%">
							<span style="float:left;width:60px;" >Defences</span>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD0' name='DD0'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD1' name='DD1'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD2' name='DD2'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD3' name='DD3'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD4' name='DD4'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD5' name='DD5'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD6' name='DD6'>
							<img src='Javascript/HeroQuest_V2/images/dee/E01.png' style="float:left;" class="test" id='DD7' name='DD7'>
						</td>
					</tr>
				</table>	
				<span id="TourMonstre"style="display:none;" ></span>
			</div>
		</div>
		<span id="TourJoueur" align="center" ></span>

	

<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleActionJeu.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModulePiece.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModulePersonnage.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleIAMonstre.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleCombat.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleCarteTresor.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleCarteHero.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleSave.js"></script>
<script Language="JavaScript" src="Javascript/HeroQuest_V2/ModuleMulti.js"></script>


<?php	
	//if(!isset($_SESSION['ReloadPartie'])){
		echo '<script Language="JavaScript" src="Javascript/HeroQuest_V2/quest/quest'.$IdAventure.'.js"></script>';
		echo '<script type="text/javascript">';	
		//SetJoueurJavascript($heros);	
		
		
		//SetOtherJoueurJavascript('103405');
		//SetOtherJoueurJavascript('030655');
			echo "   var MyHeroId ='";echo session_id();echo "';";
			echo "   var MyHeroNum ='";echo $_SESSION["num"];echo "';";
			
		echo"</script>";
	//}
	/*
	if(isset($_SESSION['ReloadPartie'])){
		echo '<script Language="JavaScript" src="Javascript/HeroQuest_V2/quest/quest'.$IdAventure.'.js"></script>';
		echo '<script type="text/javascript"> ';	
			echo "var MyHeroId ='";echo session_id();echo "';";
			if(isset($_SESSION['ReloadPartie'])==true){
				ReloadPartieMyHero();
			}	
		echo"  initialiserJeux(); ReloadCaracHero(); </script>";
	}
	*/
?>

</body></html>