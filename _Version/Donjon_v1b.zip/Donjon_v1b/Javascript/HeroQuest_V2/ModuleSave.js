	function getXhr(){
		var xhr = null;
		if (window.XMLHttpRequest)	{ xhr = new XMLHttpRequest();}
		else {
			if(window.ActiveXObject){
				try			{xhr = new ActiveXObject("Msxml2.XMLHTTP");}
				catch (e) 	{xhr = new ActiveXObject("Microsoft.XMLHTTP");}
			}
		
			else {
				alert("votre navigateur ne supporte pas xhr..");
				xhr = fasle ;
			}
		}
		return xhr
	}

	function Usexhr(ResponseId,parametres,parametres_Page){
		var xhr = getXhr()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				leselect = xhr.responseText;
				document.getElementById(ResponseId).innerHTML = leselect;
			} 
		}

		xhr.open("POST",parametres_Page,true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);
	}		
	function MyHeroReloadItem(){
		var parametres = 'MyHero=' 	+ MyHeroId ;		
		Usexhr('myHeroItem',parametres,'Vues/Carte-PageHero-Inventaire.php')
	}	
	/*
	function MyHeroReloadItem(){
		var xhr = getXhr()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				leselect = xhr.responseText;
				document.getElementById('myHeroItem').innerHTML = leselect;
			} 
		}
		var parametres = 'MyHero=' 	+ MyHeroId ;		
		xhr.open("POST",'Vues/Carte-PageHero-Inventaire.php',true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);
	}
*/	
		
	function MyHeroSave(){
		var xhr = getXhr()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				
			} 
		}
		LesJoueurs[ConstIdJoueur][12][3]   = LesJoueurs[ConstIdJoueur][3]; 
		LesJoueurs[ConstIdJoueur][12][15]  = LesJoueurs[ConstIdJoueur][10]; 
		var a = LesJoueurs; var b = ConstIdJoueur;
		var SaveOneJoueur = new Array(a[b][0],a[b][1],a[b][2],a[b][3],a[b][4],a[b][5],a[b][6],a[b][7],a[b][8],a[b][9],a[b][10],a[b][11],null,a[b][13]);
		var parametres = 'MyHero=' 			+ MyHeroId ;
		parametres +=  '&LesJoueurs=' 		+ SaveOneJoueur ;
		parametres +=  '&MyHero_pv=' 		+ LesJoueurs[ConstIdJoueur][12][2] ;
		parametres +=  '&MyHero_pv2='  		+ LesJoueurs[ConstIdJoueur][12][3];
		parametres +=  '&MyHero_pm=' 		+ LesJoueurs[ConstIdJoueur][12][4] ;
		parametres +=  '&MyHero_pm2='  		+ LesJoueurs[ConstIdJoueur][12][5];
		parametres +=  '&MyHero_forc=' 		+ LesJoueurs[ConstIdJoueur][12][6] ;
		parametres +=  '&MyHero_end='  		+ LesJoueurs[ConstIdJoueur][12][7];
		parametres +=  '&MyHero_inti=' 		+ LesJoueurs[ConstIdJoueur][12][8] ;
		parametres +=  '&MyHero_dext='  	+ LesJoueurs[ConstIdJoueur][12][9];
		parametres +=  '&MyHero_vit=' 		+ LesJoueurs[ConstIdJoueur][12][10] ;
		parametres +=  '&MyHero_cha='  		+ LesJoueurs[ConstIdJoueur][12][11];
		parametres +=  '&MyHero_man=' 		+ LesJoueurs[ConstIdJoueur][12][12] ;
		parametres +=  '&MyHero_ppm='  		+ LesJoueurs[ConstIdJoueur][12][13];
		parametres +=  '&MyHero_exp=' 		+ LesJoueurs[ConstIdJoueur][12][14] ;
		parametres +=  '&MyHero_ors=' 		+ LesJoueurs[ConstIdJoueur][12][15] ;
		parametres +=  '&MyHero_codeexp='  	+ LesJoueurs[ConstIdJoueur][12][16];
		parametres +=  '&MyHero_nivsuv=' 	+ LesJoueurs[ConstIdJoueur][12][17] ;
		parametres +=  '&MyHero_cexp='  	+ LesJoueurs[ConstIdJoueur][12][18];
		parametres +=  '&MyHero_nbexp=' 	+ LesJoueurs[ConstIdJoueur][12][19] ;	
		parametres +=  '&MyHero_Arme='  	+ LesJoueurs[ConstIdJoueur][12][24];
		parametres +=  '&MyHero_Bouclier=' 	+ LesJoueurs[ConstIdJoueur][12][25] ;
		parametres +=  '&MyHero_Casque='  	+ LesJoueurs[ConstIdJoueur][12][26];
		parametres +=  '&MyHero_Plastron=' 	+ LesJoueurs[ConstIdJoueur][12][27] ;
		parametres +=  '&MyHero_AvantBras=' + LesJoueurs[ConstIdJoueur][12][28];
		parametres +=  '&MyHero_Botte=' 	+ LesJoueurs[ConstIdJoueur][12][29] ;
		parametres +=  '&MyHero_Jambiere='  + LesJoueurs[ConstIdJoueur][12][30];
		parametres +=  '&Action=SaveJoueur';
		
		xhr.open("POST",'Vues/Ajax-Save.php',true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);
	}
	
	function MyPartieSave(){
		var xhr = getXhr()		
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				
			} 
		}
		var LesMonstreSave = null;
		for (i=0;i<LesMonstres.length;i++){ 
			LesMonstreSave += LesMonstres[i] +'@';
		}
	
		var parametres = 'MyHero=' 						+ MyHeroId ;
		parametres +=  '&LesJoueurs=' 					+ LesJoueurs ;
		parametres +=  '&MesPieces=' 					+ MesPieces ;
		parametres +=  '&MesPortes='  					+ MesPortes;
		parametres +=  '&MesPortesPieceActive=' 		+ MesPortesPieceActive ;
		parametres +=  '&MesMonstres='  				+ MesMonstres;
		parametres +=  '&MesPieges='  				+ MesPieges;
		parametres +=  '&LesMonstres=' 					+ LesMonstreSave ;
		parametres +=  '&PieceFouiller=' 				+ PieceFouiller ;
		parametres +=  '&PieceActiver=' 				+ PieceActiver ;
		parametres +=  '&Action=SavePartie';
	
		xhr.open("POST",'Vues/Ajax-Save.php',true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);
	}
	
	function MyItemQuantite(IdHero,IdItem,Quantite){
		var xhr = getXhr()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
			} 
		}
		var parametres = 'IdHero=' 	+ IdHero ;
		parametres +=  '&IdItem=' 	+ IdItem ;
		parametres +=  '&Quantite=' + Quantite ;
		parametres +=  '&Action=EnleverObjet';
		xhr.open("POST",'Vues/Ajax-SaveItem.php',true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);
	}
	
	function MyItemAjout(IdHero,IdItem,Quantite){
		var xhr = getXhr()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
			} 
		}
		var parametres = 'IdHero=' 	+ IdHero ;
		parametres +=  '&IdItem=' 	+ IdItem ;
		parametres +=  '&Quantite=' + Quantite ;
		parametres +=  '&Action=AjoutObjet';
		xhr.open("POST",'Vues/Ajax-SaveItem.php',true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);
	}
	
	function MyPartieFin(){
		var xhr = getXhr()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
			
			} 
		}
		var url = 'Vues/Ajax-Save.php';
		var parametres = 'MyHero=' 			+ MyHeroId ;
		parametres +=  '&Action=SaveFinPartie';
		xhr.open("POST",url,true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(parametres);	
	}