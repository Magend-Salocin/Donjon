
	function CaracHeroFin(){
		$('myHero').style.display='none';
	}
	
	function afficheReponse(requete) {
		alert(requete.responseText);
	}
	
	function CaracHero(){
		ReloadCaracHero();
		MyHeroSave();
	}
	
	function ReloadCaracHero(){
		$('MyHeroOrs').innerHTML = LesJoueurs[ConstIdJoueur][10];
		$('MyHeroPv').innerHTML = LesJoueurs[ConstIdJoueur][3]; 
		$('MyHeroBarrePv').width=  LesJoueurs[ConstIdJoueur][3] * 300 / LesJoueurs[ConstIdJoueur][12][2];

	}