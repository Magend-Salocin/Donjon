	
	//  Nom - Attaque -  Defence - Corp - Esprit - Position - Image - Piece - Attaquer	-ChercherTresor	 - Or	- deplacement	JOUEUR
	//   0  -      1     -               2     -       3  -    4   -            5     -   6   -          7    -  8 -                        9-                    10 -           11
	


	function initialiserJeux(){						//LANCE LA PARTIE
		
		for (jj=0;jj<PieceActiver.length;jj++){ 
			if(PieceActiver[jj].length >0){
				GetIdPieceAffiche(PieceActiver[jj]);
			}
		}
		AfficheHeros(LesJoueurs[ConstIdJoueur][5]);	
		AfficheAllJoueur();
		ReAfficheMonstre();
		RemiseZero();
		ClearAction();
		NbMonsreRestant();
		//Horloge(10);
		if(MyHeroNum != LesJoueurs[ConstIdJoueur][12][0]){ DesactiveAllAction(); }
	}
	
	function DebutTour(){							// D�but de tou d'un joueur
		ClearAction();
		RemiseZero();
		CacheAttaque();
		if(MyHeroNum != LesJoueurs[ConstIdJoueur][12][0]){ DesactiveAllAction(); }
	//	window.setTimeout("Horloge(10);",1399);

	}
	
	function FinTour(){								//Fin de tour d'un joueur
		CacheAttaque();
		TimerTourMonstre();
	}
	
	function FinTourMonstre(){
		IsTourMonstreTimer = true;
		ReloadTimer();
		window.setTimeout("DebutTour();",1399);
	}
	
	function FinCombat(){
		CacheAttaque();
	}
	
	function FinPartieVictoire(){					//Controle si la partie est fini
		MyHeroSave();
		var FinPartie = new Array(42,'Vous etez Victorieux','index.php?page=EtatPersonnage',0,0,'Bien jou�e');
		GetAfficheCarte(FinPartie);
		MyPartieFin();
	}
	
	
	


	function ClearAction(){
		MovementJoueur = 0;
		document.images['Dee1'].src='Javascript/HeroQuest_V2/images/dee/Dee.GIF';
		document.images['Dee2'].src='Javascript/HeroQuest_V2/images/dee/Dee.GIF';
		DesactiveAction("Mn_Attaquer");
		DesactiveAction("Mn_Deplacement");
		DesactiveAction("Mn_Tresor");
		DesactiveAction("Mn_Objet");
		DesactiveAction("Mn_Piege");
		LesJoueurs[ConstIdJoueur][8]=0;
		LesJoueurs[ConstIdJoueur][9] = 0;
		LesJoueurs[ConstIdJoueur][11] = 0;
		RetirerEffet();
		
	}
	
	function DesactiveAllAction(){
		document.images['Dee1'].src='Javascript/HeroQuest_V2/images/dee/Dee.GIF';
		document.images['Dee2'].src='Javascript/HeroQuest_V2/images/dee/Dee.GIF';
		ActiveAction("Mn_Attaquer");
		ActiveAction("Mn_Deplacement");
		ActiveAction("Mn_Tresor");
		ActiveAction("Mn_Objet");
		ActiveAction("Mn_Piege");
	
	}
	
	function AfficheHeros(id){
		LesJoueurs[ConstIdJoueur][5] = id;
		MontreElement(id);
		id = parseInt(id)  + IdCorrectionParam; 
		document.images[id].src=LesJoueurs[ConstIdJoueur][6];	
	}
	
	function AfficheOtherHeros(id,IdJoueur){
		if(ConstIdJoueur!=IdJoueur){
			LesJoueurs[IdJoueur][5] = id;
			MontreElement(id);
			id = parseInt(id)  + IdCorrectionParam; 
			document.images[id].src=LesJoueurs[IdJoueur][6];	
		}
	}
	
	function AfficheMonstre(id){
		LesMonstres[IdLeMienMonstre][7] = id;
		MontreElement(id);
		id = parseInt(id)  + IdCorrectionParam; 
		document.images[id].src=LesMonstres[IdLeMienMonstre][6]; 
	}
	
	function AfficheCarteTresor(){
		TirerUneCarteTresor();
	}
	
	function AjouterDebug(valeur){
		//document.getElementById("Debug").innerHTML = document.getElementById("Debug").innerHTML + "<br />" + valeur + "<br />";
	}
	
	function ClearDebug(){
		document.getElementById("Debug").innerHTML = '';
	}
	
	function ActiveAction(LienId){
		/*	Mn_Attaquer	Mn_Deplacement	Mn_Tresor	Mn_Objet	Mn_FinTour	*/
		$(LienId).style.textDecoration="line-through";
		$(LienId).style.color="DarkRed";
	}
	
	function DesactiveAction(LienId){
		/*	Mn_Attaquer	Mn_Deplacement	Mn_Tresor	Mn_Objet	Mn_FinTour	*/
		$(LienId).style.textDecoration="";
		$(LienId).style.color="";
	}
	
	function MontreElement(id){
		document.getElementById(id).className = "Montre";
	}
	
	function CacheCase(id){
		document.getElementById(id).className = "Cache";
	}
	
	function UtiliserObjet(id){
		// 1,2 num ,5 effet ,6 valeur
		alert(MesObjet[id][1] +"-"+ id);
		if(MesObjet[id][2] > 0){
			if(MesObjet[id][5] =="pv2"){ 
				UtiliserObjetHero(3,2,id);	CaracHero();
			}
			if(MesObjet[id][1] == "998"){ 
				LesEffets[LesEffets.length]   = new Array(ConstIdJoueur,2,LesJoueurs[ConstIdJoueur][2]);
				UtiliserObjetHero(2,2,id);
			}
			if(MesObjet[id][1] == "997"){ 
				LesEffets[LesEffets.length]   = new Array(ConstIdJoueur,1,LesJoueurs[ConstIdJoueur][1]);
				UtiliserObjetHero(1,1,id);
			}
			if(MesObjet[id][1] == "996"){ 
				LesJoueurs[ConstIdJoueur][11] = 0;	DesactiveAction("Mn_Deplacement"); 
				UtiliserObjetHeroDel(id);
			}
			if(MesObjet[id][1] == "995"){ 
				LesJoueurs[ConstIdJoueur][8] = 0; 	DesactiveAction("Mn_Attaquer");
				UtiliserObjetHeroDel(id);
			}
			
		}
		
	}

	function UtiliserObjetHero(IdAttribu,IdCible,id){
		var Valeur =  parseInt(MesObjet[id][6]) + 	parseInt(LesJoueurs[ConstIdJoueur][IdAttribu]);
		if(IdAttribu == IdCible){
			LesJoueurs[ConstIdJoueur][IdAttribu] =Valeur;
		}
		else{
			if(Valeur > LesJoueurs[ConstIdJoueur][12][IdAttribu]){
				LesJoueurs[ConstIdJoueur][IdAttribu] = LesJoueurs[ConstIdJoueur][12][IdAttribu]; 
			}
			else{
				LesJoueurs[ConstIdJoueur][IdAttribu] =Valeur;
			}
		}
		UtiliserObjetHeroDel(id);

	}
	
	function UtiliserObjetHeroDel(id){
		MesObjet[id][2] = parseInt(MesObjet[id][2]) - 1;
		MyItemQuantite(LesJoueurs[ConstIdJoueur][12][0],MesObjet[id][1],MesObjet[id][2]);
		$('_item'+MesObjet[id][1]).innerHTML= MesObjet[id][2];
	}
	
	function RetirerEffet(){
		for (i=0;i<LesEffets.length;i++){ 
			LesJoueurs[LesEffets[0]][LesEffets[1]] = LesEffets[2];
		}
	}
	
	
	function ActiverPiege(id){
		if(MesPieges[id]=="X"){
			LesJoueurs[ConstIdJoueur][3] = parseInt(LesJoueurs[ConstIdJoueur][3]) + parseInt(-1);
			ReloadCaracHero();
			alert("Vous etez victime d'un piege!");
		}
	}
	function DeactiverLesPieges(){
		var LaPiece = GetIdPiece(LesJoueurs[ConstIdJoueur][7]);
		for (i=0;i<LaPiece.length;i++){ 
			MesPieges[i]="0";
		}
		ActiveAction("Mn_Attaquer");
		ActiveAction("Mn_Deplacement");
		ActiveAction("Mn_Tresor");
		ActiveAction("Mn_Objet");
		ActiveAction("Mn_Piege");
		LesJoueurs[ConstIdJoueur][11] = 1;
	}
	
	function AfficheAllJoueur(){					// Affiche tout les joueurs sur la carte
		for (jj=0;jj<LesJoueurs.length;jj++){ 
			AfficheOtherHeros(LesJoueurs[jj][5],jj);	
		}
	}
	
	function MoveDee(){								//Controle du d�placement des joueurs
		MovementJoueur = MovementJoueur  - 1;		
	}

	function Lancerdee(){							//Lancer les dees pour le d�placement du joueur en cours
		if(LesJoueurs[ConstIdJoueur][11]==0){
			Valeur1 = Math.floor(Math.random()*(6 -1+1))+1;
			Valeur2 = Math.floor(Math.random()*(6 -1+1))+1;
			$('Dee1').src = 'Javascript/HeroQuest_V2/images/dee/'+Valeur1+'.bmp';
			$('Dee2').src = 'Javascript/HeroQuest_V2/images/dee/'+Valeur2+'.bmp';
			document.images['Dee1'].src='Javascript/HeroQuest_V2/images/dee/'+Valeur1+'.bmp';
			document.images['Dee2'].src='Javascript/HeroQuest_V2/images/dee/'+Valeur2+'.bmp';
			MovementJoueur = Valeur1 + Valeur2;
			temp=1;
			ActiveAction("Mn_Deplacement");
			LesJoueurs[ConstIdJoueur][11] = 1;
		}
	}
	
	