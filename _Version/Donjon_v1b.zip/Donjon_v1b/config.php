<?php

	require ("Secret/connect.php");	
							
	include ("DAO/Dao_ActionJoueur.php");  
	include ("DAO/Dao_ActionJoueur_Combat.php");				
	include ("DAO/Dao_ActionJoueur_Inventaire.php"); 
	include ("DAO/Dao_Aventure.php");  				
	include ("DAO/Dao_Joueur.php");
	include ("DAO/Dao_Magazin.php");
	include ("DAO/Dao_Message.php");
	include ("DAO/Dao_Objet.php");	
	include ("DAO/Dao_Village.php"); 

	
	include ("Class/Class_aventure.php");  	
	
	include ("Controleur/Controleur_Joueur.php");
	include ("Controleur/Controleur_Outil.php");
	include ("Controleur/ControleurPrincipal.php");
	
?>