<?php
	if (isset($_GET['page'])){
		if(!isset($_SESSION["num"])) { 
		switch ($_GET['page']){	

				case "welcome":			include("Vues/Page - Authentification.php");	break;
				case "MonCompte":		include("Vues/PageHero-MonCompte.php");			break;
				case "Inscription":		include("Vues/Page - Inscription.php");			break;
				case "Aide":			include("Vues/Page - Aide.php");				break;	
				case "Version":			include("Vues/Page - Version.php");				break;					
				case "Deco":			include("Controleur/ControleurDeco.php");		break;
				
			}
			}
			if(isset($_SESSION["num"])) { 
			switch ($_GET['page']){	
			
				
				case "EtatPersonnage":	include("Vues/PageHero-EtatHero.php");			break;
				case "Equipement":		include("Vues/PageHero-Equipement.php");		break;
				case "Inventaire":		include("Vues/PageHero-Inventaire.php");		break;
				case "Messagerie":		include("Vues/PageHero-Messagerie.php");		break;

				case "Village":			include("Vues/PageVillage-Village.php");		break;
				case "Magazin":			include("Vues/PageVillage-Magazin.php");		break;
				case "Aventure":		include("Vues/PageVillage-Aventure.php");		break;
				case "Voyager":			include("Vues/PageVillage-Voyager.php");		break;
				case "Taverne":			include("Vues/PageVillage-taverne.php");		break;

				case "Defis":			include("Vues/PageDefis-Adv.php");				break;	
				case "DefierHeros":		include("Vues/PageDefis-Enligne.php"); 	    	break;	
				case "combat":			include("Vues/PageDefis-ModuleCombat.php");		break;	
				
				case "welcome":			include("Vues/Page - Authentification.php");	break;
				case "MonCompte":		include("Vues/PageHero-MonCompte.php");			break;
				case "Inscription":		include("Vues/Page - Inscription.php");			break;					
				case "Deco":			include("Controleur/ControleurDeco.php");		break;
	
				case "Jeu":		
					if(isset($_SESSION["AventureEnCour"])){ if($_SESSION["AventureEnCour"]!=null){ include("Vues/PageAventure.php");	break; } }
					else{ include("Vues/PageHero-EtatHero.php"); break; }
			}
			}
		
		
	}
	else{
		if(isset($_SESSION["num"])) { 	include("Vues/PageHero-EtatHero.php");			}
		else{							include("Vues/Page - Authentification.php");	}
	}
?>