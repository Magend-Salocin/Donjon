<?php  
	$SERVEUR="172.20.244.3";
	$LOGIN="magend";
	$MDP="EL1rXCN0";
	$MABASE="magend";
	$CONNEXION=mysql_connect($SERVEUR,$LOGIN,$MDP);
	mysql_select_db($MABASE);

	function GetLigne($Curseur) {
	// fournit une ligne du curseur pass� en param�tre
	   $Ligne=mysql_fetch_array($Curseur);
	   return $Ligne;
	}

	function ExecuteRequete($Requete){
	// execute la requete passer en parametre
		$RequeteExecuter = mysql_query($Requete) or die (mysql_error());
		return $RequeteExecuter;
	}
	
	function GetTotal($Requete){
		/*recupere une valeur entiere a partir d une requete "count"*/
		$row=GetLigne(ExecuteRequete($Requete));
		return $row['total'];
	}
	function ReplaceCarac($Chaine){/*
		$Chaine = str_replace("�","&eacute;",$Chaine); 
		$Chaine = str_replace("�","&egrave;",$Chaine); 
		$Chaine = str_replace("�","&ecirc;",$Chaine); 
		$Chaine = str_replace("�","&euml;",$Chaine); 
		
		$Chaine = str_replace("�","&ccedil;",$Chaine); 
		$Chaine = str_replace("�","&icirc;",$Chaine); 
	
		$Chaine = str_replace("�","&ocirc;",$Chaine); 
		$Chaine = str_replace("�","&ugrave;",$Chaine);
		$Chaine = str_replace("�","&ucirc;",$Chaine); 	
		
		$Chaine = str_replace("&","&amp;",$Chaine); 
		$Chaine = str_replace("�","&euro;",$Chaine); 
		
		$Chaine = str_replace("�","&agrave;",$Chaine); 
		$Chaine = str_replace("�","&acirc;",$Chaine);
		$Chaine = str_replace("�","&ucirc;",$Chaine); 	
		*/
		return $Chaine;
	}
?>