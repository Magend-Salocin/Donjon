	function getXhrTest(){
		var xhr = null;
		if (window.XMLHttpRequest)	{ xhr = new XMLHttpRequest();}
		else {
			if(window.ActiveXObject){
				try			{xhr = new ActiveXObject("Msxml2.XMLHTTP");}
				catch (e) 	{xhr = new ActiveXObject("Microsoft.XMLHTTP");}
			}
		
			else {
				alert("votre navigateur ne supporte pas xhr..");
				xhr = fasle ;
			}
		}
		return xhr
	}	
		
	function AffichePage(CiblePage){
		var xhr = getXhrTest()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				document.getElementById('body').innerHTML = xhr.responseText;
								
			} 
		}	
		var para ="Ajax='true'";
		para += 'MyHero=' 	+ MyHeroId ;	
		xhr.open("POST",CiblePage,true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(para);
	}	
	
	function LoadSound(IdSound){
		if (AC_FL_RunContent == 0) {
			alert("Cette page n�cessite le fichier AC_RunActiveContent.js.");
		} else {
			AC_FL_RunContent(
				'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0',
				'width', '550',
				'height', '400',
				'src', 'IntroTheme',
				'quality', 'high',
				'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
				'align', 'middle',
				'play', 'true',
				'loop', 'true',
				'scale', 'showall',
				'wmode', 'window',
				'devicefont', 'false',
				'id', 'IntroTheme',
				'bgcolor', '#ffffff',
				'name', 'IntroTheme',
				'menu', 'true',
				'allowFullScreen', 'false',
				'allowScriptAccess','sameDomain',
				'movie', 'IntroTheme',
				'salign', ''
				); //end AC code
		}
	}
	
	function AffichePageMagazin(Id){
		if(Id=="0"){ NavigationPage("Taverne"); }
		var xhr = getXhrTest()
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				document.getElementById('body').innerHTML = xhr.responseText;

			} 
		}	
		var para ="Ajax='true'";
		para += 'MyHero=' 	+ MyHeroId ;
		para += 'PostMagazin=' 	+ Id ;			
		xhr.open("POST","Vues/PageVillage-Magazin.php",true);
		xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xhr.send(para);
	}	
		
	function NavigationPage(Cible)
	{
		switch (Cible){	
			case "EtatPersonnage":	AffichePage("Vues/PageHero-EtatHero.php");  		break;
			case "Equipement":		AffichePage("Vues/PageHero-Equipement.php");		break;
			case "Inventaire":		AffichePage("Vues/PageHero-Inventaire.php");		break;
			case "Messagerie":		AffichePage("Vues/PageHero-Messagerie.php");		break;

			case "Village":			AffichePage("Vues/PageVillage-Village.php");		break;
			case "Magazin":			AffichePage("Vues/PageVillage-Magazin.php");		break;
			case "Aventure":		AffichePage("Vues/PageVillage-Aventure.php");		break;
			case "Voyager":			AffichePage("Vues/PageVillage-Voyager.php");		break;
			case "Taverne":			AffichePage("Vues/PageVillage-taverne.php");		break;

			case "Defis":			AffichePage("Vues/PageDefis-Adv.php");				break;	
			case "DefierHeros":		AffichePage("Vues/PageDefis-Enligne.php"); 	    	break;	
			case "combat":			AffichePage("Vues/PageDefis-ModuleCombat.php");		break;	
			case "MonCompte":		AffichePage("Vues/PageHero-MonCompte.php");			break;
		}
	}

		
//LoadSound('IntroTheme');