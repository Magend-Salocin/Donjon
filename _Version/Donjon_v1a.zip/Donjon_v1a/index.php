<?php	
$MySessionId = session_id();	session_start();	include ("config.php");	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<script language="javascript">AC_FL_RunContent = 0;</script>
	<script language="javascript" src="Javascript/AC_RunActiveContent.js" ></script>
	<script Language="JavaScript" src="Javascript/Navigation.js"></script> 
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/old.css" />
	<title>Donjon de Naheulbeuk</title>
</head>

<!-- <body onload="PlayMusique()">  -->
<body>
<div id="megabg_container">
<div id="bg_container">
<div id="container">
	<div id="header">
		<!-- <img src="img/top_img.jpg" alt="" style="margin:0 auto 0 auto;"/> -->
		<span id="header_text"></span>
	</div>
	<div id="menu_sword">
		<div id="tabs" class="noprint">
		<h3 class="noscreen">Navigation</h3>
			<?php	include ("Vues/Menu-Header.php");	?>
        <hr class="noscreen" />
        </div>
	</div>
			<img src="image/img/menu_sword_right.jpg" alt="" style="float:right;"/>
	<div id="body">
			<?php	include ("Navigation.php");	?>
	</div>
	<div id="footer">
	
		<?php
		if($MyTexte!=null){ echo $MyTexte; $MyTexte=null;}
		include ("Vues/Menu-Footer.php");
		echo '<script type="text/javascript">';	SetJoueurJavascript($heros);	
		echo "   var MyHeroId ='";echo session_id();echo "'";
		echo"</script>";
		?>
	</div>
</div>
</div>
</div>
</body>

</html>
