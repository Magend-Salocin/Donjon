<div id="body-fullside" style="padding:80px 15px 5px 5px;background-image:url(./image/img/body_sword_handle.jpg);margin-top:27px;.margin-top:0px;_margin-top:0px;float:none;">
	<div style="left:50%;margin-left:-300px;position:relative;font-family:Georgia;font-size:large;">
		<form method="GET" action="" name="connect" >
			<input type="hidden" 	name="passage"  value='1'>
			Authentification  : <br />
			<strong>Nom d utilisateur</strong><input type="text" 		name="nom" 	size="20"><br />
			<strong>Mot de passe</strong><input type="password" 	name="mdp" value=""><br />
			<input type="submit" name="valider" 	value="connecter" ><br />
		</form>
		
		<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="550" height="400" id="IntroTheme" align="middle">
			<param name="allowScriptAccess" value="sameDomain" />
			<param name="allowFullScreen" value="false" />
			<param name="movie" value="arzhel/Donjon.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" />	<embed src="arzhel/Donjon.swf" quality="high" bgcolor="#ffffff" width="550" height="400" name="IntroTheme" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
		</object>
	</div>
</div>