<?php if(isset($_SESSION["num"])) { ?>
<ul>
	<li><a href="index.php" class="sword_menu"><span class="shadow">&nbsp;H&nbsp;</span><span class="text">&nbsp;H&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="?page=Village" class="sword_menu"><span class="shadow">&nbsp;Village&nbsp;</span><span class="text">&nbsp;Village&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="?page=Aventure" class="sword_menu"><span class="shadow">&nbsp;Aventure&nbsp;</span><span class="text">&nbsp;Aventure&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="?page=Voyager" class="sword_menu"><span class="shadow">&nbsp;Voyager&nbsp;</span><span class="text">&nbsp;Voyager&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="?page=Deco" class="sword_menu"><span class="shadow">&nbsp;X&nbsp;</span><span class="text">&nbsp;X&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>  
	</ul>
<?php } else { ?>

<ul>
	<li><a href="index.php" class="sword_menu"><span class="shadow">&nbsp;Accueil&nbsp;</span><span class="text">&nbsp;Accueil&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="index.php?page=Inscription" class="sword_menu"><span class="shadow">&nbsp;Inscription&nbsp;</span><span class="text">&nbsp;Inscription&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="#" class="sword_menu"><span class="shadow">&nbsp;Aide&nbsp;</span><span class="text">&nbsp;Aide&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
	<li><a href="?page=Jeu" class="sword_menu"><span class="shadow">&nbsp;Test_Jeu&nbsp;</span><span class="text">&nbsp;Test_Jeu&nbsp;</span><span class="tab-l"></span><span class="tab-r"></span></a></li>
</ul>
<?php } ?>

