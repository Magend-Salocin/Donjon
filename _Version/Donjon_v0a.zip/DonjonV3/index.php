<html>
<head><title>Donjon projet </title></head>

<!-- divise la page en 2 parties une parties sera fixe (� gauche) l autre affichera la page voulu -->
	<frameset  cols="23%,*" border="1" bordercolor="blue">
		<frame noresize scrolling="no"  src="Vues\acceuil.php" 		name="cadreGauche">
		<frame noresize scrolling="yes" src="Vues\principale.html" 	name="cadreDroite">
	</frameset>

</html>