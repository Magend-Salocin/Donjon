
	var arrowup 	= false;			var arrowdown 	= false;
	var arrowleft 	= false;			var arrowright 	= false;
	var movespeed 	= 150;				var bStatusA 	= false;

	document.onkeydown 	= onKeyDown;	
	window.setInterval("Move()", 10);	window.setInterval("statusA()", 100);

	function CacheCase(id){
		document.getElementById(id).style.filter = "alpha(opacity=0)";
		document.images[id].src='../image/village2/01.JPG';
	}
	
	function AfficheHeros(id){
		document.test.position.value = id;
		
		document.getElementById(id).style.filter = "alpha(opacity=100)";
	}
	
	function onKeyDown(){
	
		var code = event.keyCode;	var id = document.test.position.value;
		//alert(id);
		
		switch (code){
		
		case 37:
			arrowleft 	= true; 	
		//	if (id!="0" && id!="9" && id!="18" && id!="27" && id!="36" && id!="45" && id!="54" && id!="63" && id!="72"){					
			CacheCase(id);	id = id -1;  AfficheHeros(id);			
			document.images[id].src='../image/avatars/gauche/01.PNG'; 
			//}
			
			break
			
		case 38:
			arrowup 	= true;		
			if(id > 22){
			CacheCase(id);	id = id -22;  AfficheHeros(id);				
			document.images[id].src='../image/avatars/haut/01.PNG'; 
			}
			
			break
			
		case 39:
			arrowright 	= true;	
		//	if ( id!="8" && id!="17" && id!="26" && id!="35" && id!="44" && id!="53" && id!="62" && id!="71" && id!="80" ){ 
			CacheCase(id);	id = parseInt(id) +1;  AfficheHeros(id);		
			document.images[id].src='../image/avatars/droite/01.PNG';
		//	}
		
			break
			
		case 40:
			arrowdown 	= true;		
			if(id < 263){
			CacheCase(id);	id = parseInt(id) +22;  AfficheHeros(id);					
			document.images[id].src='../image/avatars/bas/01.PNG';
			}
		
			break
			
		case 65:
			hotel.submit();
			
			break
		default:
		}
		if (id==69){ hotel.submit();}
		if (id==194){ hotel.submit();}
	}