<?
	function GetAventure($rang,$village){
		$LesAventures="SELECT * FROM aventure WHERE rang < '".$rang."' AND village = '".$village."' ";
		return ExecuteRequete($LesAventures);
	}

	function GetMissionAventure($id){
		$UneAventure="SELECT * FROM aventure WHERE code = '".$id."' ";
		$UneAventure = ExecuteRequete($UneAventure);
		return GetLigne($UneAventure);
	}
	
	function GetDanger($grade){
		if ($grade=="Novice") 		{$nb=rand(0,6);}
		if ($grade=="Ecuyer") 		{$nb=rand(1,9);}
		if ($grade=="Aventurier")	{$nb=rand(10,20);}
		if ($grade=="Legende")		{$nb=rand(15,30);}
		return $nb;
	}
	
	function GetCapable($codeheros){
		$Vie=$_SESSION["pv2"];	$fatiguer="4";
		if( $Vie < 7  ) 			 { $fatiguer="0"; }
		if( $Vie > 6  && $Vie < 9 )  { $fatiguer="1"; }
		if( $Vie > 8  && $Vie < 20 ) { $fatiguer="2"; }
		if( $Vie > 19 && $Vie < 30 ) { $fatiguer="3"; }
		return $fatiguer;
	}
	

	function SetFinMission($IdMission,$IdHeros){
		//CALCUL DES VARIABLE DE FIN DE MISSION
								$mission=GetMissionAventure($IdMission);	
		$exp=$_SESSION["exp"]+$mission['nbexp'];		$ors=$_SESSION["ors"]+$mission['nbor'];
		$NbPerdu=GetDanger($_SESSION["libellerang"]);	$vie=$_SESSION["pv2"]-$NbPerdu;
		
		//MISE A JOUR DES DONNEE DU JOUEUR
		$MaRequete="UPDATE joueur SET exp='".$exp."',ors='".$ors."',pv2='".$vie."' WHERE num='".$IdHeros."'";
		ExecuteRequete($MaRequete);
		$_SESSION["exp"]=$exp;	$_SESSION["ors"]=$ors;	$_SESSION["pv2"]=$vie;
		
		//MISE A JOUR DU NOMBRE DE MISSION ACCOMPLIE
		SetNbMission($IdMission,$IdHeros);
		$sql = "DELETE FROM aventureencour  WHERE  jou_num= '".$IdHeros."'"; 
		ExecuteRequete($sql);
	}
?>