<?
	function GetAuth($nom,$mdp){
		$MaRequete="SELECT * FROM joueur WHERE login= '".$nom."' AND mdp='".$mdp."' ";
		return GetLigne(ExecuteRequete($MaRequete));
	}
	
	function Modif($champs,$nb,$num){	
		echo $MaRequete="UPDATE joueur SET ".$champs."='".$nb."' WHERE num='".$num."'";
		ExecuteRequete($MaRequete);
	}
	
	function Select($champs,$num){	
		echo $MaRequete="SELECT ".$champs." FROM  joueur  WHERE num= ".$num." ";
		$MonRs = GetLigne(ExecuteRequete($MaRequete));
		return $MonRs[0];
	}
	
	function GetUtilisateur($num){
		$MaRequete="SELECT * FROM joueur WHERE num= '".$num."'";
		return GetLigne(ExecuteRequete($MaRequete));
	}
	
	function SetJoueur($Tuple){
		$_SESSION["num"] 			= $Tuple['num'];			$_SESSION["nom"] 			= $Tuple['nom'];		
		$_SESSION["pv"] 			= $Tuple['pv'];				$_SESSION["pv2"] 			= $Tuple['pv2'];	
		$_SESSION["pm"] 			= $Tuple['pm'];				$_SESSION["pm2"] 			= $Tuple['pm2'];	
		$_SESSION["forc"] 			= $Tuple['forc'];			$_SESSION["end"] 			= $Tuple['end'];	
		$_SESSION["inti"] 			= $Tuple['inti'];			$_SESSION["dext"] 			= $Tuple['dext'];	
		$_SESSION["vit"] 			= $Tuple['vit'];			$_SESSION["cha"] 			= $Tuple['cha'];
		$_SESSION["man"] 			= $Tuple['man'];			$_SESSION["ppm"] 			= $Tuple['ppm'];
		
		$_SESSION["exp"] 			= $Tuple['exp'];			$_SESSION["ors"] 			= $Tuple['ors'];
		$_SESSION["codeexp"] 		= $Tuple['codeexp'];		$_SESSION["nivsuv"] 		= $Tuple['nivsuv'];	
		
		$_SESSION["cexp"] 			= $Tuple['cexp'];			$_SESSION["nbexp"] 			= $Tuple['nbexp'];	
		$_SESSION["libellerace"] 	= $Tuple['libellerace'];	$_SESSION["libellerang"]	= $Tuple['libellerang'];	
		$_SESSION["village"] 		= $Tuple['village'];		$_SESSION["numclient"] 		= $Tuple['num'];	
		$_SESSION["nomclient"] 		= $Tuple['nom'];			$_SESSION["image"] 			= $Tuple['image'];	
					                
        $_SESSION["Enligne"] 		= $Tuple['Enligne'];		$_SESSION["nbCombat"] 		= $Tuple['nbCombat'];	
		$_SESSION["nbVictoire"] 	= $Tuple['nbVictoire'];		$_SESSION["NbCombatDay"] 	= $Tuple['NbCombatDay'];	
		
		$_SESSION["Arme"] 			= $Tuple['Arme'];			$_SESSION["Bouclier"] 		= $Tuple['Bouclier'];	
		$_SESSION["Casque"] 	    = $Tuple['Casque'];			$_SESSION["Plastron"]		= $Tuple['Plastron'];	
		$_SESSION["AvantBras"] 		= $Tuple['AvantBras'];		$_SESSION["Botte"] 			= $Tuple['Botte'];	
		$_SESSION["Jambiere"] 		= $Tuple['Jambiere'];		
		$_SESSION["tab"] 			= $Tuple;
		
	}
	
	function aventureRec($heros,$aventure,$date,$libelle){
		DelAventure($heros);
		$sql = "INSERT INTO aventureencour  ( aven_num, jou_num ,  sec , libelle ) VALUES ('$aventure', '$heros' , '$date' , '$libelle')";
		ExecuteRequete($sql);
	}
	
	function GetAventureEnCour($heros){
		$MaRequete="SELECT * FROM  aventureencour  WHERE jou_num= '".$heros."' ";
		return GetLigne(ExecuteRequete($MaRequete));
	}
	
	function DelAventure($IdHeros){
		$sql = "DELETE FROM aventureencour  WHERE  jou_num= '".$IdHeros."'"; 
		ExecuteRequete($sql);
	}
	
	function affichErreur($erreur){
		if ($erreur=="pv"){$text="Vous ne pouvez utiliser cette objet votre vie est au max";}
		if ($erreur=="pm"){$text="Vous ne pouvez utiliser cette objet vos point de magie sont au max";}
		echo "<div align=left><font color=red> $text </font></div>";
	}
	
?>