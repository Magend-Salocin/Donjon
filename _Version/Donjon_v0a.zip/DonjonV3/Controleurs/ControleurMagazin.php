<?
	function GetMagazin($village){
		$LesMagazins="SELECT * FROM magazin WHERE  village = '".$village."' ";
		return ExecuteRequete($LesMagazins);
	}
	
	function GetLeMagazin($village,$magazin){
		$LeMagazin="SELECT code FROM magazin WHERE  village = '".$village."' and code = '".$magazin."'";
		$LeMagazin=GetLigne(ExecuteRequete($LeMagazin));
		return $LeMagazin[0]==$magazin;
	}

	function GetAfficheMagazin2($row){
		echo " <area shape='rect' coords='$row[2],$row[3],$row[4],$row[5]'  href='obget.php?magazin=$row[0]' alt='$row[1]'  target='cadreDroite'>"; 
	}
	
?>