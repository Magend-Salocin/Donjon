<?
	function GetVillage($num){
		$MaRequete="SELECT * FROM village WHERE code= '".$num."'";
		$MonRs = ExecuteRequete($MaRequete);
		return GetLigne($MonRs);
	}
	
	function GetVoyage($dep,$arv){
		$MaRequete="SELECT temps FROM villagealler WHERE   villagedep  = '".$dep."' and villagearv  = '".$arv."' ";
		$MonRs = ExecuteRequete($MaRequete);
		return GetLigne($MonRs);
	}
	
	function GetAutreVillage($num){
		$MaRequete="SELECT * FROM village, villagealler WHERE villagedep = '".$num."' AND villagearv = code";
		return ExecuteRequete($MaRequete);
	}

	function GetAfficheVillage($row){
	echo " <area shape='rect' coords='$row[2],$row[3],$row[4],$row[5]'  href='acceuil.php?village=$row[0]' alt='dur�e du trajet : $row[9]'  target='cadreGauche'>"; 
	}
	
?>