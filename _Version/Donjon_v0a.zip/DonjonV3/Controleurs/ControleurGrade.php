<?
	function GetGrade($lib){
		$CodeGrade="SELECT code FROM grade WHERE libelle = '".$lib."' ";
		$CodeGrade = ExecuteRequete ($CodeGrade);
		$CodeGrade = GetLigne($CodeGrade);
		return $CodeGrade[0];
	}
	
	function GetNbMission($num){
		$MaRequete="SELECT grade.libelle, sum( accomplir.nb ) FROM accomplir , aventure, grade WHERE jou_num = ".$num." and accomplir.aven_num = aventure.code AND grade.code = aventure.rang GROUP BY grade.libelle";
		return  ExecuteRequete($MaRequete);
	}
	
	function SetGradeSup($heros){
	$Ngrade=GetNbMission($heros);	$rang=$_SESSION["libellerang"];
	while($grade=GetLigne($Ngrade)){
	if($grade[0]=="Novice" && $rang==$grade[0]) { if($grade[1]>30){Modif("libellerang","Ecuyer",$heros);}}
	if($grade[0]=="Ecuyer" && $rang==$grade[0]) { if($grade[1]>40){Modif("libellerang","Aventurier",$heros);}}
	if($grade[0]=="Aventurier" && $rang==$grade[0]) { if($grade[1]>50){Modif("libellerang","Legende",$heros);}}
			
		}
	}

	function GetAfficheGrade($librang,$codeheros){
		$nbmission = GetNbMission($codeheros);
		while($row=GetLigne($nbmission))	{ 
			echo "<TR><TD width='50%'align=center>$row[0]: $row[1]</TD>";
			$row=GetLigne($nbmission);
			echo "<TD width='50%' align=center>$row[0]: $row[1]</TD></TR>"; 
		}	    
	}

	
	
	function SetNbMission($mission,$heros){
		$NbMission="SELECT nb FROM accomplir WHERE aven_num = '".$mission."' and jou_num = '".$heros."'";
		$NbMission=ExecuteRequete($NbMission);	$total=GetLigne($NbMission);
		if (isset($total['nb'])){
		   $nb=$total['nb']+1;
		   $MaRequete="UPDATE accomplir SET nb='".$nb."' WHERE aven_num='".$mission."' and jou_num='".$heros."'";
		   ExecuteRequete($MaRequete);
		}
		else{
			echo $MaRequete="insert into accomplir  values ('".$mission."','".$heros."','1')";
			ExecuteRequete($MaRequete);
		}
		SetGradeSup($heros);
	}
	
?>