<?session_start();
	$HeureActuelle=time();	$_SESSION["time"]=$HeureActuelle;
	
	require	("../Secret/connect.php");
	include ("../Controleurs/ControleurMenu.php");
	include ("../Controleurs/ControleurMagazin.php");
	$LesMagazin=GetMagazin($_SESSION["village"]);	
?>
<body> 
	<br>
	<center><img src="../image/village/<?echo $_SESSION["village"];?>.jpg"  usemap="#zonesClic" ></center>
	<map name="zonesClic">
	<? while($row=GetLigne($LesMagazin))	
				if ($row[0]==null){ echo "Le magazin ne possede plus d' objet";  }
				else 			  { GetAfficheMagazin2($row);	}
	?>
	</map> 
	
</body></html>