<html>
<head>

	<style type="text/css">
			.test{	filter:alpha(opacity=0);	}
	</style>

	<script src="../Javascript/MesFonctionMouMag.js"></script>

</head>

<body background="../image/village2/test02.bmp" bgproperties="fixed" >

<br><br><br><br>
 
<form name="test">
	<table  align="center"> 
	<?	$joueur=15;			$case=-1;
	for($j=0; $j <9 ; $j++) { 
		echo "<tr>";
			for($i=0; $i <13 ; $i++) { 
				 $case=   $case + 1;
				if($joueur == $case)  
				{ echo "<td><img src='../image/avatars/bas/01.JPG' name='$case'></td>"; }
				else 					
				{echo "<td><img src='../image/village2/01.JPG' class='test'  name='$case'></td>";}
			}
		echo "</tr>";		
	}
	echo "<input type='hidden' name='position'  value='$joueur'>";
	?>
	</table>

<A style="CURSOR: n-resize" href="javascript:void(0)" id="atop" 	 name="atop">
<A style="CURSOR: w-resize" href="javascript:void(0)" id="aleft" 	 name="aleft">
<A style="CURSOR: e-resize" href="javascript:void(0)" id="aright"    name="aright">
<A style="CURSOR: s-resize" href="javascript:void(0)" id="abottom"   name="abottom" >

</form>

<form method="POST" action="MouvDecor.php" name="hotel" >
		<input type="hidden" name="finvoyage" value="1" >	
</form>

<form method="POST" action="objet.php" name="objet" >
		<input type="hidden" name="finvoyage" value="1" >	
</form>

</body></html>