<html>
	<head>

		<style type="text/css">
			.test{	filter:alpha(opacity=0);	}
		</style>

		<script src="../Javascript/MesFonctionMouvement.js"></script>
		

	</head>

<body background="../image/village2/ville2.JPG" bgproperties="fixed" >


 
<form name="test">
	<table   align="center" > 
	<?	$joueur=32;			$case=-1;
	for($j=0; $j <13 ; $j++) { 
		echo "<tr>";
			for($i=0; $i <22 ; $i++) { 	$case=   $case + 1;
				if($joueur == $case)  
				{ echo "<td width='20%'><img src='../image/avatars/bas/01.PNG' name='$case'></td>"; }
				else 					
				{echo "<td width='20%'><img src='../image/village2/01.JPG'  class='test' name='$case'></td>";}
			}
		echo "</tr>";	
	} 
	?>
	</table>
	<?	echo "<input type='hidden' name='position'  value='$joueur'>";  ?>

<A style="CURSOR: n-resize" href="javascript:void(0)" id=atop 	 name=atop>
<A style="CURSOR: w-resize" href="javascript:void(0)" id=aleft 	 name=aleft>
<A style="CURSOR: e-resize" href="javascript:void(0)" id=aright  name=aright>
<A style="CURSOR: s-resize" href="javascript:void(0)" id=abottom name=abottom >

</form>

<form method="POST" action="MouvDecorMag.php" name="hotel" >
		<input type="hidden" name="finvoyage" value="1" >	
</form>

</body></html>