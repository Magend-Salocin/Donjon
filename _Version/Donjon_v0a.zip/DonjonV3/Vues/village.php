<?session_start();
require	("../Secret/connect.php");
include ("../MesFonctions.php");
include ("../Controleurs/ControleurMenu.php");
include ("../Controleurs/ControleurVillage.php");
	
	$HeureActuelle=time();	$_SESSION["time"]=$HeureActuelle;
			
	$VIL=$_SESSION["village"] ;	$village = GetAutreVillage($_SESSION["village"] );
?>

<html>
<head><STYLE><? include ("../Controleurs/css.php"); ?></STYLE></head>

<body>



	<center><img src="../image/carte/<? echo $VIL; ?>.jpg"  usemap="#zonesClic" ></center>
	<map name="zonesClic">
		<? while($row=GetLigne($village)){ GetAfficheVillage($row);	}?>
	</map> 
    
	
	
	
</body></html>